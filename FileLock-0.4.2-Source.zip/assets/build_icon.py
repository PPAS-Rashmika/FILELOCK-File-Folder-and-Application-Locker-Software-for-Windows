"""Build the small code-drawn FileLock icon using only the Python standard library."""
import math
import pathlib
import struct
import zlib


def inside_round(x, y, left, top, right, bottom, radius):
    if not (left <= x <= right and top <= y <= bottom):
        return False
    cx = min(max(x, left + radius), right - radius)
    cy = min(max(y, top + radius), bottom - radius)
    return (x - cx) ** 2 + (y - cy) ** 2 <= radius ** 2


def pixel(x, y):
    if not inside_round(x, y, 1, 1, 47, 47, 11):
        return (0, 0, 0, 0)
    base = (0, int(115 - y * 0.3), int(215 - y * 0.4), 255)
    ring = 5 <= math.hypot(x - 24, y - 17) <= 8 and y <= 18
    sides = 16 <= x <= 19 and 17 <= y <= 24 or 29 <= x <= 32 and 17 <= y <= 24
    body = inside_round(x, y, 13, 22, 35, 37, 3)
    if body or ring or sides:
        if (x - 24) ** 2 + (y - 28) ** 2 < 2.1 ** 2 or 23 <= x <= 25 and 28 <= y <= 33:
            return base
        return (255, 255, 255, 255)
    return base


def png(size):
    raw = bytearray()
    for y in range(size):
        raw.append(0)
        for x in range(size):
            samples = [pixel((x + (sx + 0.5) / 3) * 48 / size, (y + (sy + 0.5) / 3) * 48 / size) for sy in range(3) for sx in range(3)]
            alpha = sum(s[3] for s in samples)
            if alpha:
                raw.extend(int(sum(s[c] * s[3] for s in samples) / alpha) for c in range(3))
                raw.append(int(alpha / 9))
            else:
                raw.extend((0, 0, 0, 0))

    def chunk(name, data):
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', zlib.crc32(name + data) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>2I5B', size, size, 8, 6, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b'')


sizes = [16, 24, 32, 48, 64, 128, 256]
images = [png(size) for size in sizes]
header = struct.pack('<3H', 0, 1, len(sizes))
offset = 6 + len(sizes) * 16
entries = bytearray()
for size, data in zip(sizes, images):
    entries.extend(struct.pack('<4B2H2I', size % 256, size % 256, 0, 0, 1, 32, len(data), offset))
    offset += len(data)
pathlib.Path(__file__).with_name('filelock.ico').write_bytes(header + entries + b''.join(images))

using System.Security.AccessControl;
using System.Security.Principal;
using System.Text.Json;
using FileLock.Service;
using FileLock.Shared;
using Microsoft.Win32.SafeHandles;

internal static class AtomicSaveTests
{
    internal static void Run(string root, string sid, SafeAccessTokenHandle caller, List<string> checks)
    {
        var path = Path.Combine(root, "atomic-document.txt");
        WindowsIdentity.RunImpersonated(caller, () => File.WriteAllText(path, "Before document save."));
        using var original = SecurityNative.Open(path, "", captureSecurity: true);
        var item = new ItemState { Id = Guid.NewGuid().ToString(), Name = "atomic-document.txt", OriginalPath = path,
            OwnerSid = sid, Kind = ProtectionKind.File, VolumeIdentity = original.Entry.VolumeIdentity };
        original.Dispose();
        void Persist() => File.WriteAllText(Path.Combine(root, "atomic-save-journal.json"), JsonSerializer.Serialize(item));
        using var backend = new NativePathProtection(Persist);
        var prepared = false;
        try
        {
            backend.Prepare(item); prepared = true; Persist(); backend.Upsert(item);
            var previousIdentity = item.PermissionJournal[0].FileIdentity;
            backend.Grant(item, 1);
            WindowsIdentity.RunImpersonated(caller, () =>
            {
                File.Move(path, path + ".bak");
                File.WriteAllText(path, "Saved by replacing the original document.");
            });
            backend.Revoke(item);
            NativeAclTests.Check(item.ProtectionPhase == "Locked" && item.PermissionJournal[0].FileIdentity != previousIdentity,
                "Atomic document save did not journal and relock its verified replacement.");
            try { WindowsIdentity.RunImpersonated(caller, () => File.ReadAllText(path)); throw new InvalidOperationException("Saved document stayed accessible after close."); }
            catch (UnauthorizedAccessException) { }
            checks.Add("A same-volume own-account atomic document save is durably journaled and relocked at its original location");
            var saved = item.PermissionJournal[0];
            backend.Remove(item); prepared = false;
            using var restored = SecurityNative.Open(path, "", captureSecurity: true);
            // Windows normalizes the auto-inherited bookkeeping flag on a
            // restored ACL. Compare the actual saved permissions, owner/group,
            // audit ACL and inheritance protection as the other native cases do.
            NativeLiveTests.SameSecurity(saved.OriginalSecurityDescriptor, restored.Entry.OriginalSecurityDescriptor);
            NativeAclTests.Check(WindowsIdentity.RunImpersonated(caller, () => File.ReadAllText(path)) == "Saved by replacing the original document.",
                "Removing protection changed the saved document's contents.");
            checks.Add("Removing an atomically saved document restores the replacement's exact original permissions and preserves its saved contents");
        }
        finally { if (prepared) backend.Remove(item); }
    }
}

using System.Security.Principal;
using System.Text.Json;
using System.Text.RegularExpressions;
using FileLock.Service;
using FileLock.Shared;
using Microsoft.Win32.SafeHandles;

// Exercises relocation only in fresh disposable native-test fixtures. A saved
// root identity must authorize recovery; a reused path name must never do so.
internal static class RelocationTests
{
    internal static void Run(string suppliedRoot, string sid, SafeAccessTokenHandle caller, List<string> checks)
    {
        var root = Path.GetFullPath(suppliedRoot).TrimEnd(Path.DirectorySeparatorChar);
        var fixture = new DirectoryInfo(root);
        if (!Regex.IsMatch(fixture.Name, "^native-[a-f0-9]{32}$") || fixture.Parent?.Name != ".work" || fixture.Parent.Parent?.Name != "tests")
            throw new InvalidOperationException("Relocation tests require a fresh native integration fixture.");
        for (var parent = fixture; parent != null; parent = parent.Parent)
            if (parent.Attributes.HasFlag(FileAttributes.ReparsePoint)) throw new IOException("The relocation fixture contains a reparse point.");
        using var identity = WindowsIdentity.GetCurrent();
        if (!identity.IsSystem) throw new UnauthorizedAccessException("Relocation tests require the disposable SYSTEM service.");

        LockedRename(root, sid, caller, checks);
        ApprovedParentMove(root, sid, caller, checks);
        PersistenceRollback(root, sid, caller, checks);
        MissingOriginal(root, sid, caller, checks);
        DeletedRootWithSurvivor(root, sid, caller, checks);
    }

    private static void LockedRename(string root, string sid, SafeAccessTokenHandle caller, List<string> checks)
    {
        var originalPath = Path.Combine(root, "relocation-locked-original");
        var movedPath = Path.Combine(root, "relocation-locked-renamed");
        var aliasPath = Path.Combine(root, "relocation-locked-link");
        WindowsIdentity.RunImpersonated(caller, () =>
        {
            Directory.CreateDirectory(Path.Combine(originalPath, "nested"));
            File.WriteAllText(Path.Combine(originalPath, "nested", "child.txt"), "A renamed locked fixture.");
        });
        var item = CreateItem(originalPath, sid);
        var journalPath = Path.Combine(root, "relocation-locked-journal.json");
        void Persist() => File.WriteAllText(journalPath, JsonSerializer.Serialize(item));
        using var backend = new NativePathProtection(Persist);
        var prepared = false;
        var linkCreated = false;
        try
        {
            backend.Prepare(item); prepared = true; Persist(); backend.Upsert(item);
            var originalJournal = JsonSerializer.Serialize(item.PermissionJournal);
            Directory.Move(originalPath, movedPath); // SYSTEM can rename denied contents.
            WindowsIdentity.RunImpersonated(caller, () =>
            {
                Directory.CreateDirectory(originalPath);
                File.WriteAllText(Path.Combine(originalPath, "unrelated.txt"), "Unrelated reused path name.");
            });

            var before = JsonSerializer.Serialize(item);
            var durableBefore = File.ReadAllBytes(journalPath);
            using (var unrelated = SecurityNative.Open(originalPath, "", captureSecurity: true))
            using (var unrelatedFile = SecurityNative.Open(Path.Combine(originalPath, "unrelated.txt"), "unrelated.txt", captureSecurity: true))
            {
                var rootSecurity = unrelated.Entry.OriginalSecurityDescriptor;
                var fileSecurity = unrelatedFile.Entry.OriginalSecurityDescriptor;
                unrelated.Dispose(); unrelatedFile.Dispose();
                Refused(() => backend.RecoverLocation(item, originalPath));
                AssertUnchanged(item, before, journalPath, durableBefore);
                using var afterRoot = SecurityNative.Open(originalPath, "", captureSecurity: true);
                using var afterFile = SecurityNative.Open(Path.Combine(originalPath, "unrelated.txt"), "unrelated.txt", captureSecurity: true);
                NativeLiveTests.SameSecurity(rootSecurity, afterRoot.Entry.OriginalSecurityDescriptor);
                NativeLiveTests.SameSecurity(fileSecurity, afterFile.Entry.OriginalSecurityDescriptor);
            }
            NativeAclTests.Check(WindowsIdentity.RunImpersonated(caller, () => File.ReadAllText(Path.Combine(originalPath, "unrelated.txt"))) == "Unrelated reused path name.",
                "Wrong-location recovery changed unrelated contents.");
            Denied(caller, () => File.ReadAllText(Path.Combine(movedPath, "nested", "child.txt")));
            checks.Add("Recovery refuses a different folder at the old name without changing its permissions, contents, or saved location");

            var childPath = Path.Combine(movedPath, "nested", "child.txt");
            var heldChildPath = Path.Combine(root, "relocation-held-child.txt");
            File.Move(childPath, heldChildPath);
            try
            {
                File.WriteAllText(childPath, "Different file at a saved descendant name.");
                using var replacement = SecurityNative.Open(childPath, "nested\\child.txt", captureSecurity: true);
                var replacementSecurity = replacement.Entry.OriginalSecurityDescriptor;
                replacement.Dispose();
                Refused(() => backend.RecoverLocation(item, movedPath));
                AssertUnchanged(item, before, journalPath, durableBefore);
                using var replacementAfter = SecurityNative.Open(childPath, "nested\\child.txt", captureSecurity: true);
                NativeLiveTests.SameSecurity(replacementSecurity, replacementAfter.Entry.OriginalSecurityDescriptor);
            }
            finally
            {
                File.Delete(childPath);
                File.Move(heldChildPath, childPath);
            }
            checks.Add("Recovery refuses a replaced locked descendant before modifying either the tree's permissions or its saved journal");

            Directory.CreateSymbolicLink(aliasPath, movedPath);
            linkCreated = true;
            Refused(() => backend.RecoverLocation(item, aliasPath));
            AssertUnchanged(item, before, journalPath, durableBefore);
            checks.Add("Recovery refuses a symbolic-link alias even when it points at the saved root identity");

            Refused(() => backend.RecoverLocation(item, Environment.GetFolderPath(Environment.SpecialFolder.Windows)));
            AssertUnchanged(item, before, journalPath, durableBefore);
            checks.Add("Recovery refuses Windows system locations and retains the durable permission journal");

            NativeAclTests.Check(SecurityNative.LocateOriginal(item.PermissionJournal.Single(entry => entry.RelativePath == "")) == movedPath,
                "Windows file-identity discovery did not find the renamed original root.");
            backend.Upsert(item); // Startup/expiry must repair without a manually selected path.
            NativeAclTests.Check(item.OriginalPath == movedPath && item.Name == Path.GetFileName(movedPath)
                && item.NtPath.EndsWith("\\relocation-locked-renamed", StringComparison.OrdinalIgnoreCase)
                && item.ProtectionPhase == "Locked" && item.ActiveLeaseUntilUtc == null && item.ProtectionError == null,
                "Recovery did not persist the renamed root and finish locked.");
            NativeAclTests.Check(originalJournal == JsonSerializer.Serialize(item.PermissionJournal),
                "Recovery rewrote the original permissions of an unchanged locked tree.");
            var persisted = JsonSerializer.Deserialize<ItemState>(File.ReadAllText(journalPath))!;
            NativeAclTests.Check(persisted.OriginalPath == movedPath && persisted.Name == item.Name && persisted.NtPath == item.NtPath
                && persisted.ProtectionPhase == "Locked" && persisted.ActiveLeaseUntilUtc == null,
                "Recovered location metadata was not durable.");
            Denied(caller, () => Directory.GetFileSystemEntries(movedPath));
            Denied(caller, () => File.ReadAllText(Path.Combine(movedPath, "nested", "child.txt")));
            checks.Add("A renamed locked folder is recovered by volume and root file identity, persisted, and remains inaccessible without approval");

            backend.Remove(item); prepared = false;
            AssertRestored(item);
            NativeAclTests.Check(WindowsIdentity.RunImpersonated(caller, () => File.ReadAllText(Path.Combine(movedPath, "nested", "child.txt"))) == "A renamed locked fixture.",
                "Recovered fixture contents were not restored after removing protection.");
            checks.Add("Removing a renamed folder restores every original owner, group, permission ACL, and audit ACL at its new location");
        }
        finally
        {
            if (linkCreated) Directory.Delete(aliasPath); // Remove only the link.
            if (prepared) RestoreFixture(backend, item, Directory.Exists(movedPath) ? movedPath : originalPath);
        }
    }

    private static void ApprovedParentMove(string root, string sid, SafeAccessTokenHandle caller, List<string> checks)
    {
        var originalParent = Path.Combine(root, "relocation-open-parent-original");
        var movedParent = Path.Combine(root, "relocation-open-parent-moved");
        var originalPath = Path.Combine(originalParent, "contents");
        var movedPath = Path.Combine(movedParent, "contents");
        WindowsIdentity.RunImpersonated(caller, () =>
        {
            Directory.CreateDirectory(Path.Combine(originalPath, "nested"));
            File.WriteAllText(Path.Combine(originalPath, "nested", "survivor.txt"), "Surviving original contents.");
            File.WriteAllText(Path.Combine(originalPath, "changed.txt"), "Original replaced contents.");
            File.WriteAllText(Path.Combine(originalPath, "deleted.txt"), "Removed during approved use.");
        });
        var item = CreateItem(originalPath, sid);
        var journalPath = Path.Combine(root, "relocation-open-journal.json");
        void Persist() => File.WriteAllText(journalPath, JsonSerializer.Serialize(item));
        using var backend = new NativePathProtection(Persist);
        var prepared = false;
        try
        {
            backend.Prepare(item); prepared = true; Persist(); backend.Upsert(item);
            var originalRoot = Clone(item.PermissionJournal.Single(entry => entry.RelativePath == ""));
            var survivor = Clone(item.PermissionJournal.Single(entry => entry.RelativePath == Path.Combine("nested", "survivor.txt")));
            var replacedIdentity = item.PermissionJournal.Single(entry => entry.RelativePath == "changed.txt").FileIdentity;
            backend.Grant(item, 1, 300);
            WindowsIdentity.RunImpersonated(caller, () =>
            {
                Directory.Move(originalParent, movedParent);
                File.Move(Path.Combine(movedPath, "changed.txt"), Path.Combine(movedPath, "changed.previous.txt"));
                File.WriteAllText(Path.Combine(movedPath, "changed.txt"), "Replacement saved during approved use.");
                File.Delete(Path.Combine(movedPath, "changed.previous.txt"));
                File.Delete(Path.Combine(movedPath, "deleted.txt"));
                File.WriteAllText(Path.Combine(movedPath, "added.txt"), "Added during approved use.");
            });
            backend.RecoverLocation(item, movedPath);
            NativeAclTests.Check(item.OriginalPath == movedPath && item.ProtectionPhase == "Locked" && item.ActiveLeaseUntilUtc == null && item.ProtectionError == null,
                "An approved parent move did not recover and relock the saved root.");
            var savedRoot = item.PermissionJournal.Single(entry => entry.RelativePath == "");
            var savedSurvivor = item.PermissionJournal.Single(entry => entry.RelativePath == Path.Combine("nested", "survivor.txt"));
            NativeAclTests.Check(JsonSerializer.Serialize(originalRoot) == JsonSerializer.Serialize(savedRoot)
                && JsonSerializer.Serialize(survivor) == JsonSerializer.Serialize(savedSurvivor),
                "Approved recovery changed original metadata of identity-matching descendants.");
            NativeAclTests.Check(item.PermissionJournal.Any(entry => entry.RelativePath == "added.txt")
                && item.PermissionJournal.All(entry => entry.RelativePath != "deleted.txt" && entry.RelativePath != "changed.previous.txt")
                && item.PermissionJournal.Single(entry => entry.RelativePath == "changed.txt").FileIdentity != replacedIdentity,
                "Approved recovery omitted a created/replaced file or retained a deleted descendant.");
            var durable = JsonSerializer.Deserialize<ItemState>(File.ReadAllText(journalPath))!;
            NativeAclTests.Check(JsonSerializer.Serialize(durable.PermissionJournal) == JsonSerializer.Serialize(item.PermissionJournal),
                "Updated descendants were not durably journaled before locking the recovered tree.");
            Denied(caller, () => File.ReadAllText(Path.Combine(movedPath, "added.txt")));
            Denied(caller, () => File.ReadAllText(Path.Combine(movedPath, "changed.txt")));
            Denied(caller, () => File.ReadAllText(Path.Combine(movedPath, "nested", "survivor.txt")));
            checks.Add("Moving a parent during approved use recovers the original root, journals created/replaced/deleted descendants, and relocks every current item");

            backend.Remove(item); prepared = false;
            AssertRestored(item);
            NativeAclTests.Check(WindowsIdentity.RunImpersonated(caller, () => File.ReadAllText(Path.Combine(movedPath, "changed.txt"))) == "Replacement saved during approved use."
                && WindowsIdentity.RunImpersonated(caller, () => File.ReadAllText(Path.Combine(movedPath, "added.txt"))) == "Added during approved use."
                && WindowsIdentity.RunImpersonated(caller, () => File.ReadAllText(Path.Combine(movedPath, "nested", "survivor.txt"))) == "Surviving original contents.",
                "Removing a recovered approved folder changed its current contents.");
            checks.Add("Removing an approved moved folder restores exact saved security for survivors and replacement files while preserving edited contents");
        }
        finally { if (prepared) RestoreFixture(backend, item, Directory.Exists(movedPath) ? movedPath : originalPath); }
    }

    private static void PersistenceRollback(string root, string sid, SafeAccessTokenHandle caller, List<string> checks)
    {
        var originalPath = Path.Combine(root, "relocation-persist-original");
        var movedPath = Path.Combine(root, "relocation-persist-renamed");
        WindowsIdentity.RunImpersonated(caller, () =>
        {
            Directory.CreateDirectory(originalPath);
            File.WriteAllText(Path.Combine(originalPath, "child.txt"), "A failed-save recovery fixture.");
        });
        var item = CreateItem(originalPath, sid);
        var journalPath = Path.Combine(root, "relocation-persist-journal.json");
        var failPersistence = false;
        void Persist()
        {
            if (failPersistence) throw new IOException("Injected failure before recovery journal commit.");
            File.WriteAllText(journalPath, JsonSerializer.Serialize(item));
        }
        using var backend = new NativePathProtection(Persist);
        var prepared = false;
        try
        {
            backend.Prepare(item); prepared = true; Persist(); backend.Upsert(item);
            Directory.Move(originalPath, movedPath);
            item.ProtectionError = "Original path is missing.";
            Persist();
            var before = JsonSerializer.Serialize(item);
            var durableBefore = File.ReadAllBytes(journalPath);
            using var rootBefore = SecurityNative.Open(movedPath, "", captureSecurity: true);
            using var fileBefore = SecurityNative.Open(Path.Combine(movedPath, "child.txt"), "child.txt", captureSecurity: true);
            var rootSecurity = rootBefore.Entry.OriginalSecurityDescriptor;
            var fileSecurity = fileBefore.Entry.OriginalSecurityDescriptor;
            rootBefore.Dispose(); fileBefore.Dispose();
            failPersistence = true;
            try { Refused(() => backend.RecoverLocation(item, movedPath)); }
            finally { failPersistence = false; }
            AssertUnchanged(item, before, journalPath, durableBefore);
            using (var rootAfter = SecurityNative.Open(movedPath, "", captureSecurity: true))
            using (var fileAfter = SecurityNative.Open(Path.Combine(movedPath, "child.txt"), "child.txt", captureSecurity: true))
            {
                NativeLiveTests.SameSecurity(rootSecurity, rootAfter.Entry.OriginalSecurityDescriptor);
                NativeLiveTests.SameSecurity(fileSecurity, fileAfter.Entry.OriginalSecurityDescriptor);
            }
            Denied(caller, () => File.ReadAllText(Path.Combine(movedPath, "child.txt")));
            checks.Add("Failed recovery persistence leaves the saved path, name, audit path, journal, durable bytes, and denied permissions unchanged");
            backend.RecoverLocation(item);
            backend.Remove(item); prepared = false;
            AssertRestored(item);
            checks.Add("A failed recovery can be retried successfully and its original security can still be restored");
        }
        finally
        {
            failPersistence = false;
            if (prepared) RestoreFixture(backend, item, Directory.Exists(movedPath) ? movedPath : originalPath);
        }
    }

    private static void MissingOriginal(string root, string sid, SafeAccessTokenHandle caller, List<string> checks)
    {
        var path = Path.Combine(root, "relocation-deleted-empty-root");
        WindowsIdentity.RunImpersonated(caller, () => Directory.CreateDirectory(path));
        var item = CreateItem(path, sid);
        item.PinSalt = "Disposable-saved-individual-salt";
        item.PinHash = "Disposable-saved-individual-verifier";
        var journalPath = Path.Combine(root, "relocation-deleted-journal.json");
        void Persist() => File.WriteAllText(journalPath, JsonSerializer.Serialize(item));
        using var backend = new NativePathProtection(Persist);
        var removedByTest = false;
        try
        {
            backend.Prepare(item); Persist(); backend.Upsert(item);
            var before = JsonSerializer.Serialize(item);
            var durableBefore = File.ReadAllBytes(journalPath);
            // This empty, disposable root has no real contents. Deletion is
            // deliberate and must never make recovery forget the saved entry.
            Directory.Delete(path);
            removedByTest = true;
            try { backend.Upsert(item); throw new InvalidOperationException("Recovery accepted a deleted original root."); }
            catch (GateException error) when (error.Code == "LOCATION_NOT_FOUND") { }
            AssertUnchanged(item, before, journalPath, durableBefore);
            NativeAclTests.Check(item.PermissionJournal.Count == 1 && item.PinSalt == "Disposable-saved-individual-salt"
                && item.PinHash == "Disposable-saved-individual-verifier" && !Directory.Exists(path),
                "Missing-location handling recreated a root or discarded its passcode and recovery metadata.");
            checks.Add("A deleted original root reports location-not-found while retaining its passcode, original permission journal, and durable state");
            var originalJournal = JsonSerializer.Serialize(item.PermissionJournal);
            backend.Remove(item);
            NativeAclTests.Check(!Directory.Exists(path) && originalJournal == JsonSerializer.Serialize(item.PermissionJournal),
                "Removing a deleted item recreated its root or discarded the saved journal before the broker transaction.");
            checks.Add("Removing a permanently deleted empty location succeeds without recreating contents or prematurely clearing its original journal");
        }
        finally { if (!removedByTest && Directory.Exists(path)) backend.Remove(item); }
    }

    private static void DeletedRootWithSurvivor(string root, string sid, SafeAccessTokenHandle caller, List<string> checks)
    {
        var path = Path.Combine(root, "relocation-deleted-with-survivor");
        var originalChildPath = Path.Combine(path, "child.txt");
        var survivorPath = Path.Combine(root, "relocation-independent-survivor.txt");
        WindowsIdentity.RunImpersonated(caller, () =>
        {
            Directory.CreateDirectory(path);
            File.WriteAllText(originalChildPath, "An original child moved independently before root deletion.");
        });
        var item = CreateItem(path, sid);
        var journalPath = Path.Combine(root, "relocation-deleted-survivor-journal.json");
        void Persist() => File.WriteAllText(journalPath, JsonSerializer.Serialize(item));
        using var backend = new NativePathProtection(Persist);
        var prepared = false;
        PermissionJournalEntry? savedChild = null;
        try
        {
            backend.Prepare(item); prepared = true; Persist(); backend.Upsert(item);
            savedChild = Clone(item.PermissionJournal.Single(entry => entry.RelativePath == "child.txt"));
            var originalJournal = JsonSerializer.Serialize(item.PermissionJournal);
            File.Move(originalChildPath, survivorPath);
            Directory.Delete(path);
            Denied(caller, () => File.ReadAllText(survivorPath));

            // Another folder with the old name is unrelated. Neither its root
            // nor its reused child name may receive this item's saved security.
            WindowsIdentity.RunImpersonated(caller, () =>
            {
                Directory.CreateDirectory(path);
                File.WriteAllText(originalChildPath, "An unrelated folder at the old root name.");
            });
            using var unrelatedRoot = SecurityNative.Open(path, "", captureSecurity: true);
            using var unrelatedChild = SecurityNative.Open(originalChildPath, "child.txt", captureSecurity: true);
            var unrelatedRootSecurity = unrelatedRoot.Entry.OriginalSecurityDescriptor;
            var unrelatedChildSecurity = unrelatedChild.Entry.OriginalSecurityDescriptor;
            unrelatedRoot.Dispose(); unrelatedChild.Dispose();

            backend.Remove(item); prepared = false;
            using (var restored = SecurityNative.Open(survivorPath, "child.txt", captureSecurity: true))
            {
                NativeAclTests.Check(SecurityNative.IdentityMatches(savedChild, restored.Entry), "Deleted-root removal changed the surviving child's identity.");
                NativeLiveTests.SameSecurity(savedChild.OriginalSecurityDescriptor, restored.Entry.OriginalSecurityDescriptor);
            }
            NativeAclTests.Check(WindowsIdentity.RunImpersonated(caller, () => File.ReadAllText(survivorPath)) == "An original child moved independently before root deletion."
                && originalJournal == JsonSerializer.Serialize(item.PermissionJournal),
                "Deleted-root removal changed surviving contents or prematurely cleared its original permission journal.");
            checks.Add("Removing a deleted original root finds an independently moved child by its saved identity and restores its exact original owner, group, permission ACL, audit ACL, and contents");
            using (var rootAfter = SecurityNative.Open(path, "", captureSecurity: true))
            using (var childAfter = SecurityNative.Open(originalChildPath, "child.txt", captureSecurity: true))
            {
                NativeLiveTests.SameSecurity(unrelatedRootSecurity, rootAfter.Entry.OriginalSecurityDescriptor);
                NativeLiveTests.SameSecurity(unrelatedChildSecurity, childAfter.Entry.OriginalSecurityDescriptor);
            }
            NativeAclTests.Check(WindowsIdentity.RunImpersonated(caller, () => File.ReadAllText(originalChildPath)) == "An unrelated folder at the old root name.",
                "Deleted-root removal changed the unrelated replacement's contents.");
            checks.Add("Deleted-location removal leaves a reused old root and child name untouched rather than applying saved security to unrelated files");
        }
        finally
        {
            if (prepared && savedChild != null && File.Exists(survivorPath))
            {
                // Restore only the exact independently moved fixture identity
                // even when a production removal regression fails the test.
                using var survivor = SecurityNative.Open(survivorPath, "child.txt", captureSecurity: false);
                if (SecurityNative.IdentityMatches(savedChild, survivor.Entry)) SecurityNative.Restore(survivor, savedChild);
            }
            else if (prepared && Directory.Exists(path)) backend.Remove(item);
        }
    }

    private static ItemState CreateItem(string path, string sid)
    {
        using var target = SecurityNative.Open(path, "", captureSecurity: true);
        return new ItemState { Id = Guid.NewGuid().ToString(), Name = Path.GetFileName(path), OriginalPath = path,
            OwnerSid = sid, Kind = ProtectionKind.Folder, VolumeIdentity = target.Entry.VolumeIdentity, AddedUtc = DateTimeOffset.UtcNow };
    }

    private static PermissionJournalEntry Clone(PermissionJournalEntry entry) => JsonSerializer.Deserialize<PermissionJournalEntry>(JsonSerializer.Serialize(entry))!;

    private static void Refused(Action action)
    {
        try { action(); }
        catch (IOException) { return; }
        catch (GateException) { return; }
        throw new InvalidOperationException("Unsafe or uncommitted location recovery was accepted.");
    }

    private static void AssertUnchanged(ItemState item, string serialized, string journalPath, byte[] durable)
    {
        NativeAclTests.Check(serialized == JsonSerializer.Serialize(item) && durable.SequenceEqual(File.ReadAllBytes(journalPath)),
            "Rejected recovery changed the saved item or its durable permission journal.");
    }

    private static void Denied(SafeAccessTokenHandle caller, Action action)
    {
        try { WindowsIdentity.RunImpersonated(caller, action); }
        catch (UnauthorizedAccessException) { return; }
        throw new InvalidOperationException("An unelevated account accessed a recovered locked fixture.");
    }

    private static void AssertRestored(ItemState item)
    {
        foreach (var entry in item.PermissionJournal)
        {
            var path = entry.RelativePath.Length == 0 ? item.OriginalPath : Path.Combine(item.OriginalPath, entry.RelativePath);
            using var target = SecurityNative.Open(path, entry.RelativePath, captureSecurity: true);
            NativeAclTests.Check(SecurityNative.IdentityMatches(entry, target.Entry), "Recovery removal changed a file identity.");
            NativeLiveTests.SameSecurity(entry.OriginalSecurityDescriptor, target.Entry.OriginalSecurityDescriptor);
        }
    }

    private static void RestoreFixture(NativePathProtection backend, ItemState item, string actualPath)
    {
        // The test created and renamed this exact identity. Cleanup keeps its
        // original journal even if the production recovery operation failed.
        item.OriginalPath = actualPath;
        backend.Remove(item);
    }
}

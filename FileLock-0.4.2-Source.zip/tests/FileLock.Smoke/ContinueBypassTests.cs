using System.Text.Json;

// Requests Explorer-equivalent permission changes from the actual elevated
// PowerShell helper, not the SYSTEM test service or an artificial restricted token.
internal static class ContinueBypassTests
{
    internal static async Task AssertDeniedAsync(string root, string path, string ownerSid, List<string> checks)
    {
        var id = Guid.NewGuid().ToString("N");
        var requestPath = Path.Combine(root, "admin-probe-request.json");
        var temporary = requestPath + ".next";
        File.WriteAllText(temporary, JsonSerializer.Serialize(new { Id = id, Path = path }));
        File.Move(temporary, requestPath, overwrite: true);
        var responsePath = Path.Combine(root, "admin-probe-response.json");
        var deadline = DateTimeOffset.UtcNow.AddSeconds(20);
        while (DateTimeOffset.UtcNow < deadline)
        {
            try
            {
                if (File.Exists(responsePath) && new FileInfo(responsePath).Length < 16 * 1024)
                {
                    var response = JsonSerializer.Deserialize<ContinueResponse>(File.ReadAllText(responsePath));
                    if (response?.Id == id)
                    {
                        NativeAclTests.Check(response.Error == null, "The actual elevated Continue helper failed: " + response.Error);
                        NativeAclTests.Check(response.ProcessId != Environment.ProcessId && response.IsAdministrator && response.UserSid == ownerSid
                            && !response.TakeOwnershipEnabled && !response.RestoreEnabled && !response.BackupEnabled,
                            "Continue regression did not use the default elevated administrator token.");
                        NativeAclTests.Check(response.OwnerSid == "S-1-5-18" && response.EnumerationDenied && response.ReadDenied,
                            "An elevated administrator can enumerate or read the locked original folder without a PIN.");
                        checks.Add("Actual elevated administrator with disabled takeover privileges cannot list or read locked " + Path.GetFileName(path));
                        NativeAclTests.Check(response.WriteDacError == 5 && response.WriteOwnerError == 5,
                            "An elevated administrator can open WRITE_DAC or WRITE_OWNER on the locked original folder.");
                        checks.Add("Elevated WRITE_DAC and WRITE_OWNER opens fail with access denied for " + Path.GetFileName(path));
                        NativeAclTests.Check(response.GrantDenied && response.DescriptorUnchanged,
                            "Explorer-equivalent inherited FullControl grant changed the locked folder permissions without a PIN.");
                        checks.Add("Explorer Continue equivalent inherited FullControl grant is denied and permissions stay unchanged for " + Path.GetFileName(path));
                        return;
                    }
                }
            }
            catch (IOException) { }
            catch (JsonException) { }
            await Task.Delay(50);
        }
        throw new TimeoutException("The actual elevated helper did not answer the isolated Continue bypass probe.");
    }

    private sealed class ContinueResponse
    {
        public string Id { get; set; } = "";
        public uint ProcessId { get; set; }
        public string? UserSid { get; set; }
        public bool IsAdministrator { get; set; }
        public bool TakeOwnershipEnabled { get; set; }
        public bool RestoreEnabled { get; set; }
        public bool BackupEnabled { get; set; }
        public string? OwnerSid { get; set; }
        public bool EnumerationDenied { get; set; }
        public bool ReadDenied { get; set; }
        public int WriteDacError { get; set; }
        public int WriteOwnerError { get; set; }
        public bool GrantDenied { get; set; }
        public bool DescriptorUnchanged { get; set; }
        public string? Error { get; set; }
    }
}

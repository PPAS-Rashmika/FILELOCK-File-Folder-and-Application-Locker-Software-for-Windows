using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using FileLock.Service;
using FileLock.Shared;
using Microsoft.Win32.SafeHandles;

// Only the test script registers this short-lived SYSTEM service. It operates
// on freshly-created tests/.work fixtures and never opens the live broker store.
internal static class NativeLiveTests
{
    private static readonly CancellationTokenSource Stop = new();
    private static ServiceMainCallback? _main;
    private static HandlerCallback? _handler;
    private static IntPtr _status;
    private static string[] _arguments = [];

    internal static int RunService(string[] args)
    {
        if (args.Length != 5 || !Regex.IsMatch(args[1], "^FileLockNativeTest-[a-f0-9]{16}$")) return 2;
        _arguments = args;
        _main = ServiceMain;
        _handler = Control;
        var table = new[] { new ServiceEntry { Name = args[1], Main = Marshal.GetFunctionPointerForDelegate(_main) }, new ServiceEntry() };
        if (!StartServiceCtrlDispatcher(table)) return Marshal.GetLastWin32Error();
        return 0;
    }

    private static void ServiceMain(uint count, IntPtr arguments)
    {
        _status = RegisterServiceCtrlHandlerEx(_arguments[1], _handler!, IntPtr.Zero);
        SetStatus(2, 0, 30_000);
        SetStatus(4, 0, 0);
        var code = 1;
        try { code = RunAsync(_arguments[2], _arguments[3], uint.Parse(_arguments[4])).GetAwaiter().GetResult() ? 0 : 1; }
        catch (Exception error)
        {
            code = 2;
            // Early setup failures still leave a report in the validated fresh
            // fixture so the hidden elevated helper can explain the failure.
            try
            {
                var fixture = new DirectoryInfo(Path.GetFullPath(_arguments[2]));
                if (Regex.IsMatch(fixture.Name, "^native-[a-f0-9]{32}$") && fixture.Parent?.Name == ".work" && fixture.Parent.Parent?.Name == "tests")
                {
                    var safe = true;
                    for (var parent = fixture; parent != null; parent = parent.Parent)
                        safe &= !parent.Attributes.HasFlag(FileAttributes.ReparsePoint);
                    if (safe) File.WriteAllText(Path.Combine(fixture.FullName, "result.json"), JsonSerializer.Serialize(new { Passed = false, Checks = Array.Empty<string>(), Errors = new[] { error.ToString() }, PersistenceCount = 0 }, new JsonSerializerOptions { WriteIndented = true }));
                }
            }
            catch { }
        }
        SetStatus(1, (uint)code, 0);
    }

    private static uint Control(uint control, uint eventType, IntPtr eventData, IntPtr context)
    {
        if (control is 1 or 5) { Stop.Cancel(); SetStatus(3, 0, 30_000); }
        return 0;
    }

    private static void SetStatus(uint state, uint code, uint wait)
    {
        var status = new ServiceStatus { Type = 0x10, State = state, Controls = state == 4 ? 1U : 0U, ExitCode = code, WaitHint = wait };
        SetServiceStatus(_status, ref status);
    }

    private static async Task<bool> RunAsync(string suppliedRoot, string ownerSid, uint processId)
    {
        var root = Path.GetFullPath(suppliedRoot).TrimEnd(Path.DirectorySeparatorChar);
        var directory = new DirectoryInfo(root);
        if (!Regex.IsMatch(directory.Name, "^native-[a-f0-9]{32}$") || directory.Parent?.Name != ".work" || directory.Parent.Parent?.Name != "tests")
            throw new InvalidOperationException("Live native tests require a freshly-created tests/.work/native-<guid> fixture.");
        for (var parent = directory; parent != null; parent = parent.Parent)
            if (parent.Attributes.HasFlag(FileAttributes.ReparsePoint)) throw new IOException("The test fixture path contains a junction or symbolic link.");
        using var serviceIdentity = WindowsIdentity.GetCurrent();
        if (!serviceIdentity.IsSystem) throw new UnauthorizedAccessException("The native integration harness must run in its temporary LocalSystem service.");
        SecurityNative.EnableRequiredPrivileges();
        using var normalToken = CallerToken(processId, ownerSid);
        using var fixtureRoot = SecurityNative.Open(root, "", captureSecurity: true);
        var rootSecurity = new RawSecurityDescriptor(Convert.FromBase64String(fixtureRoot.Entry.OriginalSecurityDescriptor), 0);
        if (rootSecurity.Owner?.Value != ownerSid) throw new InvalidOperationException("The fresh fixture is not owned by the unelevated test caller.");
        fixtureRoot.Dispose();

        var checks = new List<string>();
        var errors = new List<string>();
        var items = new List<ItemState>();
        var persistenceCount = 0;
        var persisted = new Dictionary<string, PermissionJournalEntry[]>(StringComparer.Ordinal);
        var queuedAudits = new List<AccessAuditNotification>();
        var lockedSecurity = new List<object>();
        var auditEvents = new List<object>();
        var diagnosticErrors = new List<string>();
        var normalProcessProbes = new List<object>();
        object? backendStatus = null;
        NativePathProtection? backend = null;
        void Persist()
        {
            persistenceCount++;
            foreach (var item in items)
                persisted[item.Id] = item.PermissionJournal.Select(Clone).ToArray();
            File.WriteAllText(Path.Combine(root, "journal.json"), JsonSerializer.Serialize(items, new JsonSerializerOptions { WriteIndented = true }));
        }
        try
        {
            backend = new(Persist);
            NativeAclTests.Check(backend.Available, "Windows NTFS backend unavailable: " + backend.UnavailableReason);
            foreach (var (relative, kind) in new[] { ("single.txt", ProtectionKind.File), ("folder", ProtectionKind.Folder), ("application.exe", ProtectionKind.Application) })
            {
                Stop.Token.ThrowIfCancellationRequested();
                var path = Path.Combine(root, relative);
                var content = kind == ProtectionKind.Folder ? Path.Combine(path, "nested", "child.txt") : path;
                var baseline = await ProbeNormalProcessAsync(root, content);
                normalProcessProbes.Add(new { Stage = "BeforeLock", Path = content, Response = baseline });
                NativeAclTests.Check(baseline.ProcessId == processId && baseline.ReadSucceeded, "The actual normal process could not read the original fixture before locking: " + baseline.ErrorType + " " + baseline.ErrorMessage);
                checks.Add($"Baseline {kind.ToString().ToLowerInvariant()} content is readable by the actual normal Windows process");
                if (kind == ProtectionKind.Folder)
                {
                    var listing = await ProbeNormalProcessAsync(root, path, "Enumerate");
                    normalProcessProbes.Add(new { Stage = "BeforeLock", Path = path, Response = listing });
                    NativeAclTests.Check(listing.ProcessId == processId && listing.Operation == "Enumerate" && listing.Succeeded && listing.EntryCount > 0,
                        "The actual normal process could not list the original folder before locking: " + listing.ErrorType + " " + listing.ErrorMessage);
                    var nestedListing = await ProbeNormalProcessAsync(root, Path.Combine(path, "nested"), "Enumerate");
                    normalProcessProbes.Add(new { Stage = "BeforeLock", Path = Path.Combine(path, "nested"), Response = nestedListing });
                    NativeAclTests.Check(nestedListing.ProcessId == processId && nestedListing.Operation == "Enumerate" && nestedListing.Succeeded && nestedListing.EntryCount > 0,
                        "The actual normal process could not list the nested original folder before locking: " + nestedListing.ErrorType + " " + nestedListing.ErrorMessage);
                    checks.Add("Baseline original root and nested folder listings succeed in the actual normal Windows process");
                }
                if (kind == ProtectionKind.Application)
                {
                    var execution = await ProbeNormalProcessAsync(root, content, "Execute");
                    normalProcessProbes.Add(new { Stage = "BeforeLock", Path = content, Response = execution });
                    NativeAclTests.Check(execution.ProcessId == processId && execution.Operation == "Execute" && execution.Succeeded, "The actual normal process could not execute the disposable application before locking: " + execution.ErrorType + " " + execution.ErrorMessage);
                    checks.Add("Baseline original application executes successfully in the actual normal Windows process");
                }
                using var before = SecurityNative.Open(path, "", captureSecurity: true);
                var item = new ItemState
                {
                    Id = Guid.NewGuid().ToString(), Name = relative, OriginalPath = path, OwnerSid = ownerSid, Kind = kind,
                    VolumeIdentity = before.Entry.VolumeIdentity, AddedUtc = DateTimeOffset.UtcNow
                };
                before.Dispose();
                items.Add(item);
                backend.Prepare(item);
                Persist(); // Original metadata must be durable before first lock.
                NativeAclTests.Check(item.PermissionJournal.Count >= (kind == ProtectionKind.Folder ? 3 : 1), "A descendant was omitted from the permission journal.");
                backend.Upsert(item);
                NativeAclTests.Check(item.ProtectionPhase == "Locked" && persisted[item.Id].Length == item.PermissionJournal.Count, "The lock was applied without a durable original-permission journal.");
                using (var locked = SecurityNative.Open(content, "", captureSecurity: true))
                {
                    var descriptor = new RawSecurityDescriptor(Convert.FromBase64String(locked.Entry.OriginalSecurityDescriptor), 0);
                    lockedSecurity.Add(new { Path = content, SecurityDescriptor = locked.Entry.OriginalSecurityDescriptor, Sddl = descriptor.GetSddlForm(AccessControlSections.All), SystemAclCount = descriptor.SystemAcl?.Count ?? 0, ControlFlags = descriptor.ControlFlags.ToString() });
                }
                Denied(normalToken, () => File.ReadAllBytes(content));
                Denied(normalToken, () => { File.WriteAllText(content, "This must never overwrite a locked fixture."); return true; });
                Denied(normalToken, () =>
                {
                    var info = new FileInfo(content);
                    var acl = info.GetAccessControl(AccessControlSections.Access);
                    acl.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(ownerSid), FileSystemRights.FullControl, AccessControlType.Allow));
                    info.SetAccessControl(acl);
                    return true;
                });
                if (kind == ProtectionKind.Folder) Denied(normalToken, () => Directory.GetFileSystemEntries(path));
                checks.Add($"Original {kind.ToString().ToLowerInvariant()} path denies read, write, and permission changes to the unelevated owner");
                var lockedProbe = await ProbeNormalProcessAsync(root, content);
                normalProcessProbes.Add(new { Stage = "Locked", Path = content, Response = lockedProbe });
                NativeAclTests.Check(lockedProbe.ProcessId == processId && !lockedProbe.ReadSucceeded && lockedProbe.ErrorType == typeof(UnauthorizedAccessException).FullName,
                    "The actual normal Windows process did not receive ACL access denial: " + lockedProbe.ErrorType + " " + lockedProbe.ErrorMessage);
                checks.Add("An actual normal Windows process receives access denial at the original location");
                if (kind == ProtectionKind.Folder)
                {
                    var listing = await ProbeNormalProcessAsync(root, path, "Enumerate");
                    normalProcessProbes.Add(new { Stage = "Locked", Path = path, Response = listing });
                    NativeAclTests.Check(listing.ProcessId == processId && listing.Operation == "Enumerate" && !listing.Succeeded && listing.EntryCount == null && listing.ErrorType == typeof(UnauthorizedAccessException).FullName,
                        "The locked original folder listing did not fail with Windows access denied: " + listing.ErrorType + " " + listing.ErrorMessage);
                    var nestedListing = await ProbeNormalProcessAsync(root, Path.Combine(path, "nested"), "Enumerate");
                    normalProcessProbes.Add(new { Stage = "Locked", Path = Path.Combine(path, "nested"), Response = nestedListing });
                    NativeAclTests.Check(nestedListing.ProcessId == processId && nestedListing.Operation == "Enumerate" && !nestedListing.Succeeded && nestedListing.EntryCount == null && nestedListing.ErrorType == typeof(UnauthorizedAccessException).FullName,
                        "The locked nested-folder listing did not fail with Windows access denied: " + nestedListing.ErrorType + " " + nestedListing.ErrorMessage);
                    checks.Add("Locked original root and nested folder listings are denied to the actual normal Windows process");
                }
                if (kind == ProtectionKind.Application)
                {
                    var execution = await ProbeNormalProcessAsync(root, content, "Execute");
                    normalProcessProbes.Add(new { Stage = "Locked", Path = content, Response = execution });
                    NativeAclTests.Check(execution.ProcessId == processId && execution.Operation == "Execute" && !execution.Succeeded && execution.NativeErrorCode == 5, "The locked application execution did not fail with Windows access denied: " + execution.ErrorType + " " + execution.ErrorMessage);
                    checks.Add("Locked original application execution fails with Windows access denied");
                }

                var auditDeadline = DateTimeOffset.UtcNow.AddSeconds(15);
                var notification = false;
                var folderRootNotification = kind != ProtectionKind.Folder;
                while ((!notification || !folderRootNotification) && DateTimeOffset.UtcNow < auditDeadline)
                {
                    while (backend.Notifications.TryDequeue(out var entry))
                    {
                        queuedAudits.Add(entry);
                        if (entry.OwnerSid == ownerSid && (SameAuditPath(entry.Path, content) || SameAuditPath(entry.Path, path))) notification = true;
                        if (entry.OwnerSid == ownerSid && SameAuditPath(entry.Path, path)) folderRootNotification = true;
                    }
                    if (!notification || !folderRootNotification) await Task.Delay(100, Stop.Token);
                }
                NativeAclTests.Check(notification, "Windows did not deliver a matching failed-access audit event for " + path);
                checks.Add("Failed original-path access reaches the raw access-audit diagnostics queue");
                if (kind == ProtectionKind.Folder)
                {
                    NativeAclTests.Check(folderRootNotification, "Windows did not deliver a failed folder-root enumeration audit event for " + path);
                    checks.Add("Direct original folder listing failure reaches the raw access-audit diagnostics queue at the folder root");
                }

                backend.Grant(item, 1, 2);
                NativeAclTests.Check(item.ProtectionPhase == "Open" && item.ActiveLeaseUntilUtc > DateTimeOffset.UtcNow && item.ActiveLeaseUntilUtc <= DateTimeOffset.UtcNow.AddSeconds(3), "An approved access deadline was not recorded.");
                var read = WindowsIdentity.RunImpersonated(normalToken, () => File.ReadAllBytes(content));
                NativeAclTests.Check(read.Length > 0, "The original path remained blocked after grant.");
                var grantedProbe = await ProbeNormalProcessAsync(root, content);
                normalProcessProbes.Add(new { Stage = "Granted", Path = content, Response = grantedProbe });
                NativeAclTests.Check(grantedProbe.ProcessId == processId && grantedProbe.ReadSucceeded, "The actual normal process remained blocked after grant: " + grantedProbe.ErrorType + " " + grantedProbe.ErrorMessage);
                if (kind == ProtectionKind.Folder)
                {
                    var listing = await ProbeNormalProcessAsync(root, path, "Enumerate");
                    normalProcessProbes.Add(new { Stage = "Granted", Path = path, Response = listing });
                    NativeAclTests.Check(listing.ProcessId == processId && listing.Operation == "Enumerate" && listing.Succeeded && listing.EntryCount > 0,
                        "The actual normal process could not list the original folder after approval: " + listing.ErrorType + " " + listing.ErrorMessage);
                    var nestedListing = await ProbeNormalProcessAsync(root, Path.Combine(path, "nested"), "Enumerate");
                    normalProcessProbes.Add(new { Stage = "Granted", Path = Path.Combine(path, "nested"), Response = nestedListing });
                    NativeAclTests.Check(nestedListing.ProcessId == processId && nestedListing.Operation == "Enumerate" && nestedListing.Succeeded && nestedListing.EntryCount > 0,
                        "The actual normal process could not list the nested folder after approval: " + nestedListing.ErrorType + " " + nestedListing.ErrorMessage);
                    checks.Add("Approved original root and nested folder listings succeed");
                }
                if (kind == ProtectionKind.Application)
                {
                    var execution = await ProbeNormalProcessAsync(root, content, "Execute");
                    normalProcessProbes.Add(new { Stage = "Granted", Path = content, Response = execution });
                    NativeAclTests.Check(execution.ProcessId == processId && execution.Operation == "Execute" && execution.Succeeded, "The actual normal process could not execute the application after approval: " + execution.ErrorType + " " + execution.ErrorMessage);
                    checks.Add("Approved original application executes successfully");
                }
                using var existingHandle = WindowsIdentity.RunImpersonated(normalToken, () => new FileStream(content, FileMode.Open, FileAccess.Read, FileShare.Read));
                if (kind == ProtectionKind.Folder)
                    WindowsIdentity.RunImpersonated(normalToken, () => File.WriteAllText(Path.Combine(path, "new.txt"), "Created during the approved window."));
                await Task.Delay(2100, Stop.Token);
                backend.Revoke(item);
                NativeAclTests.Check(item.ActiveLeaseUntilUtc == null && item.ProtectionPhase == "Locked", "Relock did not close the access deadline.");
                Denied(normalToken, () => File.ReadAllBytes(content));
                var revokedProbe = await ProbeNormalProcessAsync(root, content);
                normalProcessProbes.Add(new { Stage = "Relocked", Path = content, Response = revokedProbe });
                NativeAclTests.Check(revokedProbe.ProcessId == processId && !revokedProbe.ReadSucceeded && revokedProbe.ErrorType == typeof(UnauthorizedAccessException).FullName, "Relock did not deny the actual normal Windows process.");
                if (kind == ProtectionKind.Folder)
                {
                    var listing = await ProbeNormalProcessAsync(root, path, "Enumerate");
                    normalProcessProbes.Add(new { Stage = "Relocked", Path = path, Response = listing });
                    NativeAclTests.Check(listing.ProcessId == processId && listing.Operation == "Enumerate" && !listing.Succeeded && listing.EntryCount == null && listing.ErrorType == typeof(UnauthorizedAccessException).FullName,
                        "Relocked original folder listing did not fail with Windows access denied: " + listing.ErrorType + " " + listing.ErrorMessage);
                    var nestedListing = await ProbeNormalProcessAsync(root, Path.Combine(path, "nested"), "Enumerate");
                    normalProcessProbes.Add(new { Stage = "Relocked", Path = Path.Combine(path, "nested"), Response = nestedListing });
                    NativeAclTests.Check(nestedListing.ProcessId == processId && nestedListing.Operation == "Enumerate" && !nestedListing.Succeeded && nestedListing.EntryCount == null && nestedListing.ErrorType == typeof(UnauthorizedAccessException).FullName,
                        "Relocked nested-folder listing did not fail with Windows access denied: " + nestedListing.ErrorType + " " + nestedListing.ErrorMessage);
                    checks.Add("Relocked original root and nested folder listings are denied again");
                }
                if (kind == ProtectionKind.Application)
                {
                    var execution = await ProbeNormalProcessAsync(root, content, "Execute");
                    normalProcessProbes.Add(new { Stage = "Relocked", Path = content, Response = execution });
                    NativeAclTests.Check(execution.ProcessId == processId && execution.Operation == "Execute" && !execution.Succeeded && execution.NativeErrorCode == 5, "Relocked application execution did not fail with Windows access denied: " + execution.ErrorType + " " + execution.ErrorMessage);
                    checks.Add("Relocked original application execution is denied again");
                }
                NativeAclTests.Check(existingHandle.ReadByte() >= 0, "An already-approved handle was unexpectedly invalidated.");
                if (kind == ProtectionKind.Folder)
                {
                    NativeAclTests.Check(item.PermissionJournal.Any(entry => entry.RelativePath == "new.txt"), "A file created during access was locked without saving its original permissions.");
                    Denied(normalToken, () => File.ReadAllText(Path.Combine(path, "new.txt")));
                }
                checks.Add("Relock blocks new opens while an already-approved read handle remains open");
                checks.Add("Grant opens the original path, and relock includes files created during access");

                backend.Remove(item);
                foreach (var original in item.PermissionJournal)
                {
                    var originalPath = original.RelativePath.Length == 0 ? path : Path.Combine(path, original.RelativePath);
                    using var restored = SecurityNative.Open(originalPath, original.RelativePath, captureSecurity: true);
                    NativeAclTests.Check(SecurityNative.IdentityMatches(original, restored.Entry), "Restoration changed a file identity.");
                    SameSecurity(original.OriginalSecurityDescriptor, restored.Entry.OriginalSecurityDescriptor);
                }
                WindowsIdentity.RunImpersonated(normalToken, () => File.ReadAllBytes(content));
                item.ProtectionPhase = "Removed";
                checks.Add("Remove restores original owner, group, DACL, and SACL without moving contents");
            }

            // An empty folder has no descendant access to accidentally trigger
            // the prompt: enumeration of the original directory must suffice.
            var emptyPath = Path.Combine(root, "empty-folder");
            var emptyBaseline = await ProbeNormalProcessAsync(root, emptyPath, "Enumerate");
            normalProcessProbes.Add(new { Stage = "BeforeLock", Path = emptyPath, Response = emptyBaseline });
            NativeAclTests.Check(emptyBaseline.ProcessId == processId && emptyBaseline.Operation == "Enumerate" && emptyBaseline.Succeeded && emptyBaseline.EntryCount == 0,
                "The actual normal process could not list the empty folder before locking: " + emptyBaseline.ErrorType + " " + emptyBaseline.ErrorMessage);
            checks.Add("Baseline empty original folder listing succeeds with zero entries");
            using var emptyBefore = SecurityNative.Open(emptyPath, "", captureSecurity: true);
            var emptyItem = new ItemState
            {
                Id = Guid.NewGuid().ToString(), Name = "empty-folder", OriginalPath = emptyPath, OwnerSid = ownerSid, Kind = ProtectionKind.Folder,
                VolumeIdentity = emptyBefore.Entry.VolumeIdentity, AddedUtc = DateTimeOffset.UtcNow
            };
            emptyBefore.Dispose();
            items.Add(emptyItem);
            backend.Prepare(emptyItem);
            Persist();
            NativeAclTests.Check(emptyItem.PermissionJournal.Count == 1 && emptyItem.PermissionJournal[0].RelativePath == "", "The empty-folder journal did not contain exactly its original root.");
            backend.Upsert(emptyItem);
            NativeAclTests.Check(emptyItem.ProtectionPhase == "Locked" && persisted[emptyItem.Id].Length == 1, "The empty folder was locked without a durable original-permission journal.");
            using (var locked = SecurityNative.Open(emptyPath, "", captureSecurity: true))
            {
                var descriptor = new RawSecurityDescriptor(Convert.FromBase64String(locked.Entry.OriginalSecurityDescriptor), 0);
                lockedSecurity.Add(new { Path = emptyPath, SecurityDescriptor = locked.Entry.OriginalSecurityDescriptor, Sddl = descriptor.GetSddlForm(AccessControlSections.All), SystemAclCount = descriptor.SystemAcl?.Count ?? 0, ControlFlags = descriptor.ControlFlags.ToString() });
            }
            Denied(normalToken, () => Directory.GetFileSystemEntries(emptyPath));
            var emptyLocked = await ProbeNormalProcessAsync(root, emptyPath, "Enumerate");
            normalProcessProbes.Add(new { Stage = "Locked", Path = emptyPath, Response = emptyLocked });
            NativeAclTests.Check(emptyLocked.ProcessId == processId && emptyLocked.Operation == "Enumerate" && !emptyLocked.Succeeded && emptyLocked.EntryCount == null && emptyLocked.ErrorType == typeof(UnauthorizedAccessException).FullName,
                "The locked empty-folder listing did not fail with Windows access denied: " + emptyLocked.ErrorType + " " + emptyLocked.ErrorMessage);
            checks.Add("Locked empty original folder listing is denied to the actual normal Windows process");
            var emptyAuditDeadline = DateTimeOffset.UtcNow.AddSeconds(15);
            var emptyAudit = false;
            while (!emptyAudit && DateTimeOffset.UtcNow < emptyAuditDeadline)
            {
                while (backend.Notifications.TryDequeue(out var entry))
                {
                    queuedAudits.Add(entry);
                    if (entry.OwnerSid == ownerSid && SameAuditPath(entry.Path, emptyPath)) emptyAudit = true;
                }
                if (!emptyAudit) await Task.Delay(100, Stop.Token);
            }
            NativeAclTests.Check(emptyAudit, "Windows did not deliver a failed empty-folder root enumeration audit event for " + emptyPath);
            checks.Add("Empty folder root access reaches the raw access-audit diagnostics queue without any descendant probe");
            backend.Grant(emptyItem, 1, 2);
            NativeAclTests.Check(emptyItem.ProtectionPhase == "Open" && emptyItem.ActiveLeaseUntilUtc > DateTimeOffset.UtcNow, "Approved empty-folder access was not recorded.");
            var emptyGranted = await ProbeNormalProcessAsync(root, emptyPath, "Enumerate");
            normalProcessProbes.Add(new { Stage = "Granted", Path = emptyPath, Response = emptyGranted });
            NativeAclTests.Check(emptyGranted.ProcessId == processId && emptyGranted.Operation == "Enumerate" && emptyGranted.Succeeded && emptyGranted.EntryCount == 0,
                "The actual normal process could not list the empty folder after approval: " + emptyGranted.ErrorType + " " + emptyGranted.ErrorMessage);
            checks.Add("Approved empty original folder listing succeeds with zero entries");
            await Task.Delay(2100, Stop.Token);
            backend.Revoke(emptyItem);
            NativeAclTests.Check(emptyItem.ActiveLeaseUntilUtc == null && emptyItem.ProtectionPhase == "Locked", "Relock did not close the empty-folder access deadline.");
            var emptyRelocked = await ProbeNormalProcessAsync(root, emptyPath, "Enumerate");
            normalProcessProbes.Add(new { Stage = "Relocked", Path = emptyPath, Response = emptyRelocked });
            NativeAclTests.Check(emptyRelocked.ProcessId == processId && emptyRelocked.Operation == "Enumerate" && !emptyRelocked.Succeeded && emptyRelocked.EntryCount == null && emptyRelocked.ErrorType == typeof(UnauthorizedAccessException).FullName,
                "Relocked empty-folder listing did not fail with Windows access denied: " + emptyRelocked.ErrorType + " " + emptyRelocked.ErrorMessage);
            checks.Add("Relocked empty original folder listing is denied again");
            backend.Remove(emptyItem);
            using (var restored = SecurityNative.Open(emptyPath, "", captureSecurity: true))
            {
                NativeAclTests.Check(SecurityNative.IdentityMatches(emptyItem.PermissionJournal[0], restored.Entry), "Empty-folder restoration changed the root identity.");
                SameSecurity(emptyItem.PermissionJournal[0].OriginalSecurityDescriptor, restored.Entry.OriginalSecurityDescriptor);
            }
            NativeAclTests.Check(WindowsIdentity.RunImpersonated(normalToken, () => Directory.GetFileSystemEntries(emptyPath)).Length == 0, "The empty folder remained inaccessible after removal.");
            emptyItem.ProtectionPhase = "Removed";
            checks.Add("Remove restores original empty-folder permissions and audit settings without adding or moving contents");
            ContinueMigrationTests.Run(root, ownerSid, normalToken, checks);
            AtomicSaveTests.Run(root, ownerSid, normalToken, checks);
            RelocationTests.Run(root, ownerSid, normalToken, checks);
            await BrokerLiveTests.RunAsync(root, ownerSid, processId, checks);
            NativeAclTests.Check(persistenceCount >= 12, "Native transitions did not persist their recovery journal and access state.");
        }
        catch (Exception error) { errors.Add(error.ToString()); }
        finally
        {
            if (backend != null)
            {
                backendStatus = new { backend.Available, backend.PermissionAvailable, backend.UnavailableReason, FailureAuditingEnabled = SecurityNative.FailureAuditingEnabled() };
                while (backend.Notifications.TryDequeue(out var entry)) queuedAudits.Add(entry);
                try
                {
                    var query = new EventLogQuery("Security", PathType.LogName, "*[System[(EventID=4656) and TimeCreated[timediff(@SystemTime)<=120000]]]") { ReverseDirection = true };
                    using var reader = new EventLogReader(query);
                    for (var index = 0; index < 512; index++)
                    {
                        using var record = reader.ReadEvent();
                        if (record == null) break;
                        var xml = record.ToXml();
                        var document = XDocument.Parse(xml);
                        XNamespace ns = "http://schemas.microsoft.com/win/2004/08/events/event";
                        var eventPath = document.Root?.Element(ns + "EventData")?.Elements(ns + "Data").SingleOrDefault(field => field.Attribute("Name")?.Value == "ObjectName")?.Value;
                        if (eventPath != null && items.Any(item => SameAuditPath(eventPath, item.OriginalPath) || (item.Kind == ProtectionKind.Folder && AuditDescendant(eventPath, item.OriginalPath))))
                            auditEvents.Add(new { RecordId = record.RecordId, record.TimeCreated, Xml = xml, Parsed = AccessAuditListener.Parse(xml) });
                    }
                }
                catch (Exception diagnosticError) { diagnosticErrors.Add("Scoped Security log query: " + diagnosticError.Message); }
                foreach (var item in items.Where(item => item.ProtectionPhase != "Removed"))
                {
                    try { backend.Remove(item); item.ProtectionPhase = "Removed"; }
                    catch (Exception restoreError) { errors.Add("Fixture restoration requires the retained journal: " + restoreError); }
                }
                backend.Dispose();
            }
            File.WriteAllText(Path.Combine(root, "result.json"), JsonSerializer.Serialize(new { Passed = errors.Count == 0, Checks = checks, Errors = errors, PersistenceCount = persistenceCount, BackendStatus = backendStatus, QueuedAuditNotifications = queuedAudits, LockedSecurity = lockedSecurity, FixtureAuditEvents = auditEvents, DiagnosticErrors = diagnosticErrors, NormalProcessProbes = normalProcessProbes }, new JsonSerializerOptions { WriteIndented = true }));
        }
        return errors.Count == 0;
    }

    private static PermissionJournalEntry Clone(PermissionJournalEntry entry) => JsonSerializer.Deserialize<PermissionJournalEntry>(JsonSerializer.Serialize(entry))!;

    private sealed class ProbeResponse
    {
        public string Id { get; set; } = "";
        public string Operation { get; set; } = "";
        public bool Succeeded { get; set; }
        public bool ReadSucceeded { get; set; }
        public int? EntryCount { get; set; }
        public string? ErrorType { get; set; }
        public string? ErrorMessage { get; set; }
        public int? NativeErrorCode { get; set; }
        public uint ProcessId { get; set; }
    }

    private static async Task<ProbeResponse> ProbeNormalProcessAsync(string root, string content, string operation = "Read")
    {
        var id = Guid.NewGuid().ToString("N");
        var request = Path.Combine(root, "probe-request.json");
        var temporary = request + ".next";
        File.WriteAllText(temporary, JsonSerializer.Serialize(new { Id = id, Path = content, Operation = operation }));
        File.Move(temporary, request, overwrite: true);
        var responsePath = Path.Combine(root, "probe-response.json");
        var deadline = DateTimeOffset.UtcNow.AddSeconds(15);
        while (DateTimeOffset.UtcNow < deadline)
        {
            Stop.Token.ThrowIfCancellationRequested();
            try
            {
                if (File.Exists(responsePath) && new FileInfo(responsePath).Length < 16 * 1024)
                {
                    var response = JsonSerializer.Deserialize<ProbeResponse>(File.ReadAllText(responsePath));
                    if (response?.Id == id) return response;
                }
            }
            catch (IOException) { }
            catch (JsonException) { }
            await Task.Delay(50, Stop.Token);
        }
        throw new TimeoutException("The actual normal Windows parent process did not answer its fixture content probe.");
    }

    private static bool SameAuditPath(string audit, string dos) => NormalizeAuditPath(audit).Equals(NormalizeAuditPath(dos), StringComparison.OrdinalIgnoreCase);
    private static bool AuditDescendant(string audit, string dos) => NormalizeAuditPath(audit).StartsWith(NormalizeAuditPath(dos).TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase);
    private static string NormalizeAuditPath(string path)
    {
        if (path.StartsWith(@"\\?\", StringComparison.Ordinal)) path = path[4..];
        if (path.Length >= 3 && path[1] == ':')
        {
            var native = new StringBuilder(2048);
            if (QueryDosDevice(path[..2], native, (uint)native.Capacity) != 0) return native + path[2..];
        }
        return path;
    }

    internal static void SameSecurity(string originalBase64, string restoredBase64)
    {
        var original = new RawSecurityDescriptor(Convert.FromBase64String(originalBase64), 0);
        var restored = new RawSecurityDescriptor(Convert.FromBase64String(restoredBase64), 0);
        NativeAclTests.Check(original.Owner?.Value == restored.Owner?.Value && original.Group?.Value == restored.Group?.Value, "The original security owner/group was not restored.");
        foreach (var (left, right) in new[] { (original.DiscretionaryAcl, restored.DiscretionaryAcl), (original.SystemAcl, restored.SystemAcl) })
        {
            NativeAclTests.Check((left == null) == (right == null), "An absent original ACL was changed.");
            if (left == null) continue;
            var leftBytes = new byte[left.BinaryLength]; var rightBytes = new byte[right!.BinaryLength];
            left.GetBinaryForm(leftBytes, 0); right.GetBinaryForm(rightBytes, 0);
            NativeAclTests.Check(leftBytes.SequenceEqual(rightBytes), "The original permission/audit ACL was not restored exactly.");
        }
        var protection = ControlFlags.DiscretionaryAclProtected | ControlFlags.SystemAclProtected;
        NativeAclTests.Check((original.ControlFlags & protection) == (restored.ControlFlags & protection), "Original permission inheritance protection was not restored.");
    }

    private static void Denied<T>(SafeAccessTokenHandle token, Func<T> read)
    {
        try { WindowsIdentity.RunImpersonated(token, read); }
        catch (UnauthorizedAccessException) { return; }
        throw new InvalidOperationException("A normal Windows token accessed a locked original location.");
    }

    private static SafeAccessTokenHandle CallerToken(uint processId, string sid)
    {
        using var process = OpenProcess(0x1000, false, processId);
        if (process.IsInvalid || !OpenProcessToken(process, 0x000E, out var source)) throw new Win32Exception();
        using (source)
        {
            if (!DuplicateTokenEx(source, 0x02000000, IntPtr.Zero, 2, 2, out var token)) throw new Win32Exception();
            try
            {
                using var identity = new WindowsIdentity(token.DangerousGetHandle());
                if (identity.User?.Value != sid || identity.IsSystem || new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator))
                    throw new UnauthorizedAccessException("Start test-native.ps1 from a normal unelevated PowerShell session.");
                return token;
            }
            catch { token.Dispose(); throw; }
        }
    }

    [UnmanagedFunctionPointer(CallingConvention.Winapi)] private delegate void ServiceMainCallback(uint count, IntPtr arguments);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)] private delegate uint HandlerCallback(uint control, uint eventType, IntPtr eventData, IntPtr context);
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] private struct ServiceEntry { [MarshalAs(UnmanagedType.LPWStr)] public string? Name; public IntPtr Main; }
    [StructLayout(LayoutKind.Sequential)] private struct ServiceStatus { public uint Type, State, Controls, ExitCode, SpecificExitCode, CheckPoint, WaitHint; }
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool StartServiceCtrlDispatcher([In] ServiceEntry[] table);
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr RegisterServiceCtrlHandlerEx(string name, HandlerCallback callback, IntPtr context);
    [DllImport("advapi32.dll", SetLastError = true)] private static extern bool SetServiceStatus(IntPtr handle, ref ServiceStatus status);
    [DllImport("kernel32.dll", SetLastError = true)] private static extern SafeProcessHandle OpenProcess(uint access, bool inherit, uint processId);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern uint QueryDosDevice(string device, StringBuilder target, uint length);
    [DllImport("advapi32.dll", SetLastError = true)] private static extern bool OpenProcessToken(SafeProcessHandle process, uint access, out SafeAccessTokenHandle token);
    [DllImport("advapi32.dll", SetLastError = true)] private static extern bool DuplicateTokenEx(SafeAccessTokenHandle source, uint access, IntPtr attributes, int level, int type, out SafeAccessTokenHandle token);
}

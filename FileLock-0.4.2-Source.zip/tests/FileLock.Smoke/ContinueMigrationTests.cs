using System.Security.AccessControl;
using System.Security.Principal;
using System.Text.Json;
using System.Text.RegularExpressions;
using FileLock.Service;
using FileLock.Shared;
using Microsoft.Win32.SafeHandles;

// Runs inside the disposable native-test SYSTEM service. Replaying a saved
// journal must repair old/Continue-modified permissions without saving those
// weakened permissions as the user's original permissions.
internal static class ContinueMigrationTests
{
    internal static void Run(string suppliedRoot, string ownerSid, SafeAccessTokenHandle normalToken, List<string> checks)
    {
        var root = Path.GetFullPath(suppliedRoot).TrimEnd(Path.DirectorySeparatorChar);
        var fixture = new DirectoryInfo(root);
        if (!Regex.IsMatch(fixture.Name, "^native-[a-f0-9]{32}$") || fixture.Parent?.Name != ".work" || fixture.Parent.Parent?.Name != "tests")
            throw new InvalidOperationException("Permission migration tests require a fresh native integration fixture.");
        for (var parent = fixture; parent != null; parent = parent.Parent)
            if (parent.Attributes.HasFlag(FileAttributes.ReparsePoint)) throw new IOException("The migration fixture contains a reparse point.");
        using var system = WindowsIdentity.GetCurrent();
        if (!system.IsSystem) throw new UnauthorizedAccessException("Permission migration tests require the disposable SYSTEM service.");

        var path = Path.Combine(root, "continue-migration-folder");
        var nested = Path.Combine(path, "nested");
        var content = Path.Combine(nested, "child.txt");
        WindowsIdentity.RunImpersonated(normalToken, () =>
        {
            Directory.CreateDirectory(nested);
            File.WriteAllText(content, "Disposable old-permission migration fixture.");
        });
        using var before = SecurityNative.Open(path, "", captureSecurity: true);
        var item = new ItemState
        {
            Id = Guid.NewGuid().ToString(), Name = "continue-migration-folder", OriginalPath = path,
            OwnerSid = ownerSid, Kind = ProtectionKind.Folder, VolumeIdentity = before.Entry.VolumeIdentity,
            AddedUtc = DateTimeOffset.UtcNow
        };
        before.Dispose();
        var persistedJournal = "";
        void Persist()
        {
            persistedJournal = JsonSerializer.Serialize(item.PermissionJournal);
            File.WriteAllText(Path.Combine(root, "continue-migration-journal.json"), JsonSerializer.Serialize(item));
        }
        using var backend = new NativePathProtection(Persist);
        NativeAclTests.Check(backend.Available, "The migration backend is unavailable: " + backend.UnavailableReason);
        var prepared = false;
        try
        {
            backend.Prepare(item);
            prepared = true;
            Persist();
            var originalJournal = persistedJournal;
            NativeAclTests.Check(item.PermissionJournal.Count == 3, "The migration fixture journal omitted its nested directory or file.");

            // Reproduce the exact old allow-list: SYSTEM and Administrators
            // FullControl, with only metadata rights for the unelevated owner.
            SetLegacyPermissions(item, ownerSid, ownerFullControl: false);
            item.ProtectionPhase = "Locked";
            Persist();
            AssertDenied(normalToken, path, nested, content);
            backend.Upsert(item); // The broker uses this operation at startup.
            AssertHardened(item, normalToken, path, nested, content);
            AssertJournalUnchanged(item, originalJournal, persistedJournal);
            checks.Add("Upgrade replay hardens the old 0.3 folder and every descendant without changing the original permission journal");

            // Continue granted access outside FileLock; the broker's saved
            // phase remains Locked and its original journal must be retained.
            SetLegacyPermissions(item, ownerSid, ownerFullControl: true);
            NativeAclTests.Check(WindowsIdentity.RunImpersonated(normalToken, () => File.ReadAllText(content)).Length > 0,
                "The disposable Continue-modified permissions did not reproduce the old access bypass.");
            backend.Upsert(item);
            AssertHardened(item, normalToken, path, nested, content);
            AssertJournalUnchanged(item, originalJournal, persistedJournal);
            checks.Add("Upgrade replay removes a previous Continue permission grant from the original folder and all descendants");

            backend.Grant(item, 1, 300);
            NativeAclTests.Check(WindowsIdentity.RunImpersonated(normalToken, () => Directory.GetFileSystemEntries(path)).Length == 1
                && WindowsIdentity.RunImpersonated(normalToken, () => File.ReadAllText(content)).Length > 0,
                "Approved access did not restore the migrated folder and contents.");
            NativeAclTests.Check(item.ProtectionPhase == "Open" && item.ActiveLeaseUntilUtc > DateTimeOffset.UtcNow,
                "The migration fixture did not record its approved access lease.");
            backend.Upsert(item); // Restart must close an existing Open lease.
            AssertHardened(item, normalToken, path, nested, content);
            AssertJournalUnchanged(item, originalJournal, persistedJournal);
            checks.Add("Upgrade replay closes an existing approved access lease and retains recoverable original permissions");

            backend.Remove(item);
            AssertOriginalPermissions(item);
            NativeAclTests.Check(WindowsIdentity.RunImpersonated(normalToken, () => File.ReadAllText(content)).Length > 0,
                "Removing the migrated fixture did not restore normal access.");
            prepared = false;
            checks.Add("Removing a migrated item restores its exact original owner, group, permission ACL, and audit ACL");
        }
        finally
        {
            if (prepared) backend.Remove(item);
        }
    }

    private static void SetLegacyPermissions(ItemState item, string ownerSid, bool ownerFullControl)
    {
        foreach (var saved in item.PermissionJournal)
        {
            var path = saved.RelativePath.Length == 0 ? item.OriginalPath : Path.Combine(item.OriginalPath, saved.RelativePath);
            using var target = SecurityNative.Open(path, saved.RelativePath, captureSecurity: false);
            NativeAclTests.Check(SecurityNative.IdentityMatches(saved, target.Entry), "The migration fixture changed identity.");
            var descriptor = SecurityNative.LockedDescriptor(saved, ownerSid);
            var inheritance = saved.IsDirectory ? AceFlags.ContainerInherit | AceFlags.ObjectInherit : AceFlags.None;
            var dacl = new RawAcl(2, 3);
            dacl.InsertAce(0, new CommonAce(inheritance, AceQualifier.AccessAllowed, 0x1F01FF, new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), false, null));
            dacl.InsertAce(1, new CommonAce(inheritance, AceQualifier.AccessAllowed, 0x1F01FF, new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null), false, null));
            dacl.InsertAce(2, new CommonAce(inheritance, AceQualifier.AccessAllowed, ownerFullControl ? 0x1F01FF : 0x120080, new SecurityIdentifier(ownerSid), false, null));
            descriptor.DiscretionaryAcl = dacl;
            SecurityNative.WriteDescriptor(target.Handle, descriptor);
        }
    }

    private static void AssertHardened(ItemState item, SafeAccessTokenHandle normalToken, string path, string nested, string content)
    {
        NativeAclTests.Check(item.ProtectionPhase == "Locked" && item.ActiveLeaseUntilUtc == null && item.ProtectionError == null,
            "Migration replay did not finish in a locked state without an access window.");
        var systemSid = new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null).Value;
        foreach (var saved in item.PermissionJournal)
        {
            var currentPath = saved.RelativePath.Length == 0 ? path : Path.Combine(path, saved.RelativePath);
            using var target = SecurityNative.Open(currentPath, saved.RelativePath, captureSecurity: true);
            var descriptor = new RawSecurityDescriptor(Convert.FromBase64String(target.Entry.OriginalSecurityDescriptor), 0);
            NativeAclTests.Check(SecurityNative.IdentityMatches(saved, target.Entry) && descriptor.Owner?.Value == systemSid
                && descriptor.ControlFlags.HasFlag(ControlFlags.DiscretionaryAclProtected),
                "Migration did not preserve identity and establish a protected SYSTEM-owned permission ACL.");
            foreach (var ace in descriptor.DiscretionaryAcl!.OfType<QualifiedAce>())
                if (ace.AceQualifier == AceQualifier.AccessAllowed && (ace.AccessMask & SecurityNative.ContentAccessMask) != 0)
                    NativeAclTests.Check(ace.SecurityIdentifier.Value == systemSid,
                        "Migration left content or permission-change access for a principal other than the SYSTEM broker.");
        }
        AssertDenied(normalToken, path, nested, content);
        Denied(normalToken, () =>
        {
            var directory = new DirectoryInfo(path);
            var permissions = directory.GetAccessControl(AccessControlSections.Access);
            permissions.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(item.OwnerSid), FileSystemRights.FullControl, AccessControlType.Allow));
            directory.SetAccessControl(permissions);
        });
    }

    private static void AssertDenied(SafeAccessTokenHandle normalToken, string path, string nested, string content)
    {
        Denied(normalToken, () => Directory.GetFileSystemEntries(path));
        Denied(normalToken, () => Directory.GetFileSystemEntries(nested));
        Denied(normalToken, () => File.ReadAllText(content));
    }

    private static void Denied(SafeAccessTokenHandle normalToken, Action action)
    {
        try { WindowsIdentity.RunImpersonated(normalToken, action); }
        catch (UnauthorizedAccessException) { return; }
        throw new InvalidOperationException("A normal Windows token accessed migrated locked contents or changed its permissions.");
    }

    private static void AssertJournalUnchanged(ItemState item, string original, string persisted)
    {
        NativeAclTests.Check(original == JsonSerializer.Serialize(item.PermissionJournal) && original == persisted,
            "Migration replaced the durable original permission journal with locked or Continue-modified permissions.");
    }

    private static void AssertOriginalPermissions(ItemState item)
    {
        foreach (var saved in item.PermissionJournal)
        {
            var path = saved.RelativePath.Length == 0 ? item.OriginalPath : Path.Combine(item.OriginalPath, saved.RelativePath);
            using var target = SecurityNative.Open(path, saved.RelativePath, captureSecurity: true);
            NativeAclTests.Check(SecurityNative.IdentityMatches(saved, target.Entry), "Migration restoration changed a file identity.");
            var original = new RawSecurityDescriptor(Convert.FromBase64String(saved.OriginalSecurityDescriptor), 0);
            var restored = new RawSecurityDescriptor(Convert.FromBase64String(target.Entry.OriginalSecurityDescriptor), 0);
            NativeAclTests.Check(original.Owner?.Value == restored.Owner?.Value && original.Group?.Value == restored.Group?.Value,
                "Migration removal changed the original owner/group.");
            foreach (var (left, right) in new[] { (original.DiscretionaryAcl, restored.DiscretionaryAcl), (original.SystemAcl, restored.SystemAcl) })
            {
                NativeAclTests.Check((left == null) == (right == null), "Migration removal changed an absent original ACL.");
                if (left == null) continue;
                var originalBytes = new byte[left.BinaryLength];
                var restoredBytes = new byte[right!.BinaryLength];
                left.GetBinaryForm(originalBytes, 0);
                right.GetBinaryForm(restoredBytes, 0);
                NativeAclTests.Check(originalBytes.SequenceEqual(restoredBytes), "Migration removal did not restore an original permission/audit ACL exactly.");
            }
            const ControlFlags protection = ControlFlags.DiscretionaryAclProtected | ControlFlags.SystemAclProtected;
            NativeAclTests.Check((original.ControlFlags & protection) == (restored.ControlFlags & protection),
                "Migration removal changed original ACL inheritance protection.");
        }
    }
}

using System.Text;
using System.Text.Json;
using System.Security.Cryptography;
using FileLock.Service;
using FileLock.Shared;

internal static class Program
{
    private static async Task<int> Main(string[] args)
    {
        if (args.Length > 0 && args[0] == "--native-service") return NativeLiveTests.RunService(args);
        var tests = new (string Name, Func<Task> Run)[]
        {
            ("Six ASCII digits, including zero-prefixed PINs", SixDigitPinsAsync),
            ("PIN verifiers reject wrong PINs and different service secrets", PinVerifiersAsync),
            ("Recovery rejects wrong keys, tampering, and rotated keys", RecoveryAsync),
            ("Policy path boundaries reject aliases and namespace escapes", PathPolicyAsync),
            ("Folder open requests resolve only journaled original locations", FolderRequestsAsync),
            ("Locked permissions preserve the recovery journal and scope access", NativeAclTests.DescriptorAsync),
            ("Native permission journals bind restoration to file identity", NativeAclTests.JournalAsync),
            ("Access diagnostics parse only content-denial audit events", NativeAclTests.AuditAsync),
            ("Local pipe framing handles Unicode and consecutive messages", FramingAsync),
            ("Oversized and incomplete pipe messages fail closed", MessageBoundsAsync),
            ("Canceled pipe reads terminate", CancellationAsync)
        };
        var failures = 0;
        foreach (var test in tests)
        {
            try
            {
                await test.Run();
                Console.WriteLine($"PASS {test.Name}");
            }
            catch (Exception error)
            {
                failures++;
                Console.Error.WriteLine($"FAIL {test.Name}: {error}");
            }
        }
        Console.WriteLine($"{tests.Length - failures}/{tests.Length} user-mode checks passed. Run scripts/test-native.ps1 to verify live NTFS enforcement and silent access diagnostics.");
        return failures == 0 ? 0 : 1;
    }

    private static Task SixDigitPinsAsync()
    {
        foreach (var pin in new[] { "123456", "000001", "000000", "999999" })
        {
            Check(PinRules.IsValid(pin), "Valid six-digit PIN rejected.");
            PinRules.Ensure(pin);
        }
        foreach (var invalid in new string?[] { null, "", "12345", "1234567", "12a456", "１２３４５６", "١٢٣٤٥٦", "12345 ", " 12345", "12345\n" })
        {
            Check(!PinRules.IsValid(invalid), "Invalid PIN accepted.");
            Rejects<ArgumentException>(() => PinRules.Ensure(invalid));
        }
        return Task.CompletedTask;
    }

    private static async Task FramingAsync()
    {
        using var stream = new MemoryStream();
        var first = new BrokerRequest { Operation = "Add", Path = "C:\\සිංහල\\日本語😀.txt", Kind = ProtectionKind.File };
        await BrokerProtocol.WriteLineAsync(stream, first, CancellationToken.None);
        await BrokerProtocol.WriteLineAsync(stream, new BrokerRequest { Operation = "Status" }, CancellationToken.None);
        stream.Position = 0;
        var readFirst = JsonSerializer.Deserialize<BrokerRequest>(await BrokerProtocol.ReadLineAsync(stream, CancellationToken.None), BrokerProtocol.JsonOptions)!;
        var readSecond = JsonSerializer.Deserialize<BrokerRequest>(await BrokerProtocol.ReadLineAsync(stream, CancellationToken.None), BrokerProtocol.JsonOptions)!;
        Check(readFirst.Path == first.Path && readFirst.Kind == first.Kind, "Pipe framing changed Unicode path or kind.");
        Check(readSecond.Operation == "Status" && stream.Position == stream.Length, "First frame consumed the next frame.");
    }

    private static Task PinVerifiersAsync()
    {
        var secret = RandomNumberGenerator.GetBytes(32);
        var differentSecret = RandomNumberGenerator.GetBytes(32);
        try
        {
            var stored = PasscodeStore.Create("000001", secret);
            var separate = PasscodeStore.Create("000001", secret);
            Check(stored != separate, "Creating the same PIN twice reused a verifier.");
            Check(PasscodeStore.Verify("000001", stored.Salt, stored.Hash, secret), "Correct PIN was rejected.");
            Check(!PasscodeStore.Verify("000002", stored.Salt, stored.Hash, secret), "Wrong PIN was accepted.");
            Check(!PasscodeStore.Verify("000001", stored.Salt, stored.Hash, differentSecret), "A verifier accepted another service secret.");
            Check(!PasscodeStore.Verify("０００００１", stored.Salt, stored.Hash, secret), "Non-ASCII PIN was accepted.");
            var changed = PasscodeStore.Create("654321", secret);
            Check(!PasscodeStore.Verify("000001", changed.Salt, changed.Hash, secret), "Old PIN accepted a replacement verifier.");
            Check(PasscodeStore.Verify("654321", changed.Salt, changed.Hash, secret), "Replacement PIN was rejected.");
        }
        finally
        {
            CryptographicOperations.ZeroMemory(secret);
            CryptographicOperations.ZeroMemory(differentSecret);
        }
        return Task.CompletedTask;
    }

    private static Task RecoveryAsync()
    {
        var secret = RandomNumberGenerator.GetBytes(32);
        var differentSecret = RandomNumberGenerator.GetBytes(32);
        try
        {
            var original = PasscodeStore.CreateRecovery(secret);
            Check(PasscodeStore.VerifyRecovery(original.Key, original.Envelope, secret), "Correct recovery key was rejected.");
            Check(PasscodeStore.VerifyRecovery(original.Key.ToLowerInvariant().Replace("-", " "), original.Envelope, secret), "Readable recovery-key formatting was rejected.");
            Check(!PasscodeStore.VerifyRecovery(null, original.Envelope, secret), "Missing recovery key was accepted.");
            Check(!PasscodeStore.VerifyRecovery(new string('0', 64), original.Envelope, secret), "Wrong recovery key was accepted.");
            Check(!PasscodeStore.VerifyRecovery(original.Key, original.Envelope, differentSecret), "Recovery key authenticated another user secret.");
            var bytes = Convert.FromBase64String(original.Envelope);
            bytes[^1] ^= 1;
            Check(!PasscodeStore.VerifyRecovery(original.Key, Convert.ToBase64String(bytes), secret), "A tampered recovery envelope was accepted.");
            Check(!PasscodeStore.VerifyRecovery(original.Key, "invalid-base64", secret), "An invalid envelope was accepted.");
            var rotated = PasscodeStore.CreateRecovery(secret);
            Check(rotated.Key != original.Key, "Recovery key rotation reused the key.");
            Check(!PasscodeStore.VerifyRecovery(original.Key, rotated.Envelope, secret), "Old recovery key accepted a rotated envelope.");
            Check(PasscodeStore.VerifyRecovery(rotated.Key, rotated.Envelope, secret), "New recovery key was rejected.");
        }
        finally
        {
            CryptographicOperations.ZeroMemory(secret);
            CryptographicOperations.ZeroMemory(differentSecret);
        }
        return Task.CompletedTask;
    }

    private static Task PathPolicyAsync()
    {
        Check(PathPolicy.Overlaps(@"C:\private", @"c:\PRIVATE\nested\file.txt"), "A descendant bypassed the folder boundary.");
        Check(PathPolicy.Overlaps(@"C:\private\nested", @"C:\private"), "An ancestor did not overlap a rule.");
        Check(PathPolicy.Overlaps(@"C:\private\", @"C:\private"), "A trailing separator bypassed overlap detection.");
        Check(!PathPolicy.Overlaps(@"C:\private", @"C:\private-other\file.txt"), "A same-prefix sibling was treated as protected.");
        Check(!PathPolicy.Overlaps(@"C:\private", @"D:\private"), "Rules crossed drive boundaries.");
        Check(PathPolicy.IsValidNtPath(@"\Device\HarddiskVolume3\සිංහල\file.txt"), "A valid canonical device path was rejected.");
        foreach (var invalid in new[]
        {
            @"\Device\HarddiskVolume3", @"\Device\HarddiskVolume3\", @"\Device\HarddiskVolumeX\file.txt",
            @"\Device\HarddiskVolume3\..\file.txt", @"\Device\HarddiskVolume3\folder\\file.txt",
            @"\Device\HarddiskVolume3\file.txt:stream", @"\Device\HarddiskVolume3/folder/file.txt",
            @"\??\C:\file.txt", @"C:\file.txt", @"\Device\Mup\server\file.txt"
        }) Check(!PathPolicy.IsValidNtPath(invalid), "Unsupported device path accepted: " + invalid);
        foreach (var invalid in new[]
        {
            "", @"\\server\share\file.txt", @"\\?\C:\file.txt", @"C:relative.txt", @"C:\folder\..\file.txt",
            @"C:\file.txt:stream", @"C:\folder.\file.txt", @"C:\folder \file.txt", "C:/folder/file.txt"
        }) Rejects<GateException>(() => PathPolicy.Validate(invalid, ProtectionKind.File, "S-1-5-21-0"));
        return Task.CompletedTask;
    }

    private static Task FolderRequestsAsync()
    {
        Check(BrokerEngine.NormalizeRequestedPath(@"C:\private\nested\..\") == @"C:\private", "An absolute folder request was not canonicalized.");
        Check(BrokerEngine.NormalizeRequestedPath(@"c:\PRIVATE\nested\") == @"c:\PRIVATE\nested", "A normal trailing directory separator was not removed.");
        foreach (var invalid in new string?[] { null, "", " ", @"private\nested", @"C:private\nested", @"\\?\C:\private", @"\\.\C:\private", "C:\\private\"folder", @"C:\" + new string('x', 2048) })
            Rejects<GateException>(() => BrokerEngine.NormalizeRequestedPath(invalid));
        var folder = new ItemState
        {
            Kind = ProtectionKind.Folder,
            OriginalPath = @"C:\private",
            PermissionJournal =
            [
                new() { RelativePath = "" },
                new() { RelativePath = "nested" },
                new() { RelativePath = @"nested\child.txt" }
            ]
        };
        Check(BrokerEngine.MatchesOriginalPath(folder, @"c:\PRIVATE"), "The original folder root failed to match.");
        Check(BrokerEngine.MatchesOriginalPath(folder, @"C:\private\nested"), "A journaled nested folder failed to match.");
        Check(BrokerEngine.MatchesOriginalPath(folder, @"c:\PRIVATE\NESTED\CHILD.TXT"), "A concrete journaled descendant failed to match.");
        foreach (var denied in new[] { @"C:\private-other\nested", @"C:\private\unlisted.txt", @"D:\private\nested", @"C:\other\child.txt" })
            Check(!BrokerEngine.MatchesOriginalPath(folder, denied), "A folder request resolved an unprotected or unjournaled location: " + denied);
        var file = new ItemState { Kind = ProtectionKind.File, OriginalPath = @"C:\private\file.txt" };
        Check(BrokerEngine.MatchesOriginalPath(file, file.OriginalPath), "An original file request failed to match.");
        Check(!BrokerEngine.MatchesOriginalPath(file, @"C:\private\file.txt\child") && !BrokerEngine.MatchesOriginalPath(file, @"C:\private\other.txt"), "A file request resolved another file or a fake descendant.");
        return Task.CompletedTask;
    }

    private static async Task MessageBoundsAsync()
    {
        using var atLimit = new MemoryStream(Encoding.UTF8.GetBytes(new string('x', BrokerProtocol.MaximumMessageBytes - 1) + "\n"));
        Check((await BrokerProtocol.ReadLineAsync(atLimit, CancellationToken.None)).Length == BrokerProtocol.MaximumMessageBytes - 1, "Maximum valid frame rejected.");
        using var oversized = new MemoryStream(Encoding.UTF8.GetBytes(new string('x', BrokerProtocol.MaximumMessageBytes) + "\n"));
        await RejectsAsync<IOException>(() => BrokerProtocol.ReadLineAsync(oversized, CancellationToken.None));
        using var incomplete = new MemoryStream(Encoding.UTF8.GetBytes("{\"Operation\":\"Status\"}"));
        await RejectsAsync<IOException>(() => BrokerProtocol.ReadLineAsync(incomplete, CancellationToken.None));
        using var destination = new MemoryStream();
        await RejectsAsync<IOException>(() => BrokerProtocol.WriteLineAsync(destination,
            new BrokerResponse { Ok = true, Error = new string('x', BrokerProtocol.MaximumMessageBytes) }, CancellationToken.None));
        Check(destination.Length == 0, "Oversized response left a partial frame.");
    }

    private static async Task CancellationAsync()
    {
        using var stream = new MemoryStream(new byte[] { 1 });
        using var cancellation = new CancellationTokenSource();
        cancellation.Cancel();
        await RejectsAsync<OperationCanceledException>(() => BrokerProtocol.ReadLineAsync(stream, cancellation.Token));
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private static void Rejects<T>(Action action) where T : Exception
    {
        try { action(); }
        catch (T) { return; }
        throw new InvalidOperationException($"Expected {typeof(T).Name}.");
    }

    private static async Task RejectsAsync<T>(Func<Task> action) where T : Exception
    {
        try { await action(); }
        catch (T) { return; }
        throw new InvalidOperationException($"Expected {typeof(T).Name}.");
    }
}

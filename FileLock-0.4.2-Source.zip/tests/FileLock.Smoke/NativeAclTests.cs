using System.Security.AccessControl;
using System.Security.Principal;
using System.Text.Json;
using FileLock.Service;

internal static class NativeAclTests
{
    private const string Owner = "S-1-5-21-1000-2000-3000-1001";

    internal static Task DescriptorAsync()
    {
        foreach (var directory in new[] { false, true })
        {
            var original = new RawSecurityDescriptor("O:" + Owner + "G:SYD:PAI(A;;FA;;;" + Owner + ")(D;;FW;;;BU)S:(AU;SA;FR;;;WD)");
            var originalBytes = Binary(original);
            var entry = new PermissionJournalEntry
            {
                IsDirectory = directory,
                OriginalSecurityDescriptor = Convert.ToBase64String(originalBytes)
            };
            var locked = SecurityNative.LockedDescriptor(entry, Owner);
            Check(locked.Owner?.IsWellKnown(WellKnownSidType.LocalSystemSid) == true, "The locked owner can still replace the DACL.");
            Check(locked.Group?.Value == original.Group?.Value, "The original primary group was lost.");
            Check(locked.ControlFlags.HasFlag(ControlFlags.DiscretionaryAclProtected) && locked.ControlFlags.HasFlag(ControlFlags.SystemAclProtected), "Parent permission inheritance can bypass the locked descriptor.");
            Check(locked.DiscretionaryAcl?.Count == 2, "The locked descriptor grants unexpected principals access.");
            var grants = locked.DiscretionaryAcl!.Cast<CommonAce>().ToArray();
            Check(grants[0].SecurityIdentifier.IsWellKnown(WellKnownSidType.LocalSystemSid) && grants[0].AccessMask == 0x1F01FF, "SYSTEM recovery access is missing.");
            Check(!grants.Any(ace => ace.SecurityIdentifier.IsWellKnown(WellKnownSidType.BuiltinAdministratorsSid)), "An elevated Explorer Continue helper can bypass the lock through an Administrators grant.");
            Check(grants[1].SecurityIdentifier.Value == Owner && (grants[1].AccessMask & SecurityNative.ContentAccessMask) == 0, "The owner can read contents, execute, write, or change permissions while locked.");
            Check(grants[1].AccessMask == 0x120080, "The metadata grant changed unexpectedly.");
            var inheritance = directory ? AceFlags.ContainerInherit | AceFlags.ObjectInherit : AceFlags.None;
            Check(grants.All(ace => ace.AceFlags == inheritance), "A file/folder grant has incorrect inheritance.");
            Check(locked.SystemAcl?.Count == 2, "The original audit rule was discarded.");
            Check(Binary(locked.SystemAcl![0]).SequenceEqual(Binary(original.SystemAcl![0])), "The original audit ACE changed.");
            var audit = (CommonAce)locked.SystemAcl[1];
            Check(audit.SecurityIdentifier.Value == Owner && audit.AccessMask == SecurityNative.ContentAccessMask && audit.AceFlags == (inheritance | AceFlags.FailedAccess), "The failure audit rule is not limited to the protected owner and content access.");
            Check(Convert.FromBase64String(entry.OriginalSecurityDescriptor).SequenceEqual(originalBytes), "Creating a lock modified the restoration journal.");
        }
        return Task.CompletedTask;
    }

    internal static Task JournalAsync()
    {
        var descriptor = new RawSecurityDescriptor("O:" + Owner + "G:SYD:(A;;FA;;;" + Owner + ")");
        var entry = new PermissionJournalEntry
        {
            RelativePath = @"සිංහල\日本語.txt", VolumeIdentity = @"\\?\Volume{00112233-4455-6677-8899-aabbccddeeff}",
            FileIdentity = "00112233:0000000000001234", OriginalSecurityDescriptor = Convert.ToBase64String(Binary(descriptor)), IsDirectory = false
        };
        var restored = JsonSerializer.Deserialize<PermissionJournalEntry>(JsonSerializer.Serialize(entry))!;
        Check(restored.RelativePath == entry.RelativePath && restored.OriginalSecurityDescriptor == entry.OriginalSecurityDescriptor && SecurityNative.IdentityMatches(entry, restored), "Journal serialization lost the path, descriptor, or stable identity.");
        restored.VolumeIdentity = restored.VolumeIdentity.ToUpperInvariant();
        Check(SecurityNative.IdentityMatches(entry, restored), "Volume identity comparison became case-sensitive.");
        restored.FileIdentity = "00112233:0000000000009999";
        Check(!SecurityNative.IdentityMatches(entry, restored), "A replacement object accepted the previous object's permissions.");
        restored.FileIdentity = entry.FileIdentity;
        restored.VolumeIdentity += "other";
        Check(!SecurityNative.IdentityMatches(entry, restored), "A different volume accepted the previous permissions.");
        restored.VolumeIdentity = entry.VolumeIdentity;
        restored.IsDirectory = true;
        Check(!SecurityNative.IdentityMatches(entry, restored), "A different object kind accepted the previous permissions.");
        return Task.CompletedTask;
    }

    internal static Task AuditAsync()
    {
        var xml = "<Event xmlns='http://schemas.microsoft.com/win/2004/08/events/event'><System><EventID>4656</EventID><Keywords>0x8010000000000000</Keywords></System><EventData><Data Name='ObjectType'>File</Data><Data Name='AccessMask'>0x1</Data><Data Name='SubjectUserSid'>" + Owner + "</Data><Data Name='ObjectName'>C:\\සිංහල\\日本語.txt</Data><Data Name='ProcessId'>0x0</Data></EventData></Event>";
        var parsed = AccessAuditListener.Parse(xml);
        Check(parsed?.OwnerSid == Owner && parsed.Path == @"C:\සිංහල\日本語.txt" && parsed.ProcessId == 0, "A valid content-denial event was lost or changed.");
        foreach (var invalid in new[]
        {
            xml.Replace("4656", "4663"), xml.Replace("0x8010000000000000", "0x8020000000000000"),
            xml.Replace(">File<", ">Key<"), xml.Replace("0x1<", "0x80<"),
            xml.Replace(Owner, "invalid-sid"), new string('x', 65537)
        }) Check(AccessAuditListener.Parse(invalid) == null, "An unrelated audit record triggered a passcode prompt.");
        try
        {
            AccessAuditListener.Parse("<!DOCTYPE Event [<!ENTITY payload SYSTEM 'file:///C:/Windows/win.ini'>]><Event>&payload;</Event>");
            throw new InvalidOperationException("An audit XML external entity was accepted.");
        }
        catch (System.Xml.XmlException) { }
        return Task.CompletedTask;
    }

    private static byte[] Binary(GenericSecurityDescriptor descriptor) { var bytes = new byte[descriptor.BinaryLength]; descriptor.GetBinaryForm(bytes, 0); return bytes; }
    private static byte[] Binary(GenericAce ace) { var bytes = new byte[ace.BinaryLength]; ace.GetBinaryForm(bytes, 0); return bytes; }
    internal static void Check(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
}

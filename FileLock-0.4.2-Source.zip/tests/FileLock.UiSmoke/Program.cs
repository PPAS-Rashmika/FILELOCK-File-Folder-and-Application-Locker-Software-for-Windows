using System.Reflection;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Windows.Markup;
using System.Xml.Linq;
using FileLock;
using FileLock.Shared;

internal static class Program
{
    private static int _passed;
    private static Exception? _failure;

    [STAThread]
    private static int Main()
    {
        var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
        // Load the production theme without instantiating App: WPF would queue
        // its real startup until the modal dialog's first dispatcher frame.
        XNamespace presentation = "http://schemas.microsoft.com/winfx/2006/xaml/presentation";
        var themeSource = XDocument.Load(Path.Combine(AppContext.BaseDirectory, "AppTheme.xaml"));
        var resources = themeSource.Root!.Elements().Single(element => element.Name.LocalName == "Application.Resources");
        var theme = new XElement(presentation + "ResourceDictionary",
            new XAttribute(XNamespace.Xmlns + "x", "http://schemas.microsoft.com/winfx/2006/xaml"),
            resources.Elements().Select(element => new XElement(element)));
        app.Resources = (ResourceDictionary)XamlReader.Parse(theme.ToString());
        var manager = new MainWindow(preview: true);
        app.MainWindow = manager;
        try
        {
            TestWrongThenCorrect(manager);
            TestCancel(manager);
            TestExpiredApproval(manager);
            TestRequestedPath();
            TestRebasedRequestedPath();
            TestActivationProtocol();
            _passed += PinChoiceTests.Run();
            _passed += ManagerAccessGateTests.Run(manager);
            manager.Hide();
            _passed += ProtectedUseTests.Run();
            _passed += AuditPopupTests.Run(manager);
            _passed += ProtectedOpenTargetTests.Run();
            _passed += FileShellCommandTests.Run();
            Console.WriteLine($"PASS: {_passed} UI regression checks; no real protected items or service state used.");
            return 0;
        }
        catch (Exception error) { Console.Error.WriteLine(error); return 1; }
        finally { app.Shutdown(); }
    }

    private static void TestWrongThenCorrect(MainWindow manager)
    {
        var opened = new List<string>();
        var attempts = 0;
        ScheduleDialog(dialog =>
        {
            Check(!manager.IsVisible && dialog.Owner is null && dialog.ShowInTaskbar, "Automatic prompt is independent of the hidden manager");
            Check(Application.Current.Windows.Cast<Window>().Count(window => window.IsVisible) == 1, "Only the passcode dialog is visible");
            SetPinAndSubmit(dialog, "000000");
            Check(dialog.IsVisible && Get<PasswordBox>(dialog, "_pin").Password.Length == 0 && opened.Count == 0,
                "Wrong PIN leaves the prompt open, clears input and never opens the item");
            SetPinAndSubmit(dialog, "123456");
        });
        var approved = AccessPrompt.Show(null, "Disposable folder", pin =>
        {
            attempts++;
            if (pin != "123456") throw new GateException("Incorrect six-digit passcode.");
            return Task.FromResult(new ProtectedItem { OriginalPath = @"C:\fixture\folder", IsOpen = true, UnlockedUntilUtc = DateTimeOffset.UtcNow.AddMinutes(5) });
        }, granted => opened.Add(granted.OriginalPath));
        ThrowFailure();
        Check(approved && attempts == 2 && opened.SequenceEqual([@"C:\fixture\folder"]), "Correct PIN opens the broker-approved original location exactly once");
        Check(!manager.IsVisible, "Approval does not open the management window");
    }

    private static void TestCancel(MainWindow manager)
    {
        var attempts = 0;
        var opened = 0;
        ScheduleDialog(dialog => Get<Button>(dialog, "_cancel").RaiseEvent(new RoutedEventArgs(Button.ClickEvent)));
        var approved = AccessPrompt.Show(null, "Disposable folder", _ => { attempts++; throw new Exception("Cancel must not verify."); }, _ => opened++);
        ThrowFailure();
        Check(!approved && attempts == 0 && opened == 0 && !manager.IsVisible, "Cancel does not verify, open the item or show the manager");
    }

    private static void TestExpiredApproval(MainWindow manager)
    {
        var opened = 0;
        ScheduleDialog(dialog =>
        {
            SetPinAndSubmit(dialog, "123456");
            Check(dialog.IsVisible && opened == 0, "A closed or expired access grant cannot open the original item");
            Get<Button>(dialog, "_cancel").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        });
        var approved = AccessPrompt.Show(null, "Disposable folder", _ => Task.FromResult(new ProtectedItem
        {
            OriginalPath = @"C:\fixture\folder", IsOpen = true, UnlockedUntilUtc = DateTimeOffset.UtcNow.AddSeconds(-1)
        }), _ => opened++);
        ThrowFailure();
        Check(!approved && opened == 0 && !manager.IsVisible, "Rejected grant remains canceled without a management window");
    }

    private static void TestRequestedPath()
    {
        var granted = new ProtectedItem { OriginalPath = @"C:\fixture\folder", Kind = ProtectionKind.Folder };
        Check(AccessPrompt.ValidateRequestedPath(granted, @"C:\fixture\folder\subfolder") == @"C:\fixture\folder\subfolder",
            "Approved nested folders reopen the requested original location");
        foreach (var invalid in new[] { @"C:\fixture\folder-other", @"C:\fixture\folder\..\outside" })
        {
            try { AccessPrompt.ValidateRequestedPath(granted, invalid); throw new InvalidOperationException("An unrelated path was accepted."); }
            catch (IOException) { }
        }
        Check(true, "Sibling-prefix and parent traversal cannot escape the approved folder");
    }

    private static void TestRebasedRequestedPath()
    {
        var granted = new ProtectedItem { OriginalPath = @"C:\fixture\renamed folder", Kind = ProtectionKind.Folder };
        const string previousRoot = @"C:\fixture\old folder";
        Check(AccessPrompt.RebaseRequestedPath(granted, previousRoot, previousRoot) == granted.OriginalPath,
            "A folder renamed while entering its PIN opens the broker-approved new root");
        Check(AccessPrompt.RebaseRequestedPath(granted, previousRoot + @"\subfolder\සිංහල", previousRoot)
                == granted.OriginalPath + @"\subfolder\සිංහල",
            "A moved-root approval preserves the requested nested folder beneath its new root");
        foreach (var outside in new[] { previousRoot + "-other", previousRoot + @"\..\outside", @"D:\fixture\old folder" })
        {
            try { AccessPrompt.RebaseRequestedPath(granted, outside, previousRoot); throw new InvalidOperationException("Rebasing accepted a folder outside the cached root."); }
            catch (IOException) { }
        }
        Check(true, "Rebasing rejects sibling prefixes, parent traversal and unrelated-drive requests");
    }

    private static void TestActivationProtocol()
    {
        using var stream = new MemoryStream();
        DesktopActivation.WriteAsync(stream, new() { Operation = "open", Path = @"C:\fixture\සිංහල folder" }, CancellationToken.None).GetAwaiter().GetResult();
        stream.Position = 0;
        var request = DesktopActivation.ReadAsync(stream, CancellationToken.None).GetAwaiter().GetResult();
        Check(request.Operation == "open" && request.Path == @"C:\fixture\සිංහල folder", "Bounded activation preserves Unicode folder paths");
        foreach (var invalid in new[] { "relative\\folder", "C:\\fixture\nfolder", @"\\.\pipe\unsafe", "C:\\fixture\\\"quoted" })
        {
            try { DesktopActivation.NormalizeOpenPath(invalid); throw new InvalidOperationException("An unsafe activation path was accepted."); }
            catch (ArgumentException) { }
        }
        Check(true, "Shell activation rejects relative, control-character and device paths");
        using var oversized = new MemoryStream(Enumerable.Repeat((byte)'a', DesktopActivation.MaximumMessageBytes).ToArray());
        try { DesktopActivation.ReadAsync(oversized, CancellationToken.None).GetAwaiter().GetResult(); throw new InvalidOperationException("Oversized activation accepted."); }
        catch (IOException) { }
        Check(true, "An oversized activation request is bounded before JSON parsing");
    }

    private static void ScheduleDialog(Action<PinDialog> action)
    {
        Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
        {
            var dialog = Application.Current.Windows.OfType<PinDialog>().Single(window => window.IsVisible);
            try { action(dialog); }
            catch (Exception error) { _failure = error; dialog.DialogResult = false; }
        });
    }

    private static T Get<T>(PinDialog dialog, string field) =>
        (T)typeof(PinDialog).GetField(field, BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(dialog)!;

    private static void SetPinAndSubmit(PinDialog dialog, string pin)
    {
        Get<PasswordBox>(dialog, "_pin").Password = pin;
        Get<Button>(dialog, "_submit").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
    }

    private static void ThrowFailure()
    {
        if (_failure is null) return;
        var error = _failure; _failure = null; throw error;
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
        _passed++; Console.WriteLine("PASS " + message);
    }

}

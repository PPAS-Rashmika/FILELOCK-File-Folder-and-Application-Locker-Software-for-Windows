using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using FileLock;
using FileLock.Shared;

internal static class ManagerAccessGateTests
{
    private static int _passed;
    private static Exception? _failure;

    internal static int Run(MainWindow manager)
    {
        _passed = 0;
        var session = true;
        var signOutCount = 0;
        var attempts = 0;
        var successfulLogins = 0;
        Task<ServiceStatus> Status() => Task.FromResult(new ServiceStatus
        {
            Initialized = true, ServiceAvailable = true, SessionAuthenticated = session
        });
        Task SignOut() { session = false; signOutCount++; return Task.CompletedTask; }
        Task Login(string pin)
        {
            attempts++;
            if (pin != "234567") throw new GateException("Incorrect master passcode.", "INCORRECT_PIN");
            session = true; successfulLogins++; return Task.CompletedTask;
        }

        Schedule(dialog =>
        {
            Check(!session && signOutCount == 1, "Manager opening signs out the previous settings session before asking for the passcode");
            Check(!manager.IsVisible && dialog.Owner is null && dialog.ShowInTaskbar
                && Application.Current.Windows.Cast<Window>().Count(window => window.IsVisible) == 1,
                "Manager opening exposes only an independent passcode dialog");
            Submit(dialog, "000000");
            Check(dialog.IsVisible && !session && !manager.IsVisible && Get<PasswordBox>(dialog, "_pin").Password.Length == 0,
                "Wrong master PIN keeps the manager hidden and clears the failed input");
            Submit(dialog, "234567");
        });
        var first = ManagerAccessGate.OpenAsync(Status, SignOut, Login).GetAwaiter().GetResult();
        ThrowFailure();
        Check(first == ManagerAccessResult.Authenticated && attempts == 2 && successfulLogins == 1,
            "Correct master PIN opens a freshly verified settings session");

        Schedule(dialog =>
        {
            Check(!session && signOutCount == 2, "A second explicit manager opening cannot reuse its successful first session");
            Get<Button>(dialog, "_cancel").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        });
        var canceled = ManagerAccessGate.OpenAsync(Status, SignOut, Login).GetAwaiter().GetResult();
        ThrowFailure();
        Check(canceled == ManagerAccessResult.Canceled && !session && attempts == 2 && !manager.IsVisible,
            "Canceling a repeat manager opening leaves settings signed out and hidden");

        var firstRun = ManagerAccessGate.OpenAsync(
            () => Task.FromResult(new ServiceStatus { Initialized = false, ServiceAvailable = true }),
            () => throw new InvalidOperationException("First-run setup must not sign out a nonexistent account."),
            _ => throw new InvalidOperationException("First-run setup must not ask for a nonexistent master PIN.")).GetAwaiter().GetResult();
        Check(firstRun == ManagerAccessResult.SetupRequired,
            "An unconfigured account can create its master passcode instead of being locked out");

        try
        {
            ManagerAccessGate.OpenAsync(
                () => Task.FromResult(new ServiceStatus { ServiceAvailable = false }),
                () => throw new InvalidOperationException("Unavailable broker must not be used."),
                _ => throw new InvalidOperationException("Unavailable broker must not authorize the manager.")).GetAwaiter().GetResult();
            throw new InvalidOperationException("An unavailable broker authorized manager opening.");
        }
        catch (GateException error) when (error.Code == "SERVICE_UNAVAILABLE")
        {
            Check(!manager.IsVisible, "An unavailable broker fails closed with a setup repair message");
        }

        var statusCalls = 0;
        Schedule(dialog => Submit(dialog, "234567"));
        try
        {
            ManagerAccessGate.OpenAsync(
                () => { statusCalls++; return Task.FromResult(new ServiceStatus { Initialized = true, ServiceAvailable = true, SessionAuthenticated = false }); },
                () => Task.CompletedTask,
                _ => Task.CompletedTask).GetAwaiter().GetResult();
            throw new InvalidOperationException("A dialog result without a broker settings session was accepted.");
        }
        catch (GateException error) when (error.Code == "SESSION_EXPIRED")
        {
            ThrowFailure();
            Check(statusCalls == 2 && !manager.IsVisible,
                "A successful dialog without an authenticated broker session cannot reveal settings");
        }
        TestRecovery(manager);
        TestConcurrentSignOut(manager);
        TestShutdownGuard(manager);
        return _passed;
    }

    private static void TestShutdownGuard(MainWindow manager)
    {
        var exiting = typeof(MainWindow).GetField("_exiting", BindingFlags.Instance | BindingFlags.NonPublic)!;
        exiting.SetValue(manager, true);
        try
        {
            var start = typeof(MainWindow).GetMethod("StartProtectedUse", BindingFlags.Instance | BindingFlags.NonPublic)!;
            try
            {
                start.Invoke(manager, [new ProtectedItem { Id = "fixture", OriginalPath = @"C:\fixture\folder", Kind = ProtectionKind.Folder, AccessToken = new string('A', 64) }, @"C:\fixture\folder"]);
                throw new InvalidOperationException("A late PIN approval started a new viewer while the agent was exiting.");
            }
            catch (TargetInvocationException error) when (error.InnerException is InvalidOperationException)
            {
                var watches = (System.Collections.IDictionary)typeof(MainWindow).GetField("_activeUses", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(manager)!;
                Check(watches.Count == 0 && !manager.IsVisible,
                    "A late PIN approval cannot launch or create an unmonitored access session after shutdown starts");
            }
        }
        finally { exiting.SetValue(manager, false); }
    }

    private static void TestConcurrentSignOut(MainWindow manager)
    {
        var prompting = typeof(MainWindow).GetField("_prompting", BindingFlags.Instance | BindingFlags.NonPublic)!;
        var signingOut = typeof(MainWindow).GetField("_settingsSigningOut", BindingFlags.Instance | BindingFlags.NonPublic)!;
        var finish = new TaskCompletionSource();
        var calls = 0;
        prompting.SetValue(manager, true);
        var operation = manager.SignOutHiddenSettingsAsync(() => { calls++; return finish.Task; });
        manager.SignOutHiddenSettingsAsync(() => throw new InvalidOperationException("Concurrent signout must be coalesced.")).GetAwaiter().GetResult();
        Check((bool)signingOut.GetValue(manager)! && (bool)prompting.GetValue(manager)! && calls == 1,
            "Hiding settings tracks signout separately from an already active item PIN prompt");
        // The item dialog can finish while a slow signout is still pending.
        prompting.SetValue(manager, false);
        finish.SetResult();
        CompleteOnDispatcher(operation);
        Check(!(bool)signingOut.GetValue(manager)! && !(bool)prompting.GetValue(manager)!,
            "An item dialog finishing before signout cannot leave prompt processing permanently blocked");

        finish = new TaskCompletionSource();
        operation = manager.SignOutHiddenSettingsAsync(() => finish.Task);
        prompting.SetValue(manager, true);
        finish.SetResult();
        CompleteOnDispatcher(operation);
        Check(!(bool)signingOut.GetValue(manager)! && (bool)prompting.GetValue(manager)!,
            "Finishing settings signout cannot clear an independent item prompt that is still active");
        prompting.SetValue(manager, false);

        manager.SignOutHiddenSettingsAsync(() => Task.FromException(new GateException("Fixture broker unavailable.", "SERVICE_UNAVAILABLE"))).GetAwaiter().GetResult();
        Check(!(bool)signingOut.GetValue(manager)! && !(bool)prompting.GetValue(manager)!,
            "A failed settings signout releases its guard so a later manager open can retry");
    }

    private static void CompleteOnDispatcher(Task operation)
    {
        if (!operation.IsCompleted)
        {
            var frame = new DispatcherFrame();
            _ = operation.ContinueWith(_ => Application.Current.Dispatcher.BeginInvoke(() => frame.Continue = false));
            Dispatcher.PushFrame(frame);
        }
        operation.GetAwaiter().GetResult();
    }

    private static void TestRecovery(MainWindow manager)
    {
        var session = false;
        var recovered = 0;
        Schedule(dialog =>
        {
            Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
            {
                var recovery = Application.Current.Windows.OfType<RecoverDialog>().Single(window => window.IsVisible);
                try
                {
                    Check(!manager.IsVisible && recovery.Owner is null && recovery.ShowInTaskbar,
                        "Forgotten master recovery is available while the manager stays hidden");
                    Field<TextBox>(recovery, "_key").Text = "disposable-recovery-key";
                    Field<PasswordBox>(recovery, "_pin").Password = "456789";
                    Field<PasswordBox>(recovery, "_confirm").Password = "456789";
                    Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
                    {
                        var key = Application.Current.Windows.OfType<RecoveryKeyDialog>().Single(window => window.IsVisible);
                        try
                        {
                            var panel = (StackPanel)key.Content;
                            panel.Children.OfType<CheckBox>().Single().IsChecked = true;
                            panel.Children.OfType<Button>().Single(button => (string)button.Content == "Done").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                        }
                        catch (Exception error)
                        {
                            _failure = error;
                            foreach (var acknowledgment in ((StackPanel)key.Content).Children.OfType<CheckBox>()) acknowledgment.IsChecked = true;
                            key.DialogResult = false;
                        }
                    });
                    ((StackPanel)recovery.Content).Children.OfType<StackPanel>().Single()
                        .Children.OfType<Button>().Single(button => (string)button.Content == "Reset passcode")
                        .RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
                catch (Exception error) { _failure = error; recovery.DialogResult = false; }
            });
            ((StackPanel)dialog.Content).Children.OfType<Button>().Single(button => (string)button.Content == "Forgot your passcode?")
                .RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        });
        var approved = ManagerAccessGate.OpenAsync(
            () => Task.FromResult(new ServiceStatus { Initialized = true, ServiceAvailable = true, SessionAuthenticated = session }),
            () => { session = false; return Task.CompletedTask; },
            _ => throw new InvalidOperationException("Recovery should verify the recovery key and replacement PIN."),
            (key, pin) =>
            {
                if (key != "disposable-recovery-key" || pin != "456789") throw new GateException("Incorrect fixture recovery data.");
                session = true; recovered++; return Task.FromResult("disposable-replacement-key");
            }).GetAwaiter().GetResult();
        ThrowFailure();
        Check(approved == ManagerAccessResult.Authenticated && recovered == 1 && !manager.IsVisible,
            "Valid recovery and a new master PIN establish a verified session before revealing settings");
    }

    private static void Schedule(Action<PinDialog> action)
    {
        Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
        {
            var dialog = Application.Current.Windows.OfType<PinDialog>().Single(window => window.IsVisible);
            try { action(dialog); }
            catch (Exception error) { _failure = error; dialog.DialogResult = false; }
        });
    }

    private static T Get<T>(PinDialog dialog, string field) =>
        Field<T>(dialog, field);

    private static T Field<T>(Window dialog, string field) =>
        (T)dialog.GetType().GetField(field, BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(dialog)!;

    private static void Submit(PinDialog dialog, string pin)
    {
        Get<PasswordBox>(dialog, "_pin").Password = pin;
        Get<Button>(dialog, "_submit").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
    }

    private static void ThrowFailure()
    {
        if (_failure is null) return;
        var error = _failure; _failure = null; throw error;
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
        _passed++; Console.WriteLine("PASS " + message);
    }
}

using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using FileLock;

internal static class PinChoiceTests
{
    internal static int Run()
    {
        var passed = 0;
        void Check(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
            passed++; Console.WriteLine("PASS " + message);
        }

        var individual = new PinDialog(null, "Choose a passcode", "Test location", confirm: true, offerShared: true);
        WithDialog(individual, () =>
        {
            Submit(individual);
            Check(individual.IsVisible && Get<TextBlock>(individual, "_error").Text.Contains("Choose"),
                "Adding a location requires an explicit shared or individual passcode choice");
            Get<RadioButton>(individual, "_individualChoice").IsChecked = true;
            Check(Get<PasswordBox>(individual, "_pin").IsEnabled && Get<PasswordBox>(individual, "_confirm").IsEnabled,
                "Choosing an individual passcode enables both passcode entries");
            Get<PasswordBox>(individual, "_pin").Password = "00123";
            Get<PasswordBox>(individual, "_confirm").Password = "00123";
            Submit(individual);
            Check(individual.IsVisible && Get<TextBlock>(individual, "_error").Text.Contains("six digits"),
                "An individual passcode with fewer than six digits cannot be saved");
            Get<PasswordBox>(individual, "_pin").Password = "000123";
            Get<PasswordBox>(individual, "_confirm").Password = "000124";
            Submit(individual);
            Check(individual.IsVisible && Get<TextBlock>(individual, "_error").Text.Contains("do not match"),
                "An individual passcode cannot be saved with mismatched confirmation");
            Get<PasswordBox>(individual, "_confirm").Password = "000123";
            Submit(individual);
        });
        Check(individual.DialogResult == true && !individual.UseShared && individual.Pin == "000123",
            "A confirmed individual passcode preserves leading zeroes and selects individual protection");

        // Even if a caller omits confirm, choosing a separate passcode must be confirmed.
        var shared = new PinDialog(null, "Choose a passcode", "Test location", offerShared: true);
        WithDialog(shared, () =>
        {
            Get<RadioButton>(shared, "_individualChoice").IsChecked = true;
            Get<PasswordBox>(shared, "_pin").Password = "111222";
            Submit(shared);
            Check(shared.IsVisible, "Choosing a new individual passcode always requires confirmation");
            Get<PasswordBox>(shared, "_confirm").Password = "111222";
            Get<RadioButton>(shared, "_sharedChoice").IsChecked = true;
            Check(Get<PasswordBox>(shared, "_pin").Password.Length == 0 && Get<PasswordBox>(shared, "_confirm").Password.Length == 0,
                "Switching to the shared master passcode clears an entered individual passcode");
            // Disabled input cannot accidentally become the submitted item PIN.
            Get<PasswordBox>(shared, "_pin").Password = "999999";
            Submit(shared);
        });
        Check(shared.DialogResult == true && shared.UseShared && shared.Pin.Length == 0,
            "The shared choice returns no individual passcode, including stale disabled input");
        return passed;
    }

    private static void WithDialog(PinDialog dialog, Action action)
    {
        Exception? failure = null;
        Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
        {
            try { action(); }
            catch (Exception error) { failure = error; dialog.DialogResult = false; }
        });
        dialog.ShowDialog();
        if (failure is not null) throw failure;
    }

    private static T Get<T>(PinDialog dialog, string field) =>
        (T)typeof(PinDialog).GetField(field, BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(dialog)!;

    private static void Submit(PinDialog dialog) =>
        Get<Button>(dialog, "_submit").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
}

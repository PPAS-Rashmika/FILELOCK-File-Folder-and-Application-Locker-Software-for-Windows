using FileLock;

internal static class FileShellCommandTests
{
    internal static int Run()
    {
        var passed = 0;
        Check(FileShellIntegration.BuildCommand(@"C:\Program Files\FileLock\App\FileLock.exe")
            == "\"C:\\Program Files\\FileLock\\App\\FileLock.exe\" --open \"%1\"",
            "The explicit file command quotes the installed application and selected file placeholder");
        Check(FileShellIntegration.BuildCommand(@"C:\සිංහල folder\FileLock.exe")
            == "\"C:\\සිංහල folder\\FileLock.exe\" --open \"%1\"",
            "The explicit file command preserves Unicode executable paths with spaces");
        ExpectArgumentError(() => FileShellIntegration.BuildCommand("C:\\fixture\\bad\"path.exe"));
        Check(true, "A quoted executable path cannot inject another argument into the file command");
        foreach (var invalid in new[] { null, "", "   " })
            ExpectArgumentError(() => FileShellIntegration.BuildCommand(invalid!));
        Check(true, "An absent executable cannot produce an Explorer file command");
        return passed;

        void Check(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
            passed++;
            Console.WriteLine("PASS " + message);
        }
    }

    private static void ExpectArgumentError(Action action)
    {
        try { action(); }
        catch (ArgumentException) { return; }
        throw new InvalidOperationException("An invalid executable path was accepted.");
    }
}

using System.IO;
using FileLock;
using FileLock.Shared;

internal static class ProtectedOpenTargetTests
{
    internal static int Run()
    {
        var passed = 0;
        const string root = @"C:\fixture\private folder";
        var folder = new ProtectedItem { OriginalPath = root, Kind = ProtectionKind.Folder };
        var target = ProtectedOpenTarget.Select(folder, root, isDirectory: true);
        Check(target.Path == root && target.ObserverKind == ProtectionKind.Folder && target.ObserverPath == root,
            "Opening a protected folder observes its approved root");

        var nested = root + @"\nested\සිංහල";
        target = ProtectedOpenTarget.Select(folder, nested, isDirectory: true);
        Check(target.Path == nested && target.ObserverKind == ProtectionKind.Folder && target.ObserverPath == root,
            "A nested folder opens the requested view while observing the protected root");

        var document = root + @"\nested\report.pdf";
        target = ProtectedOpenTarget.Select(folder, document, isDirectory: false);
        Check(target.Path == document && target.ObserverKind == ProtectionKind.File && target.ObserverPath == document,
            "A document inside a protected folder observes the document viewer rather than unrelated Explorer views");

        var executable = root + @"\nested\tool.EXE";
        target = ProtectedOpenTarget.Select(folder, executable, isDirectory: false);
        Check(target.Path == executable && target.ObserverKind == ProtectionKind.Application && target.ObserverPath == executable,
            "An executable inside a protected folder observes its application lifetime");

        foreach (var invalid in new[] { root + "-other\\report.pdf", root + @"\..\outside\report.pdf", @"D:\fixture\private folder\report.pdf" })
        {
            ExpectIOException(() => ProtectedOpenTarget.Select(folder, invalid, isDirectory: false));
            Check(true, "A file request outside its approved protected folder is rejected");
        }

        var repairedFile = new ProtectedItem { OriginalPath = @"C:\fixture\renamed report.pdf", Kind = ProtectionKind.File };
        target = ProtectedOpenTarget.Select(repairedFile, @"C:\fixture\old report.pdf", isDirectory: false);
        Check(target.Path == repairedFile.OriginalPath && target.ObserverKind == ProtectionKind.File
            && target.ObserverPath == repairedFile.OriginalPath,
            "A single-file approval opens and observes the broker's repaired location");

        ExpectIOException(() => ProtectedOpenTarget.Select(repairedFile, repairedFile.OriginalPath, isDirectory: true));
        Check(true, "A protected file replaced with a directory cannot open as an approved file");

        var application = new ProtectedItem { OriginalPath = @"C:\fixture\renamed tool.exe", Kind = ProtectionKind.Application };
        target = ProtectedOpenTarget.Select(application, @"C:\fixture\old tool.exe", isDirectory: false);
        Check(target.Path == application.OriginalPath && target.ObserverKind == ProtectionKind.Application
            && target.ObserverPath == application.OriginalPath,
            "An application approval uses its repaired executable location");

        ExpectIOException(() => ProtectedOpenTarget.Select(application, application.OriginalPath, isDirectory: true));
        Check(true, "A protected application replaced with a directory cannot open as an approved application");
        return passed;

        void Check(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
            passed++;
            Console.WriteLine("PASS " + message);
        }
    }

    private static void ExpectIOException(Action action)
    {
        try { action(); }
        catch (IOException) { return; }
        throw new InvalidOperationException("An invalid protected open target was accepted.");
    }
}

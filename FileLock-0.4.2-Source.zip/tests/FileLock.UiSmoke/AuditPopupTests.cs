using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using FileLock;
using FileLock.Shared;

internal static class AuditPopupTests
{
    private static int _passed;
    private static Exception? _failure;

    internal static int Run(MainWindow manager)
    {
        _passed = 0;
        manager.Hide();
        var reads = 0;
        var now = DateTimeOffset.UtcNow;
        var noisy = new List<PendingChallenge>
        {
            Challenge("unknown", "document", now, process: 0),
            Challenge("stale", "folder", now.AddMinutes(-3)),
            Challenge("fresh", "application", now),
            Challenge("future", "document", now.AddDays(1))
        };
        Drain(manager, noisy, () => reads++);
        PumpDispatcher();
        Check(reads == 1 && VisiblePrompts() == 0 && !manager.IsVisible,
            "Legacy audit delivery is drained without showing a PIN or management window");

        // Each real failed read gets a new event ID. Time-based suppression
        // therefore only postponed the previous repeating-popup bug.
        for (var batch = 0; batch < 8; batch++)
        {
            Drain(manager, Enumerable.Range(0, 16).Select(index =>
                Challenge($"scan-{batch}-{index}", "document", DateTimeOffset.UtcNow)).ToList(), () => reads++);
            PumpDispatcher();
        }
        Check(reads == 9 && VisiblePrompts() == 0 && !manager.IsVisible,
            "Repeated background reads with fresh audit IDs never create an unlock popup");

        var attempts = 0;
        var opened = 0;
        SchedulePrompt(dialog =>
        {
            Drain(manager, noisy, () => reads++);
            Check(VisiblePrompts() == 1 && dialog.IsVisible && !manager.IsVisible,
                "An audit arriving during an explicit PIN dialog neither adds nor replaces a prompt");
            Get<Button>(dialog, "_cancel").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        });
        var canceled = AccessPrompt.Show(null, "Disposable document", _ =>
        {
            attempts++;
            throw new InvalidOperationException("Cancel must not unlock the fixture.");
        }, _ => opened++);
        ThrowFailure();
        Drain(manager, [Challenge("after-cancel", "document", DateTimeOffset.UtcNow)], () => reads++);
        PumpDispatcher();
        Check(!canceled && attempts == 0 && opened == 0 && VisiblePrompts() == 0,
            "Cancel followed by another failed read cannot resurrect a PIN dialog or open content");

        SchedulePrompt(dialog =>
        {
            Drain(manager, [Challenge("while-reopening", "document", DateTimeOffset.UtcNow)], () => reads++);
            Check(VisiblePrompts() == 1 && dialog.IsVisible,
                "A new explicit opening still has its own PIN dialog after cancel and audit noise");
            Get<PasswordBox>(dialog, "_pin").Password = "000001";
            Get<Button>(dialog, "_submit").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        });
        var approved = AccessPrompt.Show(null, "Disposable document", pin =>
        {
            attempts++;
            if (pin != "000001") throw new GateException("Incorrect fixture PIN.");
            return Task.FromResult(new ProtectedItem
            {
                Id = "document", OriginalPath = @"C:\fixture\document.txt", Kind = ProtectionKind.File,
                IsOpen = true, UnlockedUntilUtc = DateTimeOffset.UtcNow.AddSeconds(15)
            });
        }, _ => opened++);
        ThrowFailure();
        Check(approved && attempts == 1 && opened == 1 && VisiblePrompts() == 0 && !manager.IsVisible,
            "Only fresh explicit PIN approval opens the fixture once while the manager stays hidden");
        return _passed;
    }

    private static PendingChallenge Challenge(string id, string item, DateTimeOffset time, uint process = 123) => new()
    {
        Id = id, ItemId = item, Name = "Disposable " + item, OriginalPath = @"C:\fixture\" + item,
        ProcessId = process, RequestedUtc = time, Kind = item switch
        {
            "folder" => ProtectionKind.Folder, "application" => ProtectionKind.Application, _ => ProtectionKind.File
        }
    };

    private static void Drain(MainWindow manager, List<PendingChallenge> challenges, Action read)
    {
        manager.PollAuditNotificationsAsync(() => { read(); return Task.FromResult(challenges); }).GetAwaiter().GetResult();
    }

    private static int VisiblePrompts() => Application.Current.Windows.OfType<PinDialog>().Count(window => window.IsVisible);

    private static void PumpDispatcher()
    {
        var frame = new DispatcherFrame();
        Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () => frame.Continue = false);
        Dispatcher.PushFrame(frame);
    }

    private static void SchedulePrompt(Action<PinDialog> action)
    {
        Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, () =>
        {
            var dialog = Application.Current.Windows.OfType<PinDialog>().Single(window => window.IsVisible);
            try { action(dialog); }
            catch (Exception error) { _failure = error; dialog.DialogResult = false; }
        });
    }

    private static T Get<T>(PinDialog dialog, string field) =>
        (T)typeof(PinDialog).GetField(field, BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(dialog)!;

    private static void ThrowFailure()
    {
        if (_failure is null) return;
        var error = _failure; _failure = null; throw error;
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
        _passed++; Console.WriteLine("PASS " + message);
    }
}

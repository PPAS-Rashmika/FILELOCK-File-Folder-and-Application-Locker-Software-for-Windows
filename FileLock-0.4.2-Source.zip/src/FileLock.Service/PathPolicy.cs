using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using FileLock.Shared;
using Microsoft.Win32.SafeHandles;

namespace FileLock.Service;

internal sealed record ValidatedPath(string OriginalPath, string NtPath, string Name, string VolumeIdentity);

internal static class PathPolicy
{
    private const uint ReadControl = 0x20000;
    private const uint FileReadAttributes = 0x80;
    private const uint BackupSemantics = 0x02000000;
    private const uint OpenReparsePoint = 0x00200000;

    // Must execute under the named-pipe caller's impersonation token: the
    // LocalSystem broker cannot acquire permission to lock someone else's data.
    public static ValidatedPath Validate(string? input, ProtectionKind kind, string ownerSid)
    {
        var path = ValidateRecoveryLocation(input, kind, ownerSid);
        var isDirectory = kind == ProtectionKind.Folder;
        using var handle = OpenChecked(path);
        CheckOwner(handle, ownerSid);
        CheckLinks(handle, isDirectory);
        var canonical = ReadFinalPath(handle, 0);
        if (!canonical.StartsWith("\\\\?\\", StringComparison.Ordinal) || !string.Equals(canonical[4..], path, StringComparison.OrdinalIgnoreCase))
            throw new GateException("Choose the canonical long path; aliases and substituted drives are unsupported.", "INVALID_PATH");
        var ntPath = ReadFinalPath(handle, 2);
        if (!IsValidNtPath(ntPath)) throw new GateException("This device path is unsupported.", "INVALID_PATH");
        var volumePath = ReadFinalPath(handle, 1);
        var volumeEnd = volumePath.IndexOf('}');
        if (!volumePath.StartsWith("\\\\?\\Volume{", StringComparison.OrdinalIgnoreCase) || volumeEnd < 0)
            throw new GateException("The volume identity cannot be verified.", "INVALID_PATH");
        var volumeIdentity = volumePath[..(volumeEnd + 1)];

        if (isDirectory)
        {
            var inspected = 0;
            var queue = new Queue<string>();
            queue.Enqueue(path);
            while (queue.Count > 0)
            {
                var directory = queue.Dequeue();
                foreach (var child in Directory.EnumerateFileSystemEntries(directory))
                {
                    if (++inspected > 200_000) throw new GateException("This folder is too large to validate safely. Select smaller folders.", "INVALID_PATH");
                    var childAttributes = File.GetAttributes(child);
                    if (childAttributes.HasFlag(FileAttributes.ReparsePoint))
                        throw new GateException("Folders containing symbolic links, junctions, or cloud placeholders cannot be protected.", "INVALID_PATH");
                    var childDirectory = childAttributes.HasFlag(FileAttributes.Directory);
                    using var childHandle = OpenChecked(child);
                    CheckOwner(childHandle, ownerSid);
                    CheckLinks(childHandle, childDirectory);
                    if (childDirectory) queue.Enqueue(child);
                }
            }
        }
        return new(path, ntPath, Path.GetFileName(path), volumeIdentity);
    }

    // Recovery authorization comes from the durable original file identity.
    // A locked object's current owner is SYSTEM, so this checks only location
    // policy; RecoverLocation must match the saved root before changing security.
    internal static string ValidateRecoveryLocation(string? input, ProtectionKind kind, string ownerSid)
    {
        if (!Enum.IsDefined(kind)) throw new GateException("Choose a valid file, folder, or application type.", "INVALID_PATH");
        if (string.IsNullOrWhiteSpace(input) || input.Length > 700 || input.Length < 4 || !char.IsAsciiLetter(input[0]) || input[1] != ':' || input[2] != '\\' || input.Contains('/'))
            throw new GateException("Choose a local NTFS path such as C:\\Users\\your-name\\Documents\\file.txt.", "INVALID_PATH");
        if (input.AsSpan(2).Contains(':') || input.Split('\\').Skip(1).Any(s => s is "." or ".." || s.EndsWith(' ') || s.EndsWith('.')))
            throw new GateException("Alternate data streams and ambiguous path names cannot be protected.", "INVALID_PATH");
        var path = Path.GetFullPath(input).TrimEnd('\\');
        var root = Path.GetPathRoot(path)!;
        if (string.Equals(path, root.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))
            throw new GateException("A drive root cannot be protected.", "INVALID_PATH");
        if (new DriveInfo(root).DriveType != DriveType.Fixed)
            throw new GateException("Only local fixed NTFS drives can be protected.", "INVALID_PATH");
        var fileSystem = new StringBuilder(32);
        if (!GetVolumeInformation(root, null, 0, out _, out _, out _, fileSystem, 32) || fileSystem.ToString() != "NTFS")
            throw new GateException("Only NTFS paths support Windows location protection.", "INVALID_PATH");
        foreach (var critical in CriticalPaths(ownerSid))
            if (Overlaps(path, critical))
                throw new GateException("Windows, installed system programs, service data, and FileLock itself cannot be protected.", "CRITICAL_PATH");

        var attributes = File.GetAttributes(path);
        var isDirectory = attributes.HasFlag(FileAttributes.Directory);
        if ((kind == ProtectionKind.Folder) != isDirectory)
            throw new GateException("The selected item type does not match this path.", "INVALID_PATH");
        if (kind == ProtectionKind.Application && !path.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
            throw new GateException("Select a local .exe application.", "INVALID_PATH");
        RejectReparseAncestors(path);

        return path;
    }

    internal static bool Overlaps(string first, string second) => IsInside(first, second) || IsInside(second, first);
    private static bool IsInside(string path, string directory)
    {
        path = path.TrimEnd('\\'); directory = directory.TrimEnd('\\');
        return path.Equals(directory, StringComparison.OrdinalIgnoreCase) || path.StartsWith(directory + "\\", StringComparison.OrdinalIgnoreCase);
    }
    internal static bool IsValidNtPath(string path)
    {
        const string prefix = "\\Device\\HarddiskVolume";
        if (path.Length > 1023 || !path.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || path.Contains('/') || path.Contains(':')) return false;
        var rest = path[prefix.Length..];
        var slash = rest.IndexOf('\\');
        return slash > 0 && rest[..slash].All(char.IsAsciiDigit) && slash < rest.Length - 1
            && !rest[(slash + 1)..].Split('\\').Any(s => s.Length == 0 || s is "." or "..");
    }

    private static IEnumerable<string> CriticalPaths(string ownerSid)
    {
        var values = new[]
        {
            Environment.GetFolderPath(Environment.SpecialFolder.Windows),
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            AppContext.BaseDirectory,
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32")
        };
        var paths = values.Where(s => !string.IsNullOrWhiteSpace(s)).Select(Path.GetFullPath).ToList();
        using var profileKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\" + ownerSid);
        if (profileKey?.GetValue("ProfileImagePath") is string profile)
        {
            profile = Environment.ExpandEnvironmentVariables(profile);
            paths.Add(Path.Combine(profile, "AppData"));
            paths.Add(Path.Combine(profile, "NTUSER.DAT"));
        }
        return paths;
    }

    private static void RejectReparseAncestors(string path)
    {
        for (var current = path; !string.IsNullOrEmpty(current); current = Path.GetDirectoryName(current)!)
            if (File.GetAttributes(current).HasFlag(FileAttributes.ReparsePoint))
                throw new GateException("Paths using symbolic links, junctions, or cloud placeholders cannot be protected.", "INVALID_PATH");
    }
    private static SafeFileHandle OpenChecked(string path)
    {
        var handle = CreateFile(path, ReadControl | FileReadAttributes, 7, IntPtr.Zero, 3, BackupSemantics | OpenReparsePoint, IntPtr.Zero);
        if (handle.IsInvalid) { handle.Dispose(); throw new Win32Exception(Marshal.GetLastWin32Error(), "The path cannot be validated under your Windows account."); }
        return handle;
    }
    private static void CheckOwner(SafeFileHandle handle, string ownerSid)
    {
        if (GetSecurityInfo(handle, 1, 1, out var owner, out _, out _, out _, out var descriptor) != 0) throw new GateException("The path owner cannot be verified.", "INVALID_PATH");
        try
        {
            if (owner == IntPtr.Zero || new SecurityIdentifier(owner).Value != ownerSid)
                throw new GateException("Protect only files and folders owned by your Windows account.", "NOT_OWNER");
        }
        finally { if (descriptor != IntPtr.Zero) LocalFree(descriptor); }
    }
    private static void CheckLinks(SafeFileHandle handle, bool directory)
    {
        if (!GetFileInformationByHandle(handle, out var information)) throw new Win32Exception();
        if (information.Attributes.HasFlag(FileAttributes.ReparsePoint)) throw new GateException("Reparse paths cannot be protected.", "INVALID_PATH");
        if (!directory && information.NumberOfLinks != 1)
            throw new GateException("Hardlinked files cannot be protected because another location can access their content.", "INVALID_PATH");
    }
    private static string ReadFinalPath(SafeFileHandle handle, uint flags)
    {
        var text = new StringBuilder(2048);
        var length = GetFinalPathNameByHandle(handle, text, (uint)text.Capacity, flags);
        if (length == 0 || length >= text.Capacity) throw new Win32Exception();
        return text.ToString();
    }

    [StructLayout(LayoutKind.Sequential)] private struct FileInformation
    {
        public FileAttributes Attributes;
        public System.Runtime.InteropServices.ComTypes.FILETIME Creation, Access, Write;
        public uint VolumeSerial, SizeHigh, SizeLow, NumberOfLinks, IndexHigh, IndexLow;
    }
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern SafeFileHandle CreateFile(string path, uint access, uint share, IntPtr attributes, uint creation, uint flags, IntPtr template);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern uint GetFinalPathNameByHandle(SafeFileHandle handle, StringBuilder path, uint length, uint flags);
    [DllImport("kernel32.dll", SetLastError = true)] private static extern bool GetFileInformationByHandle(SafeFileHandle handle, out FileInformation information);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool GetVolumeInformation(string root, StringBuilder? name, uint nameLength, out uint serial, out uint componentLength, out uint flags, StringBuilder fileSystem, uint fileSystemLength);
    [DllImport("advapi32.dll")] private static extern uint GetSecurityInfo(SafeFileHandle handle, int objectType, uint information, out IntPtr owner, out IntPtr group, out IntPtr dacl, out IntPtr sacl, out IntPtr descriptor);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
}

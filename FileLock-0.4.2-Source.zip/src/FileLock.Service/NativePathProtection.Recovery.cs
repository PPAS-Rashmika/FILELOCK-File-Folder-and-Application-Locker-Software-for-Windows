using System.ComponentModel;
using System.Text.Json;
using FileLock.Shared;

namespace FileLock.Service;

internal sealed partial class NativePathProtection
{
    public bool RecoverMovedLocation(ItemState item)
    {
        RequirePermissions();
        return TryRecoverMovedLocation(item);
    }

    private bool TryRecoverMovedLocation(ItemState item)
    {
        if (item.PermissionJournal.Count == 0) return false;
        var saved = item.PermissionJournal.Single(entry => entry.RelativePath == "");
        try
        {
            using var current = SecurityNative.Open(item.OriginalPath, "", captureSecurity: false);
            if (SecurityNative.IdentityMatches(saved, current.Entry)) return false;
            // An approved atomic file save intentionally replaces the file at
            // the same name. Its existing adoption rule is separate from moves.
            if (item.Kind != ProtectionKind.Folder && item.ProtectionPhase == "Open") return false;
        }
        catch (Win32Exception error) when (error.NativeErrorCode is 2 or 3) { }
        var candidate = SecurityNative.LocateOriginal(saved);
        if (candidate == null)
            throw new GateException("The original protected item could not be found on its saved drive. If it was moved, choose Manage > Repair moved location. If it was deleted, choose Manage > Remove protection to safely clear its record. Its passcode and permission journal have been kept.", "LOCATION_NOT_FOUND");
        if (IsRecycledLocation(candidate))
            throw new GateException("This protected item was deleted and is in the Recycle Bin. Choose Manage > Remove protection to safely clear its old record and restore any surviving permissions.", "LOCATION_DELETED");
        RecoverLocation(item, candidate);
        return true;
    }

    public void RecoverLocation(ItemState item, string? candidatePath = null)
    {
        RequirePermissions();
        if (item.PermissionJournal.Count == 0) throw new IOException("Missing permission journal; this location cannot be repaired safely.");
        candidatePath ??= SecurityNative.LocateOriginal(item.PermissionJournal.Single(entry => entry.RelativePath == ""))
            ?? throw new GateException("The original item could not be found on its saved drive. Select its moved location, or restore the original item from backup. Its saved permissions have been retained.", "LOCATION_NOT_FOUND");
        if (IsRecycledLocation(candidatePath))
            throw new GateException("This item is in the Recycle Bin. Choose Manage > Remove protection, or restore it from the Recycle Bin before repairing its location.", "LOCATION_DELETED");
        var path = PathPolicy.ValidateRecoveryLocation(candidatePath, item.Kind, item.OwnerSid);
        using var ancestors = SecurityNative.HoldRecoveryAncestors(path);
        // Validate against a separate view so an invalid candidate cannot alter
        // live metadata or capture locked security as the original descriptor.
        var candidate = JsonSerializer.Deserialize<ItemState>(JsonSerializer.Serialize(item))!;
        candidate.OriginalPath = path;
        using var tree = OpenTree(candidate, capture: false);
        ValidateRoot(candidate, tree);
        if (candidate.ProtectionPhase != "Open") ValidateAll(candidate, tree);
        var ntPath = tree.Objects[0].NtPath;
        if (_canRelocate?.Invoke(item, ntPath) == false)
            throw new GateException("This moved location overlaps another protected item. Move it outside that location before repairing it.", "OVERLAPPING_PATH");

        var previousPath = item.OriginalPath;
        var previousNtPath = item.NtPath;
        var previousName = item.Name;
        item.OriginalPath = path;
        item.NtPath = ntPath;
        item.Name = Path.GetFileName(path);
        // Commit the new address before any security update. After a crash the
        // unchanged original journal can still relock or restore this object.
        try { _persist(); }
        catch
        {
            item.OriginalPath = previousPath;
            item.NtPath = previousNtPath;
            item.Name = previousName;
            throw;
        }
        try { UpsertAtCurrentLocation(item); }
        catch (Exception error)
        {
            item.ProtectionError = "Location repaired, but locking needs attention: " + error.Message;
            try { _persist(); } catch { }
            throw;
        }
    }

    private static bool IsRecycledLocation(string path) => path.Length > 3
        && path[3..].StartsWith("$Recycle.Bin\\", StringComparison.OrdinalIgnoreCase);

    private void RemoveDeletedLocation(ItemState item)
    {
        // A missing root alone is not proof that every descendant is gone.
        // Locate each durable identity on its original, serial-verified volume
        // and restore surviving objects before the broker discards the record.
        var targets = new List<(SecurityNative.OpenObject Object, PermissionJournalEntry Saved)>();
        var ancestorScopes = new List<IDisposable>();
        var heldParents = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var volumeFiles = new Dictionary<string, HashSet<ulong>>(StringComparer.OrdinalIgnoreCase);
        try
        {
            foreach (var saved in item.PermissionJournal)
            {
                var candidatePath = SecurityNative.LocateOriginal(saved, proveMissing: true, volumeFiles);
                if (candidatePath == null) continue; // Verified absence on the original mounted NTFS volume.
                var kind = saved.IsDirectory ? ProtectionKind.Folder : ProtectionKind.File;
                var path = PathPolicy.ValidateRecoveryLocation(candidatePath, kind, item.OwnerSid);
                ancestorScopes.Add(SecurityNative.HoldRecoveryAncestors(path, heldParents));
                var target = SecurityNative.Open(path, saved.RelativePath, captureSecurity: false);
                targets.Add((target, saved));
                if (!SecurityNative.IdentityMatches(saved, target.Entry))
                    throw new IOException("A surviving object changed while validating deletion. Its permission journal was retained.");
                if (_canRelocate?.Invoke(item, target.NtPath) == false)
                    throw new GateException("A surviving object overlaps another protected item. Its permission journal has been retained for recovery.", "OVERLAPPING_PATH");
            }
            // All identities, locations and handles pass before the first write.
            var restored = new List<(SecurityNative.OpenObject Object, PermissionJournalEntry Saved)>();
            try
            {
                foreach (var target in targets)
                {
                    SecurityNative.Restore(target.Object, target.Saved);
                    restored.Add(target);
                }
            }
            catch
            {
                foreach (var target in restored) try { SecurityNative.Lock(target.Object, target.Saved, item.OwnerSid); } catch { }
                throw;
            }
        }
        finally
        {
            foreach (var target in targets) target.Object.Dispose();
            foreach (var scope in ancestorScopes) scope.Dispose();
        }
    }
}

using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Principal;
using FileLock.Shared;

namespace FileLock.Service;

internal static class Program
{
    private static readonly CancellationTokenSource Stop = new();
    private static readonly ServiceMainCallback MainCallback = ServiceMain;
    private static readonly ControlCallback HandlerCallback = Control;
    private static IntPtr _statusHandle;
    private static uint _checkpoint;

    private static int Main(string[] arguments)
    {
        if (arguments.Length == 1 && arguments[0] is "--admin-status" or "--admin-uninstall-check")
        {
            using var identity = WindowsIdentity.GetCurrent();
            if (!new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator))
            { Console.Error.WriteLine("Run this check as an elevated administrator."); return 5; }
            try
            {
                var client = new GateClient();
                if (arguments[0] == "--admin-uninstall-check") client.PrepareUninstallAsync().GetAwaiter().GetResult();
                var status = client.StatusAsync().GetAwaiter().GetResult();
                Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(status, BrokerProtocol.JsonOptions));
                return status.ServiceAvailable ? 0 : 2;
            }
            catch (Exception commandError) { Console.Error.WriteLine(commandError.Message); return 2; }
        }
        var table = new[]
        {
            new ServiceTableEntry { Name = BrokerProtocol.ServiceName, Main = MainCallback },
            new ServiceTableEntry()
        };
        if (StartServiceCtrlDispatcher(table)) return 0;
        var error = Marshal.GetLastWin32Error();
        Console.Error.WriteLine(error == 1063 ? "FileLock.Service must run as the installed LocalSystem Windows service FileLockPathGateBroker. It does not install or configure the machine when opened directly." : new Win32Exception(error).Message);
        return error;
    }

    private static void ServiceMain(uint count, IntPtr arguments)
    {
        _statusHandle = RegisterServiceCtrlHandlerEx(BrokerProtocol.ServiceName, HandlerCallback, IntPtr.Zero);
        if (_statusHandle == IntPtr.Zero) return;
        Report(2, 0, 30000);
        try
        {
            using var identity = WindowsIdentity.GetCurrent();
            if (!identity.IsSystem) throw new UnauthorizedAccessException("The broker must run as LocalSystem.");
            using var server = new BrokerServer();
            Report(4);
            server.RunAsync(Stop.Token).GetAwaiter().GetResult();
            Report(1);
        }
        catch (Exception error)
        {
            Console.Error.WriteLine("FileLock broker stopped: " + error.Message);
            Report(1, 1064);
        }
    }
    private static uint Control(uint control, uint eventType, IntPtr eventData, IntPtr context)
    {
        if (control is 1 or 5)
        {
            Report(3, 0, 30000);
            Stop.Cancel();
        }
        return 0;
    }
    private static void Report(uint state, uint error = 0, uint waitHint = 0)
    {
        var status = new NativeServiceStatus
        {
            Type = 0x10, State = state, Accepted = state == 4 ? 5U : 0U,
            Win32ExitCode = error, Checkpoint = state is 2 or 3 ? ++_checkpoint : 0, WaitHint = waitHint
        };
        SetServiceStatus(_statusHandle, ref status);
    }

    [UnmanagedFunctionPointer(CallingConvention.Winapi)] private delegate void ServiceMainCallback(uint count, IntPtr arguments);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)] private delegate uint ControlCallback(uint control, uint eventType, IntPtr eventData, IntPtr context);
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] private struct ServiceTableEntry
    {
        [MarshalAs(UnmanagedType.LPWStr)] public string? Name;
        public ServiceMainCallback? Main;
    }
    [StructLayout(LayoutKind.Sequential)] private struct NativeServiceStatus { public uint Type, State, Accepted, Win32ExitCode, SpecificExitCode, Checkpoint, WaitHint; }
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool StartServiceCtrlDispatcher([In] ServiceTableEntry[] services);
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr RegisterServiceCtrlHandlerEx(string serviceName, ControlCallback handler, IntPtr context);
    [DllImport("advapi32.dll", SetLastError = true)] private static extern bool SetServiceStatus(IntPtr handle, ref NativeServiceStatus status);
}

using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text.Json;
using FileLock.Shared;

namespace FileLock.Service;

internal sealed class StateStore
{
    private readonly string _directory;
    private readonly string _path;
    public StateStore(string? directory = null)
    {
        // Internal dependency injection is used only by the disposable SYSTEM
        // integration harness. The production server supplies no directory.
        _directory = directory == null
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "FileLockPathGate")
            : Path.GetFullPath(directory);
        _path = Path.Combine(_directory, "state.dpapi");
        EnsurePrivateDirectory();
    }

    public GateState Load()
    {
        if (!File.Exists(_path)) return new();
        if ((File.GetAttributes(_path) & FileAttributes.ReparsePoint) != 0) throw new IOException("Service state cannot be a reparse point.");
        RequireSystemOwner(_path);
        SecureAcl(_path);
        if (new FileInfo(_path).Length > 64 * 1024 * 1024 + 4096) throw new IOException("Service state is too large.");
        var plaintext = DataProtection.Transform(File.ReadAllBytes(_path), false);
        try
        {
            var state = JsonSerializer.Deserialize<GateState>(plaintext, BrokerProtocol.JsonOptions) ?? throw new IOException("Service state is invalid.");
            if (state.Version != 1 || state.Users.Count > 128 || state.Users.Sum(u => u.Items.Count) > 128)
                throw new IOException("Unsupported or invalid service state.");
            var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var owners = new HashSet<string>(StringComparer.Ordinal);
            foreach (var user in state.Users)
            {
                if (string.IsNullOrWhiteSpace(user.OwnerSid) || !owners.Add(user.OwnerSid) || Convert.FromBase64String(user.RootSecret).Length != 32
                    || Convert.FromBase64String(user.MasterSalt).Length != 16 || Convert.FromBase64String(user.MasterHash).Length != 32 || Convert.FromBase64String(user.RecoveryEnvelope).Length != 60)
                    throw new IOException("Service account state is invalid.");
                _ = new SecurityIdentifier(user.OwnerSid);
                foreach (var item in user.Items)
                {
                    if (!Guid.TryParse(item.Id, out _) || !ids.Add(item.Id) || !Enum.IsDefined(item.Kind) || !PathPolicy.IsValidNtPath(item.NtPath) || string.IsNullOrWhiteSpace(item.OriginalPath)
                        || !item.VolumeIdentity.StartsWith("\\\\?\\Volume{", StringComparison.OrdinalIgnoreCase) || !item.VolumeIdentity.EndsWith('}')
                        || (item.PinSalt == null) != (item.PinHash == null) || (item.PinSalt != null && (Convert.FromBase64String(item.PinSalt).Length != 16 || Convert.FromBase64String(item.PinHash!).Length != 32)))
                        throw new IOException("Service protection state is invalid.");
                    if (item.OwnerSid.Length != 0 && item.OwnerSid != user.OwnerSid) throw new IOException("Permission journal owner is invalid.");
                    if (item.PermissionJournal.Count > NativePathProtection.MaximumJournalEntries || item.ProtectionPhase is not ("Staged" or "Locked" or "Open"))
                        throw new IOException("Permission journal size or phase is invalid.");
                    var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    foreach (var entry in item.PermissionJournal)
                    {
                        if (!names.Add(entry.RelativePath) || entry.RelativePath.Length > 2048 || Path.IsPathRooted(entry.RelativePath)
                            || entry.RelativePath.Contains(':') || entry.RelativePath.Contains('/') || entry.RelativePath.Split('\\').Any(part => part is "." or "..")
                            || !entry.VolumeIdentity.Equals(item.VolumeIdentity, StringComparison.OrdinalIgnoreCase)
                            || !System.Text.RegularExpressions.Regex.IsMatch(entry.FileIdentity, "^[0-9A-F]{8}:[0-9A-F]{16}$"))
                            throw new IOException("Permission journal path or identity is invalid.");
                        var bytes = Convert.FromBase64String(entry.OriginalSecurityDescriptor);
                        if (bytes.Length is < 20 or > 65536) throw new IOException("Permission journal descriptor is invalid.");
                        _ = new System.Security.AccessControl.RawSecurityDescriptor(bytes, 0);
                    }
                    if (item.PermissionJournal.Count != 0 && !names.Contains("")) throw new IOException("Permission journal root is missing.");
                }
            }
            return state;
        }
        finally { CryptographicOperations.ZeroMemory(plaintext); }
    }

    public void Save(GateState state)
    {
        EnsurePrivateDirectory();
        var plaintext = JsonSerializer.SerializeToUtf8Bytes(state, BrokerProtocol.JsonOptions);
        if (plaintext.Length > 64 * 1024 * 1024) { CryptographicOperations.ZeroMemory(plaintext); throw new IOException("Permission journal is too large; select a smaller folder."); }
        byte[] protectedData;
        try { protectedData = DataProtection.Transform(plaintext, true); }
        finally { CryptographicOperations.ZeroMemory(plaintext); }
        var temporary = Path.Combine(_directory, "state-" + Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            using (var file = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            {
                file.Write(protectedData);
                file.Flush(true);
            }
            SecureAcl(temporary);
            if (File.Exists(_path)) File.Replace(temporary, _path, null);
            else File.Move(temporary, _path);
            SecureAcl(_path);
        }
        finally
        {
            if (File.Exists(temporary)) File.Delete(temporary);
        }
    }

    private void EnsurePrivateDirectory()
    {
        for (var current = new DirectoryInfo(_directory); current != null; current = current.Parent)
            if (current.Exists && (current.Attributes & FileAttributes.ReparsePoint) != 0)
                throw new IOException("The service state directory cannot use reparse points.");
        if (!Directory.Exists(_directory))
        {
            if (!ConvertStringSecurityDescriptorToSecurityDescriptor("O:SYG:SYD:P(A;;FA;;;SY)(A;;FA;;;BA)", 1, out var descriptor, out _))
                throw new Win32Exception();
            try
            {
                var attributes = new SecurityAttributes { Length = Marshal.SizeOf<SecurityAttributes>(), SecurityDescriptor = descriptor };
                if (!CreateDirectory(_directory, ref attributes)) throw new Win32Exception();
            }
            finally { LocalFree(descriptor); }
        }
        RequireSystemOwner(_directory);
        SecureAcl(_directory);
    }

    private static void SecureAcl(string path)
    {
        // Protected, inherited by children: only SYSTEM and administrators can
        // read salts, verifiers, root secrets, recovery envelopes, or rule paths.
        if (!ConvertStringSecurityDescriptorToSecurityDescriptor("O:SYG:SYD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)", 1, out var descriptor, out _))
            throw new Win32Exception();
        try
        {
            if (!SetFileSecurity(path, 0x80000007, descriptor)) throw new Win32Exception();
        }
        finally { LocalFree(descriptor); }
    }

    private static void RequireSystemOwner(string path)
    {
        if (GetNamedSecurityInfo(path, 1, 1, out var owner, out _, out _, out _, out var descriptor) != 0)
            throw new IOException("The service data owner cannot be verified.");
        try
        {
            if (owner == IntPtr.Zero || !new SecurityIdentifier(owner).IsWellKnown(WellKnownSidType.LocalSystemSid))
                throw new IOException("FileLock service data must be owned by SYSTEM. A pre-existing directory was rejected.");
        }
        finally { if (descriptor != IntPtr.Zero) LocalFree(descriptor); }
    }

    [StructLayout(LayoutKind.Sequential)] private struct SecurityAttributes { public int Length; public IntPtr SecurityDescriptor; public int InheritHandle; }
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool ConvertStringSecurityDescriptorToSecurityDescriptor(string text, uint revision, out IntPtr descriptor, out uint size);
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool SetFileSecurity(string path, uint information, IntPtr descriptor);
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode)] private static extern uint GetNamedSecurityInfo(string path, int type, uint information, out IntPtr owner, out IntPtr group, out IntPtr dacl, out IntPtr sacl, out IntPtr descriptor);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool CreateDirectory(string path, ref SecurityAttributes attributes);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
}

internal static class DataProtection
{
    public static byte[] Transform(byte[] input, bool protect)
    {
        var source = new Blob { Length = input.Length, Data = Marshal.AllocHGlobal(input.Length) };
        Marshal.Copy(input, 0, source.Data, input.Length);
        Blob output = default;
        try
        {
            var success = protect ? CryptProtectData(ref source, "FileLock path protection", IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 0x5, out output)
                : CryptUnprotectData(ref source, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 0x1, out output);
            if (!success) throw new Win32Exception();
            var result = new byte[output.Length];
            Marshal.Copy(output.Data, result, 0, result.Length);
            return result;
        }
        finally
        {
            for (var i = 0; i < source.Length; i++) Marshal.WriteByte(source.Data, i, 0);
            Marshal.FreeHGlobal(source.Data);
            if (output.Data != IntPtr.Zero)
            {
                for (var i = 0; i < output.Length; i++) Marshal.WriteByte(output.Data, i, 0);
                LocalFree(output.Data);
            }
        }
    }
    [StructLayout(LayoutKind.Sequential)] private struct Blob { public int Length; public IntPtr Data; }
    [DllImport("crypt32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool CryptProtectData(ref Blob input, string description, IntPtr entropy, IntPtr reserved, IntPtr prompt, uint flags, out Blob output);
    [DllImport("crypt32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool CryptUnprotectData(ref Blob input, IntPtr description, IntPtr entropy, IntPtr reserved, IntPtr prompt, uint flags, out Blob output);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
}

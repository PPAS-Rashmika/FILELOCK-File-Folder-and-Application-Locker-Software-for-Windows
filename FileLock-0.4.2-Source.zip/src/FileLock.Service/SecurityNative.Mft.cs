using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace FileLock.Service;

internal static partial class SecurityNative
{
    // Removal consults metadata only. A complete NTFS MFT enumeration provides
    // positive absence evidence for a retired ID that OpenFileById rejects with
    // INVALID_PARAMETER; failed/partial enumeration never authorizes forgetting.
    private static bool ConfirmMissingInMft(PermissionJournalEntry saved, ulong fileId,
        IDictionary<string, HashSet<ulong>>? volumeFiles)
    {
        if (volumeFiles?.TryGetValue(saved.VolumeIdentity, out var cached) == true) return !cached.Contains(fileId);
        using var volume = CreateFile(saved.VolumeIdentity, 0x80000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
        if (volume.IsInvalid) throw new Win32Exception(Marshal.GetLastWin32Error(), "Windows cannot verify deletion on the saved drive. The permission journal was retained.");
        var filesystem = new StringBuilder(32);
        if (!GetVolumeInformationByHandle(volume, null, 0, out var serial, out _, out _, filesystem, (uint)filesystem.Capacity))
            throw new Win32Exception();
        if (filesystem.ToString() != "NTFS" || !saved.FileIdentity.StartsWith(serial.ToString("X8") + ":", StringComparison.Ordinal))
            throw new IOException("The original NTFS drive cannot be verified. The permission journal was retained.");

        var files = new HashSet<ulong>();
        var input = new MftEnumeration { LowUsn = 0, HighUsn = long.MaxValue };
        var output = new byte[64 * 1024];
        var deadline = DateTimeOffset.UtcNow.AddSeconds(20);
        while (true)
        {
            if (DateTimeOffset.UtcNow >= deadline || files.Count > 2_000_000)
                throw new IOException("Windows could not finish verifying deletion within its safety limit. The permission journal was retained.");
            if (!DeviceIoControl(volume, 0x000900B3, ref input, (uint)Marshal.SizeOf<MftEnumeration>(), output,
                (uint)output.Length, out var length, IntPtr.Zero))
            {
                var error = Marshal.GetLastWin32Error();
                if (error == 38) break; // ERROR_HANDLE_EOF: all MFT records enumerated.
                throw new Win32Exception(error, "Windows could not complete deletion verification. The permission journal was retained.");
            }
            if (length < 8 || length > output.Length) throw new IOException("Invalid NTFS metadata enumeration; the permission journal was retained.");
            var next = BitConverter.ToUInt64(output, 0);
            for (var offset = 8; offset < length;)
            {
                if (length - offset < 60 || BitConverter.ToUInt16(output, offset + 4) != 2)
                    throw new IOException("Unsupported NTFS metadata record; the permission journal was retained.");
                var recordLength = BitConverter.ToUInt32(output, offset);
                if (recordLength < 60 || recordLength > length - offset)
                    throw new IOException("Invalid NTFS metadata record; the permission journal was retained.");
                files.Add(BitConverter.ToUInt64(output, offset + 8));
                offset += checked((int)recordLength);
            }
            if (next <= input.StartFileReferenceNumber) throw new IOException("Incomplete NTFS metadata enumeration; the permission journal was retained.");
            input.StartFileReferenceNumber = next;
        }
        volumeFiles?.Add(saved.VolumeIdentity, files);
        return !files.Contains(fileId);
    }

    [StructLayout(LayoutKind.Sequential)] private struct MftEnumeration
    {
        public ulong StartFileReferenceNumber;
        public long LowUsn, HighUsn;
    }
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "GetVolumeInformationByHandleW")]
    private static extern bool GetVolumeInformationByHandle(SafeFileHandle handle, StringBuilder? name, uint nameLength,
        out uint serial, out uint componentLength, out uint flags, StringBuilder filesystem, uint filesystemLength);
    [DllImport("kernel32.dll", SetLastError = true)] private static extern bool DeviceIoControl(SafeFileHandle handle,
        uint control, ref MftEnumeration input, uint inputLength, [Out] byte[] output, uint outputLength,
        out uint returned, IntPtr overlapped);
}

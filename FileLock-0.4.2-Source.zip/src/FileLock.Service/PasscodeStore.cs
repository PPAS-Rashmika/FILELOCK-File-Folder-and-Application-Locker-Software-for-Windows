using System.Security.Cryptography;
using System.Text;
using FileLock.Shared;

namespace FileLock.Service;

internal static class PasscodeStore
{
    private const int Iterations = 350_000;

    public static (string Salt, string Hash) Create(string pin, byte[] rootSecret)
    {
        PinRules.Ensure(pin);
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Derive(pin, salt, rootSecret);
        try { return (Convert.ToBase64String(salt), Convert.ToBase64String(hash)); }
        finally { CryptographicOperations.ZeroMemory(hash); }
    }

    public static bool Verify(string pin, string saltText, string hashText, byte[] rootSecret)
    {
        if (!PinRules.IsValid(pin)) return false;
        var expected = Convert.FromBase64String(hashText);
        var actual = Derive(pin, Convert.FromBase64String(saltText), rootSecret);
        try { return CryptographicOperations.FixedTimeEquals(actual, expected); }
        finally { CryptographicOperations.ZeroMemory(actual); CryptographicOperations.ZeroMemory(expected); }
    }

    private static byte[] Derive(string pin, byte[] salt, byte[] rootSecret)
    {
        var derived = Rfc2898DeriveBytes.Pbkdf2(pin, salt, Iterations, HashAlgorithmName.SHA256, 32);
        try { return HMACSHA256.HashData(rootSecret, derived); }
        finally { CryptographicOperations.ZeroMemory(derived); }
    }

    public static (string Key, string Envelope) CreateRecovery(byte[] rootSecret)
    {
        var key = RandomNumberGenerator.GetBytes(32);
        var nonce = RandomNumberGenerator.GetBytes(12);
        var cipher = new byte[rootSecret.Length];
        var tag = new byte[16];
        using (var aes = new AesGcm(key, 16)) aes.Encrypt(nonce, rootSecret, cipher, tag, Encoding.UTF8.GetBytes("FileLock.PathGate.Recovery.v1"));
        var envelope = new byte[nonce.Length + tag.Length + cipher.Length];
        nonce.CopyTo(envelope, 0); tag.CopyTo(envelope, 12); cipher.CopyTo(envelope, 28);
        var text = Convert.ToHexString(key);
        CryptographicOperations.ZeroMemory(key);
        return (string.Join('-', Enumerable.Range(0, 8).Select(i => text.Substring(i * 8, 8))), Convert.ToBase64String(envelope));
    }

    public static bool VerifyRecovery(string? recoveryKey, string envelopeText, byte[] expectedRoot)
    {
        byte[]? key = null;
        byte[]? recovered = null;
        try
        {
            var normalized = (recoveryKey ?? "").Replace("-", "", StringComparison.Ordinal).Replace(" ", "", StringComparison.Ordinal).Trim();
            if (normalized.Length != 64) return false;
            key = Convert.FromHexString(normalized);
            var envelope = Convert.FromBase64String(envelopeText);
            if (envelope.Length != 60) return false;
            recovered = new byte[32];
            using (var aes = new AesGcm(key, 16)) aes.Decrypt(envelope.AsSpan(0, 12), envelope.AsSpan(28), envelope.AsSpan(12, 16), recovered, Encoding.UTF8.GetBytes("FileLock.PathGate.Recovery.v1"));
            return CryptographicOperations.FixedTimeEquals(recovered, expectedRoot);
        }
        catch (Exception error) when (error is FormatException or CryptographicException or ArgumentException) { return false; }
        finally
        {
            if (key != null) CryptographicOperations.ZeroMemory(key);
            if (recovered != null) CryptographicOperations.ZeroMemory(recovered);
        }
    }
}

using FileLock.Shared;

namespace FileLock.Service;

internal sealed class GateState
{
    public int Version { get; set; } = 1;
    public List<UserState> Users { get; set; } = [];
}

internal sealed class UserState
{
    public string OwnerSid { get; set; } = "";
    public string RootSecret { get; set; } = "";
    public string MasterSalt { get; set; } = "";
    public string MasterHash { get; set; } = "";
    public string RecoveryEnvelope { get; set; } = "";
    public int FailedAttempts { get; set; }
    public DateTimeOffset? RetryAfterUtc { get; set; }
    public List<ItemState> Items { get; set; } = [];
}

internal sealed class ItemState
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string OriginalPath { get; set; } = "";
    public string NtPath { get; set; } = "";
    public string VolumeIdentity { get; set; } = "";
    public ProtectionKind Kind { get; set; }
    public DateTimeOffset AddedUtc { get; set; }
    public string? PinSalt { get; set; }
    public string? PinHash { get; set; }
    public string OwnerSid { get; set; } = "";
    public List<PermissionJournalEntry> PermissionJournal { get; set; } = [];
    public DateTimeOffset? ActiveLeaseUntilUtc { get; set; }
    public string ProtectionPhase { get; set; } = "Staged";
    public string? ProtectionError { get; set; }
}

internal sealed class PermissionJournalEntry
{
    public string RelativePath { get; set; } = "";
    public string VolumeIdentity { get; set; } = "";
    public string FileIdentity { get; set; } = "";
    public string OriginalSecurityDescriptor { get; set; } = "";
    public bool IsDirectory { get; set; }
}

internal sealed record CallerContext(string Sid, uint SessionId, System.Security.Principal.WindowsIdentity Identity) : IDisposable
{
    public void Dispose() => Identity.Dispose();
}

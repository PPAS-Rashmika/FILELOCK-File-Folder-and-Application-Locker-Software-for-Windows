using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using FileLock.Shared;
using Microsoft.Win32.SafeHandles;

namespace FileLock.Service;

// All file operations below change security only. No contents are read, moved,
// encrypted, renamed, or deleted. Handles bind each change to a verified object.
internal static partial class SecurityNative
{
    internal static readonly Guid FileSystemAuditCategory = new("0CCE921D-69AE-11D9-BED3-505054503030");
    internal static readonly Guid HandleManipulationAuditCategory = new("0CCE9223-69AE-11D9-BED3-505054503030");
    internal const int ContentAccessMask = 0x000D017F; // data/list, write, execute, delete, ACL/owner

    internal static void EnableRequiredPrivileges()
    {
        using var identity = WindowsIdentity.GetCurrent();
        if (!identity.IsSystem) throw new UnauthorizedAccessException("Original-location protection must run in the LocalSystem service.");
        foreach (var name in new[] { "SeSecurityPrivilege", "SeRestorePrivilege", "SeBackupPrivilege", "SeTakeOwnershipPrivilege" })
        {
            if (!LookupPrivilegeValue(null, name, out var luid)) throw new Win32Exception();
            var privilege = new TokenPrivileges { Count = 1, Luid = luid, Attributes = 2 };
            if (!AdjustTokenPrivileges(identity.AccessToken, false, ref privilege, 0, IntPtr.Zero, IntPtr.Zero)) throw new Win32Exception();
            var error = Marshal.GetLastWin32Error();
            if (error != 0) throw new Win32Exception(error, "The service cannot enable " + name + ".");
        }
    }

    internal static bool FailureAuditingEnabled()
        // Both policies are required by the verified original-path denial
        // flow. File System alone did not generate 4656 failures on Windows.
        => CategoryFailureAuditingEnabled(FileSystemAuditCategory) && CategoryFailureAuditingEnabled(HandleManipulationAuditCategory);

    private static bool CategoryFailureAuditingEnabled(Guid category)
    {
        if (!AuditQuerySystemPolicy(ref category, 1, out var policy)) return false;
        try { return (Marshal.PtrToStructure<AuditPolicyInformation>(policy).Information & 2) != 0; }
        finally { AuditFree(policy); }
    }

    internal sealed class OpenObject : IDisposable
    {
        internal SafeFileHandle Handle { get; }
        internal string Path { get; }
        internal string NtPath { get; }
        internal PermissionJournalEntry Entry { get; }
        internal OpenObject(SafeFileHandle handle, string path, string ntPath, PermissionJournalEntry entry) { Handle = handle; Path = path; NtPath = ntPath; Entry = entry; }
        public void Dispose() => Handle.Dispose();
    }

    internal static OpenObject Open(string path, string relativePath, bool captureSecurity, bool exclusive = false)
    {
        // Security-only access permits relocking even while another process
        // keeps a content handle open. NtSetSecurityObject updates precisely
        // this held object without the Win32 tree propagation convenience layer.
        var handle = CreateFile(path, 0x011E0080, exclusive ? 0U : 3U, IntPtr.Zero, 3, 0x02000000 | 0x00200000, IntPtr.Zero);
        if (handle.IsInvalid) { var error = Marshal.GetLastWin32Error(); handle.Dispose(); throw new Win32Exception(error, "Close programs using this location and try again: " + path); }
        try
        {
            if (!GetFileInformationByHandle(handle, out var info)) throw new Win32Exception();
            if ((info.Attributes & FileAttributes.ReparsePoint) != 0) throw new GateException("Symbolic links, junctions, and cloud placeholders cannot be protected.", "INVALID_PATH");
            var directory = (info.Attributes & FileAttributes.Directory) != 0;
            if (!directory && info.NumberOfLinks != 1) throw new GateException("Hardlinked files cannot be protected.", "INVALID_PATH");
            var volumePath = FinalPath(handle, 1);
            var end = volumePath.IndexOf('}');
            if (!volumePath.StartsWith(@"\\?\Volume{", StringComparison.OrdinalIgnoreCase) || end < 0) throw new IOException("Cannot verify the NTFS volume identity.");
            var dosPath = FinalPath(handle, 0);
            if (!dosPath.StartsWith(@"\\?\", StringComparison.Ordinal) || !dosPath[4..].Equals(path, StringComparison.OrdinalIgnoreCase))
                throw new IOException("The path changed or contains an unsupported alias.");
            var ntPath = FinalPath(handle, 2);
            if (!PathPolicy.IsValidNtPath(ntPath)) throw new IOException("The verified object has an unsupported device path.");
            var entry = new PermissionJournalEntry
            {
                RelativePath = relativePath, VolumeIdentity = volumePath[..(end + 1)],
                FileIdentity = $"{info.VolumeSerial:X8}:{info.IndexHigh:X8}{info.IndexLow:X8}", IsDirectory = directory,
                OriginalSecurityDescriptor = captureSecurity ? Convert.ToBase64String(ReadDescriptor(handle)) : ""
            };
            return new(handle, path, ntPath, entry);
        }
        catch { handle.Dispose(); throw; }
    }

    internal static byte[] ReadDescriptor(SafeFileHandle handle)
    {
        var error = GetSecurityInfo(handle, 1, 15, out _, out _, out _, out _, out var descriptor);
        if (error != 0) throw new Win32Exception((int)error, "Cannot save the original Windows permissions.");
        try
        {
            var length = GetSecurityDescriptorLength(descriptor);
            if (length < 20 || length > 64 * 1024) throw new IOException("The Windows security descriptor is invalid or too large.");
            var bytes = new byte[length]; Marshal.Copy(descriptor, bytes, 0, bytes.Length);
            _ = new RawSecurityDescriptor(bytes, 0);
            return bytes;
        }
        finally { LocalFree(descriptor); }
    }

    internal static RawSecurityDescriptor LockedDescriptor(PermissionJournalEntry entry, string ownerSid)
    {
        var original = new RawSecurityDescriptor(Convert.FromBase64String(entry.OriginalSecurityDescriptor), 0);
        var inheritance = entry.IsDirectory ? AceFlags.ContainerInherit | AceFlags.ObjectInherit : AceFlags.None;
        // Explorer's Continue helper runs elevated and permanently grants the
        // caller FullControl when Administrators have WRITE_DAC. Only the
        // SYSTEM broker may change a locked item's permissions or read content.
        var dacl = new RawAcl(2, 2);
        dacl.InsertAce(0, new CommonAce(inheritance, AceQualifier.AccessAllowed, 0x1F01FF, new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), false, null));
        dacl.InsertAce(1, new CommonAce(inheritance, AceQualifier.AccessAllowed, 0x120080, new SecurityIdentifier(ownerSid), false, null));
        var sacl = new RawAcl(original.SystemAcl?.Revision ?? 2, (original.SystemAcl?.Count ?? 0) + 1);
        if (original.SystemAcl != null) for (var index = 0; index < original.SystemAcl.Count; index++) sacl.InsertAce(sacl.Count, original.SystemAcl[index].Copy());
        sacl.InsertAce(sacl.Count, new CommonAce(inheritance | AceFlags.FailedAccess, AceQualifier.SystemAudit, ContentAccessMask, new SecurityIdentifier(ownerSid), false, null));
        var flags = ControlFlags.DiscretionaryAclPresent | ControlFlags.SystemAclPresent | ControlFlags.DiscretionaryAclProtected | ControlFlags.SystemAclProtected;
        return new(flags, new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), original.Group, sacl, dacl);
    }

    internal static void WriteDescriptor(SafeFileHandle handle, RawSecurityDescriptor security)
    {
        var bytes = new byte[security.BinaryLength]; security.GetBinaryForm(bytes, 0);
        var pin = GCHandle.Alloc(bytes, GCHandleType.Pinned);
        try
        {
            var pointer = pin.AddrOfPinnedObject();
            uint information = 15;
            information |= security.ControlFlags.HasFlag(ControlFlags.DiscretionaryAclProtected) ? 0x80000000U : 0x20000000U;
            information |= security.ControlFlags.HasFlag(ControlFlags.SystemAclProtected) ? 0x40000000U : 0x10000000U;
            var status = NtSetSecurityObject(handle, information, pointer);
            if (status < 0) throw new Win32Exception((int)RtlNtStatusToDosError(status), "Cannot apply the saved Windows permissions.");
        }
        finally { pin.Free(); }
    }

    internal static void Restore(OpenObject target, PermissionJournalEntry entry) => WriteDescriptor(target.Handle, new(Convert.FromBase64String(entry.OriginalSecurityDescriptor), 0));
    internal static void Lock(OpenObject target, PermissionJournalEntry entry, string sid) => WriteDescriptor(target.Handle, LockedDescriptor(entry, sid));
    internal static bool IdentityMatches(PermissionJournalEntry left, PermissionJournalEntry right) => left.FileIdentity.Equals(right.FileIdentity, StringComparison.Ordinal)
        && left.VolumeIdentity.Equals(right.VolumeIdentity, StringComparison.OrdinalIgnoreCase) && left.IsDirectory == right.IsDirectory;

    internal static string? LocateOriginal(PermissionJournalEntry saved, bool proveMissing = false,
        IDictionary<string, HashSet<ulong>>? volumeFiles = null)
    {
        if (saved.FileIdentity.Length != 25 || !ulong.TryParse(saved.FileIdentity.AsSpan(9), System.Globalization.NumberStyles.HexNumber,
            System.Globalization.CultureInfo.InvariantCulture, out var fileId))
            throw new IOException("The saved file identity cannot be verified; the permission journal was retained.");
        using var volume = CreateFile(saved.VolumeIdentity + "\\", 0x80, 3, IntPtr.Zero, 3, 0x02000000 | 0x00200000, IntPtr.Zero);
        if (volume.IsInvalid) throw new Win32Exception(Marshal.GetLastWin32Error(), "The saved NTFS volume is unavailable. Reconnect it before repairing this location.");
        if (!GetFileInformationByHandle(volume, out var volumeInfo)) throw new Win32Exception();
        if (!saved.FileIdentity.StartsWith(volumeInfo.VolumeSerial.ToString("X8") + ":", StringComparison.Ordinal))
            throw new IOException("The saved drive now has a different identity. Its permission journal has been retained.");
        var filesystem = new StringBuilder(32);
        if (!GetVolumeInformationByHandle(volume, null, 0, out var serial, out _, out _, filesystem, (uint)filesystem.Capacity))
            throw new Win32Exception();
        if (filesystem.ToString() != "NTFS" || serial != volumeInfo.VolumeSerial)
            throw new IOException("The original NTFS drive could not be verified. The permission journal was retained.");
        var descriptor = new FileIdDescriptor { Size = 24, Type = 0, FileId = fileId };
        using var handle = OpenFileById(volume, ref descriptor, 0x80, 3, IntPtr.Zero, 0x02000000 | 0x00200000);
        if (handle.IsInvalid)
        {
            var error = Marshal.GetLastWin32Error();
            if (error == 2) return null;
            if (error == 87)
            {
                // NTFS can reject a retired file ID with INVALID_PARAMETER.
                // That error alone is never used to discard its journal.
                if (proveMissing && ConfirmMissingInMft(saved, fileId, volumeFiles)) return null;
                throw new GateException("The saved item could not be located. If it was deleted, choose Manage > Remove protection to verify deletion and restore any surviving objects. Its permission journal was retained.", "LOCATION_NOT_FOUND");
            }
            throw new Win32Exception(error, "Windows could not locate the saved object. The permission journal was retained.");
        }
        if (!GetFileInformationByHandle(handle, out var info)) throw new Win32Exception();
        if (info.Attributes.HasFlag(FileAttributes.ReparsePoint) || (!saved.IsDirectory && info.NumberOfLinks != 1))
            throw new IOException("The saved object now uses an unsupported link. The permission journal was retained.");
        var volumePath = FinalPath(handle, 1);
        var end = volumePath.IndexOf('}');
        var current = new PermissionJournalEntry
        {
            VolumeIdentity = end >= 0 ? volumePath[..(end + 1)] : "",
            FileIdentity = $"{info.VolumeSerial:X8}:{info.IndexHigh:X8}{info.IndexLow:X8}",
            IsDirectory = info.Attributes.HasFlag(FileAttributes.Directory)
        };
        if (!IdentityMatches(saved, current)) throw new IOException("Windows returned a different object; the saved permissions were left unchanged.");
        var path = FinalPath(handle, 0);
        if (!path.StartsWith(@"\\?\", StringComparison.Ordinal) || path.Length < 7 || path[5] != ':')
            throw new IOException("The original object has no supported drive-letter location. The permission journal was retained.");
        return path[4..];
    }

    internal static IDisposable HoldRecoveryAncestors(string path, ISet<string>? heldPaths = null)
    {
        var held = new HeldDirectories();
        try
        {
            for (var parent = Path.GetDirectoryName(path); !string.IsNullOrEmpty(parent) && parent != Path.GetPathRoot(parent); parent = Path.GetDirectoryName(parent))
            {
                if (heldPaths?.Contains(parent) == true) continue;
                var handle = CreateFile(parent, 0x80, 3, IntPtr.Zero, 3, 0x02000000 | 0x00200000, IntPtr.Zero);
                held.Handles.Add(handle);
                if (handle.IsInvalid) throw new Win32Exception(Marshal.GetLastWin32Error(), "Close programs changing this folder's parent location and try again.");
                if (!GetFileInformationByHandle(handle, out var info)) throw new Win32Exception();
                if (!info.Attributes.HasFlag(FileAttributes.Directory) || info.Attributes.HasFlag(FileAttributes.ReparsePoint)
                    || !FinalPath(handle, 0).Equals(@"\\?\" + parent, StringComparison.OrdinalIgnoreCase))
                    throw new IOException("A parent location changed or uses an unsupported alias.");
                heldPaths?.Add(parent);
            }
            return held;
        }
        catch { held.Dispose(); throw; }
    }
    private sealed class HeldDirectories : IDisposable
    {
        internal readonly List<SafeFileHandle> Handles = [];
        public void Dispose() { foreach (var handle in Handles) handle.Dispose(); }
    }

    private static string FinalPath(SafeFileHandle handle, uint flags)
    {
        var text = new StringBuilder(2048); var length = GetFinalPathNameByHandle(handle, text, (uint)text.Capacity, flags);
        if (length == 0 || length >= text.Capacity) throw new Win32Exception();
        return text.ToString();
    }

    [StructLayout(LayoutKind.Sequential)] private struct FileInformation { public FileAttributes Attributes; public System.Runtime.InteropServices.ComTypes.FILETIME Creation, Access, Write; public uint VolumeSerial, SizeHigh, SizeLow, NumberOfLinks, IndexHigh, IndexLow; }
    [StructLayout(LayoutKind.Explicit, Size = 24)] private struct FileIdDescriptor
    {
        [FieldOffset(0)] public uint Size;
        [FieldOffset(4)] public uint Type;
        [FieldOffset(8)] public ulong FileId;
    }
    [StructLayout(LayoutKind.Sequential)] private struct Luid { public uint Low; public int High; }
    [StructLayout(LayoutKind.Sequential)] private struct TokenPrivileges { public uint Count; public Luid Luid; public uint Attributes; }
    [StructLayout(LayoutKind.Sequential)] private struct AuditPolicyInformation { public Guid Subcategory; public uint Information; public Guid Category; }
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool LookupPrivilegeValue(string? system, string name, out Luid luid);
    [DllImport("advapi32.dll", SetLastError = true)] private static extern bool AdjustTokenPrivileges(SafeAccessTokenHandle token, bool disableAll, ref TokenPrivileges privileges, uint size, IntPtr previous, IntPtr returned);
    [DllImport("advapi32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.U1)] private static extern bool AuditQuerySystemPolicy(ref Guid category, uint count, out IntPtr policy);
    [DllImport("advapi32.dll")] private static extern void AuditFree(IntPtr memory);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern SafeFileHandle CreateFile(string path, uint access, uint share, IntPtr attributes, uint creation, uint flags, IntPtr template);
    [DllImport("kernel32.dll", SetLastError = true)] private static extern SafeFileHandle OpenFileById(SafeFileHandle volume, ref FileIdDescriptor descriptor, uint access, uint share, IntPtr attributes, uint flags);
    [DllImport("kernel32.dll", SetLastError = true)] private static extern bool GetFileInformationByHandle(SafeFileHandle handle, out FileInformation information);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern uint GetFinalPathNameByHandle(SafeFileHandle handle, StringBuilder path, uint size, uint flags);
    [DllImport("advapi32.dll")] private static extern uint GetSecurityInfo(SafeFileHandle handle, int type, uint information, out IntPtr owner, out IntPtr group, out IntPtr dacl, out IntPtr sacl, out IntPtr descriptor);
    [DllImport("ntdll.dll")] private static extern int NtSetSecurityObject(SafeFileHandle handle, uint information, IntPtr descriptor);
    [DllImport("ntdll.dll")] private static extern uint RtlNtStatusToDosError(int status);
    [DllImport("advapi32.dll")] private static extern uint GetSecurityDescriptorLength(IntPtr descriptor);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
}

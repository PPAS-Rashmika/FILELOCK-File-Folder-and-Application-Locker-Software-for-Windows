using System.ComponentModel;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text.Json;
using FileLock.Shared;
using Microsoft.Win32.SafeHandles;

namespace FileLock.Service;

internal sealed class BrokerServer : IDisposable
{
    private readonly BrokerEngine _engine = new();
    private readonly SemaphoreSlim _workers = new(16, 16);
    private readonly List<Task> _tasks = [];

    public async Task RunAsync(CancellationToken cancellationToken)
    {
        using var first = CreatePipe(true);
        NamedPipeServerStream listener = first;
        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                await _workers.WaitAsync(cancellationToken);
                try { await listener.WaitForConnectionAsync(cancellationToken); }
                catch { _workers.Release(); throw; }
                var accepted = listener;
                // Keep an instance alive before dispatching the accepted request,
                // so a fast client cannot remove the named-pipe object in between.
                listener = CreatePipe(false);
                var task = HandleAsync(accepted, cancellationToken);
                _tasks.RemoveAll(t => t.IsCompleted);
                _tasks.Add(task);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { }
        finally
        {
            listener.Dispose();
            await Task.WhenAll(_tasks);
        }
    }

    private async Task HandleAsync(NamedPipeServerStream pipe, CancellationToken shutdown)
    {
        using (pipe)
        using (var timeout = CancellationTokenSource.CreateLinkedTokenSource(shutdown))
        {
            timeout.CancelAfter(TimeSpan.FromSeconds(30));
            try
            {
                var bytes = await BrokerProtocol.ReadLineAsync(pipe, timeout.Token);
                using var caller = GetCaller(pipe);
                var request = JsonSerializer.Deserialize<BrokerRequest>(bytes, BrokerProtocol.JsonOptions)
                    ?? throw new GateException("Invalid service request.", "INVALID_REQUEST");
                var response = await _engine.ExecuteAsync(request, caller, timeout.Token);
                await BrokerProtocol.WriteLineAsync(pipe, response, timeout.Token);
            }
            catch (Exception error) when (error is IOException or OperationCanceledException or JsonException or GateException or Win32Exception or UnauthorizedAccessException)
            {
                try
                {
                    var response = new BrokerResponse { Ok = false, Error = error is GateException ? error.Message : "The service request could not be authenticated or processed.", ErrorCode = error is GateException gate ? gate.Code : "INVALID_REQUEST" };
                    await BrokerProtocol.WriteLineAsync(pipe, response, timeout.Token);
                }
                catch (Exception failed) when (failed is IOException or OperationCanceledException or ObjectDisposedException) { }
            }
            finally { _workers.Release(); }
        }
    }

    private static CallerContext GetCaller(NamedPipeServerStream pipe)
    {
        CallerContext? caller = null;
        pipe.RunAsClient(() =>
        {
            var identity = WindowsIdentity.GetCurrent(TokenAccessLevels.Query | TokenAccessLevels.Duplicate | TokenAccessLevels.Impersonate);
            try
            {
                if (!identity.IsAuthenticated || identity.IsAnonymous || identity.IsSystem || identity.User is not { } sid || !sid.IsAccountSid())
                    throw new GateException("Use an authenticated Windows desktop account.", "UNAUTHORIZED_CLIENT");
                if (!GetTokenInformation(identity.AccessToken, 12, out uint sessionId, sizeof(uint), out _)) throw new Win32Exception();
                if (sessionId == 0) throw new GateException("FileLock requests must come from an interactive Windows session.", "UNAUTHORIZED_CLIENT");
                caller = new(sid.Value, sessionId, identity);
                identity = null!;
            }
            finally { identity?.Dispose(); }
        });
        return caller ?? throw new GateException("Windows account identity is unavailable.", "UNAUTHORIZED_CLIENT");
    }

    private static NamedPipeServerStream CreatePipe(bool first)
    {
        // AU can read/write and query owner, but cannot create server instances.
        const string security = "O:SYG:SYD:P(A;;FA;;;SY)(A;;FA;;;BA)(A;;0x0012019B;;;AU)";
        if (!ConvertStringSecurityDescriptorToSecurityDescriptor(security, 1, out var descriptor, out _)) throw new Win32Exception();
        try
        {
            var attributes = new SecurityAttributes { Length = Marshal.SizeOf<SecurityAttributes>(), Descriptor = descriptor };
            var handle = CreateNamedPipe("\\\\.\\pipe\\" + BrokerProtocol.PipeName, 3U | 0x40000000U | (first ? 0x80000U : 0U), 8, 32, 65536, 65536, 0, ref attributes);
            if (handle.IsInvalid) { handle.Dispose(); throw new Win32Exception(); }
            return new NamedPipeServerStream(PipeDirection.InOut, true, false, handle);
        }
        finally { LocalFree(descriptor); }
    }

    public void Dispose() { _engine.Dispose(); _workers.Dispose(); }
    [StructLayout(LayoutKind.Sequential)] private struct SecurityAttributes { public int Length; public IntPtr Descriptor; public int Inherit; }
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool ConvertStringSecurityDescriptorToSecurityDescriptor(string text, uint revision, out IntPtr descriptor, out uint size);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern SafePipeHandle CreateNamedPipe(string name, uint mode, uint pipeMode, uint maxInstances, uint outputSize, uint inputSize, uint timeout, ref SecurityAttributes attributes);
    [DllImport("advapi32.dll", SetLastError = true)] private static extern bool GetTokenInformation(SafeAccessTokenHandle token, int information, out uint value, int length, out int needed);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
}

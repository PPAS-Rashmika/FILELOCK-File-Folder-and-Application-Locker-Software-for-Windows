using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;

namespace FileLock;

internal static class Ui
{
    internal static TextBlock Text(string text, double size = 13, string color = "#172332", FontWeight? weight = null) => new()
    {
        Text = text, FontSize = size, Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color)),
        FontWeight = weight ?? FontWeights.Normal, TextWrapping = TextWrapping.Wrap
    };

    internal static Border Card(UIElement child) => new()
    {
        Child = child, Background = Brushes.White, BorderBrush = new SolidColorBrush(Color.FromRgb(232, 236, 241)),
        BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(8), Padding = new Thickness(22), Margin = new Thickness(0, 0, 0, 14)
    };

    internal static void Numeric(PasswordBox box)
    {
        box.MaxLength = 6;
        box.PreviewTextInput += (_, e) => e.Handled = e.Text.Any(c => c < '0' || c > '9');
        DataObject.AddPastingHandler(box, (_, e) =>
        {
            if (!e.DataObject.GetDataPresent(DataFormats.UnicodeText) || e.DataObject.GetData(DataFormats.UnicodeText) is not string s || s.Any(c => c < '0' || c > '9')) e.CancelCommand();
        });
    }

    internal static bool IsPin(string pin) => pin.Length == 6 && pin.All(c => c is >= '0' and <= '9');

    internal static void ShowError(Window? owner, Exception error)
    {
        if (owner is { IsVisible: true }) MessageBox.Show(owner, error.Message, "FileLock", MessageBoxButton.OK, MessageBoxImage.Warning);
        else MessageBox.Show(error.Message, "FileLock", MessageBoxButton.OK, MessageBoxImage.Warning);
    }
}

internal sealed class PinDialog : Window
{
    private readonly PasswordBox _pin = new();
    private readonly PasswordBox _confirm = new();
    private readonly TextBlock _error = Ui.Text("", 12, "#B42318");
    private readonly Button _submit;
    private readonly Button _cancel;
    private readonly RadioButton? _sharedChoice;
    private readonly RadioButton? _individualChoice;
    private bool _working;
    private readonly bool _confirmation;
    private readonly Func<string, Task>? _verify;
    internal string Pin { get; private set; } = "";
    internal bool UseShared { get; private set; }

    internal PinDialog(Window? owner, string heading, string description, string action = "Continue", bool confirm = false, Func<string, Task>? verify = null, bool offerShared = false)
    {
        // Access prompts have no management-window owner. In particular, showing
        // an owned modal dialog must never resurrect a hidden settings window.
        if (owner is { IsVisible: true }) Owner = owner;
        Title = "FileLock · Passcode"; Width = 440; SizeToContent = SizeToContent.Height; ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = Owner is null ? WindowStartupLocation.CenterScreen : WindowStartupLocation.CenterOwner;
        ShowInTaskbar = Owner is null; Icon = (ImageSource)Application.Current.FindResource("LockLogo");
        _confirmation = confirm || offerShared; _verify = verify;
        var panel = new StackPanel { Margin = new Thickness(30) };
        panel.Children.Add(new Image { Source = Icon, Width = 45, Height = 45, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 0, 0, 22) });
        panel.Children.Add(Ui.Text(heading, 24, weight: FontWeights.SemiBold));
        var detail = Ui.Text(description, 13, "#637083"); detail.Margin = new Thickness(0, 10, 0, 22); panel.Children.Add(detail);
        var pinInputs = new StackPanel();
        if (offerShared)
        {
            panel.Children.Add(Ui.Text("Choose a passcode for this location", 12, weight: FontWeights.SemiBold));
            var choiceGroup = "LocationPasscode" + Guid.NewGuid().ToString("N");
            _sharedChoice = new RadioButton { Content = "Shared master passcode", GroupName = choiceGroup, Margin = new Thickness(0, 10, 0, 10) };
            _individualChoice = new RadioButton { Content = "Separate passcode for this location", GroupName = choiceGroup, Margin = new Thickness(0, 0, 0, 18) };
            var sharedDetail = Ui.Text("This location will use your existing master passcode.", 12, "#637083");
            sharedDetail.Margin = new Thickness(0, 0, 0, 16); sharedDetail.Visibility = Visibility.Collapsed;
            pinInputs.Visibility = Visibility.Collapsed;
            _pin.IsEnabled = false; _confirm.IsEnabled = false;
            _sharedChoice.Checked += (_, _) =>
            {
                UseShared = true; Pin = ""; _pin.Clear(); _confirm.Clear(); _error.Text = "";
                _pin.IsEnabled = false; _confirm.IsEnabled = false;
                pinInputs.Visibility = Visibility.Collapsed; sharedDetail.Visibility = Visibility.Visible;
            };
            _individualChoice.Checked += (_, _) =>
            {
                UseShared = false; _error.Text = ""; _pin.IsEnabled = true; _confirm.IsEnabled = true;
                sharedDetail.Visibility = Visibility.Collapsed; pinInputs.Visibility = Visibility.Visible;
                _pin.Focus();
            };
            panel.Children.Add(_sharedChoice); panel.Children.Add(_individualChoice); panel.Children.Add(sharedDetail);
        }
        pinInputs.Children.Add(Ui.Text("6-digit passcode", 12, weight: FontWeights.SemiBold));
        Ui.Numeric(_pin); _pin.Margin = new Thickness(0, 8, 0, 16); pinInputs.Children.Add(_pin);
        if (_confirmation)
        {
            pinInputs.Children.Add(Ui.Text("Confirm passcode", 12, weight: FontWeights.SemiBold));
            Ui.Numeric(_confirm); _confirm.Margin = new Thickness(0, 8, 0, 16); pinInputs.Children.Add(_confirm);
        }
        panel.Children.Add(pinInputs);
        _error.Margin = new Thickness(0, 0, 0, 14); panel.Children.Add(_error);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        _cancel = new Button { Content = "Cancel", IsCancel = true, Margin = new Thickness(0, 0, 8, 0) };
        _cancel.Click += (_, _) => DialogResult = false;
        _submit = new Button { Content = action, IsDefault = true, Style = (Style)Application.Current.FindResource("PrimaryButton") };
        _submit.Click += Submit_Click; buttons.Children.Add(_cancel); buttons.Children.Add(_submit); panel.Children.Add(buttons); Content = panel;
        Loaded += (_, _) => { Activate(); if (_sharedChoice is null) _pin.Focus(); else _sharedChoice.Focus(); };
        Closing += (_, e) => { if (_working) e.Cancel = true; };
    }

    private async void Submit_Click(object sender, RoutedEventArgs e)
    {
        if (_working) return;
        if (_sharedChoice is not null && _sharedChoice.IsChecked != true && _individualChoice!.IsChecked != true)
        {
            _error.Text = "Choose the shared master passcode or a separate passcode.";
            _sharedChoice.Focus(); return;
        }
        if (!UseShared && !Ui.IsPin(_pin.Password)) { _error.Text = "Enter exactly six digits (0–9)."; _pin.Focus(); return; }
        if (!UseShared && _confirmation && _pin.Password != _confirm.Password) { _error.Text = "The two passcodes do not match."; _confirm.Focus(); return; }
        var selectedPin = UseShared ? "" : _pin.Password;
        _working = true; _submit.IsEnabled = false; _cancel.IsEnabled = false; _error.Text = "";
        try
        {
            if (_verify is not null) await _verify(selectedPin);
            Pin = selectedPin; _pin.Clear(); _confirm.Clear(); _working = false; DialogResult = true;
        }
        catch (Exception ex) { _error.Text = ex.Message; _pin.Clear(); _confirm.Clear(); _pin.Focus(); }
        finally { _working = false; _submit.IsEnabled = true; _cancel.IsEnabled = true; }
    }
}

internal sealed class RecoveryKeyDialog : Window
{
    internal RecoveryKeyDialog(Window owner, string key)
    {
        Owner = owner; Title = "Save your recovery key"; Width = 510; SizeToContent = SizeToContent.Height; ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        var panel = new StackPanel { Margin = new Thickness(30) };
        panel.Children.Add(Ui.Text("Keep a way back in", 25, weight: FontWeights.SemiBold));
        var intro = Ui.Text("Save this recovery key somewhere safe. It lets you set a new passcode if you forget yours.", 13, "#637083"); intro.Margin = new Thickness(0, 12, 0, 20); panel.Children.Add(intro);
        var keybox = new TextBox { Text = key, IsReadOnly = true, TextWrapping = TextWrapping.Wrap, FontFamily = new FontFamily("Consolas"), FontSize = 15, Padding = new Thickness(16), Margin = new Thickness(0, 0, 0, 17) }; panel.Children.Add(keybox);
        var save = new Button { Content = "Save recovery key…", HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 0, 0, 15) };
        save.Click += (_, _) =>
        {
            var dialog = new SaveFileDialog { Title = "Save recovery key outside a protected folder", FileName = "FileLock-recovery.txt", Filter = "Text file (*.txt)|*.txt", OverwritePrompt = true };
            if (dialog.ShowDialog(this) != true) return;
            try { File.WriteAllText(dialog.FileName, "FileLock recovery key\r\n\r\n" + key + "\r\n\r\nKeep private. This key can reset your FileLock passcode on this Windows installation.\r\n"); save.Content = "Recovery key saved"; }
            catch (Exception ex) { Ui.ShowError(this, ex); }
        };
        panel.Children.Add(save);
        panel.Children.Add(Ui.Text("This key is private. Keep it away from the files you protect.", 12, "#637083"));
        var acknowledgment = new CheckBox { Content = "I have saved my recovery key safely", Margin = new Thickness(0, 22, 0, 20) }; panel.Children.Add(acknowledgment);
        var done = new Button { Content = "Done", IsEnabled = false, HorizontalAlignment = HorizontalAlignment.Right, Style = (Style)Application.Current.FindResource("PrimaryButton") };
        acknowledgment.Checked += (_, _) => done.IsEnabled = true; acknowledgment.Unchecked += (_, _) => done.IsEnabled = false;
        done.Click += (_, _) => DialogResult = true; panel.Children.Add(done); Content = panel;
        Closing += (_, e) => { if (acknowledgment.IsChecked != true) e.Cancel = true; };
    }
}

internal sealed class RecoverDialog : Window
{
    private bool _working;
    private readonly TextBox _key = new() { TextWrapping = TextWrapping.Wrap, FontFamily = new FontFamily("Consolas") };
    private readonly PasswordBox _pin = new();
    private readonly PasswordBox _confirm = new();
    private readonly TextBlock _error = Ui.Text("", 12, "#B42318");
    internal RecoverDialog(Window? owner, Func<string, string, Task<string>> recover)
    {
        if (owner is { IsVisible: true }) Owner = owner;
        Title = "Recover your passcode"; Width = 490; SizeToContent = SizeToContent.Height; ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = Owner is null ? WindowStartupLocation.CenterScreen : WindowStartupLocation.CenterOwner; ShowInTaskbar = Owner is null;
        var panel = new StackPanel { Margin = new Thickness(30) };
        panel.Children.Add(Ui.Text("Let's get you back in", 24, weight: FontWeights.SemiBold));
        var detail = Ui.Text("Enter your saved recovery key and choose a new 6-digit master passcode.", 13, "#637083"); detail.Margin = new Thickness(0, 12, 0, 20); panel.Children.Add(detail);
        panel.Children.Add(Ui.Text("Recovery key", 12, weight: FontWeights.SemiBold)); _key.Margin = new Thickness(0, 8, 0, 16); _key.MinHeight = 70; panel.Children.Add(_key);
        panel.Children.Add(Ui.Text("New 6-digit passcode", 12, weight: FontWeights.SemiBold)); Ui.Numeric(_pin); _pin.Margin = new Thickness(0, 8, 0, 16); panel.Children.Add(_pin);
        panel.Children.Add(Ui.Text("Confirm passcode", 12, weight: FontWeights.SemiBold)); Ui.Numeric(_confirm); _confirm.Margin = new Thickness(0, 8, 0, 16); panel.Children.Add(_confirm);
        panel.Children.Add(_error);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 16, 0, 0) };
        var cancel = new Button { Content = "Cancel", IsCancel = true, Margin = new Thickness(0, 0, 8, 0) }; cancel.Click += (_, _) => DialogResult = false;
        var reset = new Button { Content = "Reset passcode", IsDefault = true, Style = (Style)Application.Current.FindResource("PrimaryButton") };
        reset.Click += async (_, _) =>
        {
            if (!Ui.IsPin(_pin.Password)) { _error.Text = "Enter exactly six digits."; return; }
            if (_pin.Password != _confirm.Password) { _error.Text = "The two passcodes do not match."; return; }
            _working = true; reset.IsEnabled = false; cancel.IsEnabled = false;
            try { var newKey = await recover(_key.Text, _pin.Password); _key.Clear(); _pin.Clear(); _confirm.Clear(); new RecoveryKeyDialog(this, newKey).ShowDialog(); _working = false; DialogResult = true; }
            catch (Exception ex) { _error.Text = ex.Message; }
            finally { _working = false; reset.IsEnabled = true; cancel.IsEnabled = true; }
        };
        buttons.Children.Add(cancel); buttons.Children.Add(reset); panel.Children.Add(buttons); Content = panel;
        Closing += (_, e) => { if (_working) e.Cancel = true; };
    }
}

using FileLock.Shared;

namespace FileLock;

public partial class MainWindow
{
    internal async Task PollAuditNotificationsAsync(Func<Task<List<PendingChallenge>>>? poll = null)
    {
        // Drain legacy brokers too. A failed filesystem read may come from a
        // thumbnail, indexer, antivirus or an Explorer background scan. Its
        // process and timestamp cannot prove that the user opened this item.
        // Only a shell activation or an explicit UI action starts a PIN prompt.
        var read = poll ?? _client.PollAsync;
        _ = await read();
    }
}

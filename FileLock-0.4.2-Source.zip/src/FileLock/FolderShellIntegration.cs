using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace FileLock;

// Windows invokes this verb on the real directory; no placeholder folder or
// shortcut is created. Unprotected folders are forwarded straight to Explorer.
internal static class FolderShellIntegration
{
    internal const string Verb = "FileLock.Open";
    internal const string ShellKey = @"Software\Classes\Directory\shell";
    internal const string BackupKey = @"Software\FileLock\FolderShellIntegration";
    internal static bool IsEnabled
    {
        get
        {
            using var shell = Registry.CurrentUser.OpenSubKey(ShellKey);
            using var command = Registry.CurrentUser.OpenSubKey(ShellKey + @"\" + Verb + @"\command");
            return shell?.GetValue("") is string value && value == Verb && command?.GetValue("") is string configured
                && configured.Contains(" --open ", StringComparison.Ordinal);
        }
    }
    internal static string InstalledExecutable
    {
        get
        {
            var executable = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "FileLock", "App", "FileLock.exe");
            if (!File.Exists(executable)) throw new IOException("Install FileLock before enabling Explorer passcode prompts.");
            return executable;
        }
    }
    internal static void Enable()
    {
        var executable = InstalledExecutable;
        using var backup = Registry.CurrentUser.CreateSubKey(BackupKey);
        using var shell = Registry.CurrentUser.CreateSubKey(ShellKey);
        if (shell.GetValue("") is not string active || active != Verb
            || backup.GetValue("Saved") is not int saved || saved != 1)
        {
            var exists = shell.GetValueNames().Contains("")
                && !string.Equals(shell.GetValue("") as string, Verb, StringComparison.Ordinal);
            backup.SetValue("HadDefault", exists ? 1 : 0, RegistryValueKind.DWord);
            if (exists)
            {
                backup.SetValue("PreviousDefault", shell.GetValue("", "", RegistryValueOptions.DoNotExpandEnvironmentNames)! , shell.GetValueKind(""));
                backup.SetValue("PreviousKind", (int)shell.GetValueKind(""), RegistryValueKind.DWord);
            }
            backup.SetValue("Saved", 1, RegistryValueKind.DWord);
            backup.Flush();
        }
        using (var verb = shell.CreateSubKey(Verb))
        {
            verb.SetValue("", "Open", RegistryValueKind.String);
            verb.SetValue("Icon", executable, RegistryValueKind.String);
            verb.SetValue("MultiSelectModel", "Single", RegistryValueKind.String);
            using var command = verb.CreateSubKey("command");
            command.SetValue("", "\"" + executable + "\" --open \"%1\"", RegistryValueKind.String);
        }
        shell.SetValue("", Verb, RegistryValueKind.String);
        using var run = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run");
        run.SetValue("FileLock", "\"" + executable + "\" --background", RegistryValueKind.String);
        NotifyChanged();
    }
    internal static void Disable()
    {
        using var shell = Registry.CurrentUser.OpenSubKey(ShellKey, writable: true);
        using var backup = Registry.CurrentUser.OpenSubKey(BackupKey);
        if (shell?.GetValue("") is string value && value == Verb)
        {
            if (backup?.GetValue("HadDefault") is int had && had == 1)
            {
                var kind = backup.GetValue("PreviousKind") is int number ? (RegistryValueKind)number : RegistryValueKind.String;
                shell.SetValue("", backup.GetValue("PreviousDefault", "", RegistryValueOptions.DoNotExpandEnvironmentNames)!, kind);
            }
            else shell.DeleteValue("", throwOnMissingValue: false);
        }
        shell?.DeleteSubKeyTree(Verb, throwOnMissingSubKey: false);
        // Keep the backup while disabled. A later Enable saves a newly chosen
        // external default, while upgrades of an active verb preserve its backup.
        NotifyChanged();
    }
    private static void NotifyChanged() => SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero);
    [DllImport("shell32.dll")] private static extern void SHChangeNotify(uint eventId, uint flags, IntPtr first, IntPtr second);
}

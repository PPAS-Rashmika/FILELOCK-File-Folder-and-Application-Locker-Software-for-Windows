using System.IO;
using System.IO.Pipes;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace FileLock;

public partial class App : Application
{
    private Mutex? _instance;
    private CancellationTokenSource? _stop;
    private string _pipeName = "";

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        if (e.Args.Length == 2 && e.Args[0] is "--preview" or "--preview-pin")
        {
            try
            {
                var preview = new MainWindow(preview: true);
                FrameworkElement content;
                Size size;
                if (e.Args[0] == "--preview-pin")
                {
                    new System.Windows.Interop.WindowInteropHelper(preview).EnsureHandle();
                    var dialog = new PinDialog(preview, "Unlock this location", "Personal documents\nEnter its 6-digit passcode to access the original folder.", "Unlock & open");
                    var inner = (FrameworkElement)dialog.Content; dialog.Content = null;
                    content = new Border { Background = new SolidColorBrush(Color.FromRgb(250, 251, 253)), Child = inner }; size = new Size(440, 480);
                    System.Windows.Documents.TextElement.SetFontFamily(content, new FontFamily("Segoe UI"));
                    System.Windows.Documents.TextElement.SetFontSize(content, 13);
                }
                else { content = (FrameworkElement)preview.Content; size = new Size(1160, 750); }
                content.Measure(size); content.Arrange(new Rect(size)); content.UpdateLayout();
                var bitmap = new RenderTargetBitmap((int)size.Width, (int)size.Height, 96, 96, PixelFormats.Pbgra32);
                bitmap.Render(content);
                var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap));
                Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(e.Args[1]))!);
                using var output = File.Create(e.Args[1]); encoder.Save(output);
                Shutdown(0);
            }
            catch (Exception error)
            {
                File.WriteAllText(e.Args[1] + ".error.txt", error.ToString()); Shutdown(1);
            }
            return;
        }

        if (e.Args.Length == 1 && e.Args[0] is "--enable-folder-prompts" or "--disable-folder-prompts" or "--enable-file-commands" or "--disable-file-commands")
        {
            try
            {
                if (e.Args[0] == "--enable-folder-prompts") FolderShellIntegration.Enable();
                else if (e.Args[0] == "--disable-folder-prompts") FolderShellIntegration.Disable();
                else if (e.Args[0] == "--enable-file-commands") FileShellIntegration.Enable();
                else FileShellIntegration.Disable();
                Shutdown(0);
            }
            catch (Exception error) { Ui.ShowError(null, error); Shutdown(1); }
            return;
        }
        var activation = new DesktopActivation();
        var background = e.Args.Length == 1 && e.Args[0] == "--background";
        try
        {
            if (e.Args.Length == 2 && e.Args[0] == "--open")
            {
                activation.Operation = "open"; activation.Path = DesktopActivation.NormalizeOpenPath(e.Args[1]);
                background = true;
            }
            else if (e.Args.Length != 0 && !background) throw new ArgumentException("Open FileLock normally, or use --open followed by an absolute file or folder path.");
        }
        catch (Exception error) { Ui.ShowError(null, error); Shutdown(1); return; }
        var sid = WindowsIdentity.GetCurrent().User?.Value ?? Environment.UserName;
        var session = System.Diagnostics.Process.GetCurrentProcess().SessionId;
        var id = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(sid + ":" + session)))[..24];
        _pipeName = "FileLock.Desktop.v5." + id;
        _instance = new Mutex(true, "Local\\FileLock.Desktop.v5." + id, out var first);
        if (!first)
        {
            if (background && activation.Operation != "open") { Shutdown(); return; }
            try
            {
                using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
                using var pipe = new NamedPipeClientStream(".", _pipeName, PipeDirection.InOut, PipeOptions.Asynchronous);
                await pipe.ConnectAsync(timeout.Token);
                await DesktopActivation.WriteAsync(pipe, activation, timeout.Token);
                var acknowledgement = new byte[1];
                if (await pipe.ReadAsync(acknowledgement, timeout.Token) != 1 || acknowledgement[0] != 1)
                    throw new IOException("FileLock could not accept the folder request. Open FileLock and try again.");
            }
            catch (Exception error) { if (activation.Operation == "open") Ui.ShowError(null, error); }
            Shutdown(); return;
        }
        _stop = new CancellationTokenSource();
        var window = new MainWindow(); MainWindow = window;
        _ = ListenForActivationAsync(_stop.Token);
        await window.StartPromptAgentAsync();
        if (activation.Operation == "open") window.QueueOpenPath(activation.Path!);
        else if (!background) await window.RequestManagerOpenAsync();
    }

    private async Task ListenForActivationAsync(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                using var pipe = new NamedPipeServerStream(_pipeName, PipeDirection.InOut, 1, PipeTransmissionMode.Byte,
                    PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
                await pipe.WaitForConnectionAsync(token);
                using var requestTimeout = CancellationTokenSource.CreateLinkedTokenSource(token);
                requestTimeout.CancelAfter(TimeSpan.FromSeconds(2));
                var activation = await DesktopActivation.ReadAsync(pipe, requestTimeout.Token);
                await Dispatcher.InvokeAsync(() =>
                {
                    if (MainWindow is not MainWindow window) return;
                    if (activation.Operation == "open") window.QueueOpenPath(activation.Path!);
                    else
                    {
                        // Accept activation before an ownerless modal PIN prompt.
                        // A second launcher must not time out waiting for typing.
                        Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,
                            new Action(() => _ = window.RequestManagerOpenAsync()));
                    }
                });
                await pipe.WriteAsync(new byte[] { 1 }, requestTimeout.Token);
                await pipe.FlushAsync(requestTimeout.Token);
            }
            catch (OperationCanceledException) when (token.IsCancellationRequested) { return; }
            catch { if (!token.IsCancellationRequested) await Task.Delay(500, token); }
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _stop?.Cancel(); _stop?.Dispose(); _instance?.Dispose(); base.OnExit(e);
    }
}

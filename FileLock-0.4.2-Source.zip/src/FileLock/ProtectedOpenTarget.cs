using System.IO;
using FileLock.Shared;

namespace FileLock;

internal sealed record ProtectedOpenTarget(string Path, ProtectionKind ObserverKind, string ObserverPath)
{
    internal static ProtectedOpenTarget Select(ProtectedItem granted, string requestedPath, bool isDirectory)
    {
        var path = granted.Kind == ProtectionKind.Folder
            ? AccessPrompt.ValidateRequestedPath(granted, requestedPath) : granted.OriginalPath;
        if (isDirectory)
        {
            if (granted.Kind != ProtectionKind.Folder) throw new IOException("The protected file changed its item type.");
            return new(path, ProtectionKind.Folder, granted.OriginalPath);
        }
        var kind = granted.Kind == ProtectionKind.Application || path.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)
            ? ProtectionKind.Application : ProtectionKind.File;
        return new(path, kind, path);
    }
}

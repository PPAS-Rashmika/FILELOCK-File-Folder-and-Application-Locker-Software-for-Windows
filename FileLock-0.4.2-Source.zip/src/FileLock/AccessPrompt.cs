using System.Windows;
using System.IO;
using FileLock.Shared;

namespace FileLock;

internal static class AccessPrompt
{
    internal static bool Show(Window? owner, string name, Func<string, Task<ProtectedItem>> unlock, Action<ProtectedItem> open)
    {
        ProtectedItem? granted = null;
        var dialog = new PinDialog(owner, "Unlock this location",
            $"{name}\nEnter its 6-digit passcode. Access locks again when its window closes.",
            "Unlock & open", verify: async pin =>
            {
                var result = await unlock(pin);
                if (!result.IsOpen || result.UnlockedUntilUtc is not { } until || until <= DateTimeOffset.UtcNow)
                    throw new GateException("Windows could not unlock this location. Try again.");
                granted = result;
            });
        if (dialog.ShowDialog() != true || granted is null) return false;
        open(granted);
        return true;
    }

    internal static string ValidateRequestedPath(ProtectedItem granted, string requestedPath)
    {
        var requested = DesktopActivation.NormalizeOpenPath(requestedPath);
        var root = DesktopActivation.NormalizeOpenPath(granted.OriginalPath);
        if (!requested.Equals(root, StringComparison.OrdinalIgnoreCase)
            && !requested.StartsWith(root.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new IOException("The requested folder is outside the approved protected location.");
        return requested;
    }

    internal static string RebaseRequestedPath(ProtectedItem granted, string requestedPath, string previousRoot)
    {
        if (granted.Kind != ProtectionKind.Folder) throw new IOException("Only folder requests can be rebased.");
        // A rename can be discovered while the PIN dialog is open. Preserve a
        // requested descendant, but first prove it belonged to the cached root.
        var previous = new ProtectedItem { OriginalPath = previousRoot, Kind = ProtectionKind.Folder };
        var requested = ValidateRequestedPath(previous, requestedPath);
        var oldRoot = DesktopActivation.NormalizeOpenPath(previousRoot);
        var relative = Path.GetRelativePath(oldRoot, requested);
        if (Path.IsPathRooted(relative) || relative == ".." || relative.StartsWith(".." + Path.DirectorySeparatorChar, StringComparison.Ordinal))
            throw new IOException("The requested folder is outside the previous protected location.");
        var newRoot = DesktopActivation.NormalizeOpenPath(granted.OriginalPath);
        return ValidateRequestedPath(granted, Path.Combine(newRoot, relative));
    }
}

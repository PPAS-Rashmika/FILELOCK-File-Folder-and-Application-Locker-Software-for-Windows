using System.Windows;

namespace FileLock;

public partial class MainWindow
{
    private bool _managerOpenPending;
    private bool _managerOpening;
    private bool _settingsSigningOut;

    internal async Task RequestManagerOpenAsync()
    {
        if (_preview || _exiting) return;
        // Tray double-clicks and simultaneous launchers can describe the same
        // open gesture. Keep its existing fresh-PIN challenge in front.
        if (_managerOpening) return;
        if (_busy || _prompting || _processingOpen || _polling || _settingsSigningOut)
        {
            _managerOpenPending = true;
            return;
        }
        _managerOpenPending = false;
        Hide();
        _items = [];
        RefreshRows();
        _managerOpening = true;
        _prompting = true;
        ManagerAccessResult result;
        try
        {
            result = await ManagerAccessGate.OpenAsync(_client);
            await RefreshAsync();
            if (_exiting) return;
            if (result == ManagerAccessResult.Canceled) return;
            if (result == ManagerAccessResult.Authenticated && !CanManage)
                throw new FileLock.Shared.GateException("Your settings session has expired. Open FileLock again and enter your master passcode.", "SESSION_EXPIRED");
            if (result == ManagerAccessResult.SetupRequired) Navigate("security");
            Show();
            if (WindowState == WindowState.Minimized) WindowState = WindowState.Normal;
            Activate();
        }
        catch (Exception error) { Ui.ShowError(null, error); return; }
        finally { _prompting = false; _managerOpening = false; }
        if (result == ManagerAccessResult.SetupRequired) await SetupAsync();
    }

    internal async Task SignOutHiddenSettingsAsync(Func<Task>? signOut = null)
    {
        if (_settingsSigningOut) return;
        _settingsSigningOut = true;
        try { await (signOut ?? _client.SignOutSettingsAsync)(); }
        catch { /* A disconnected broker cannot authorize a fresh manager open. */ }
        finally { _settingsSigningOut = false; }
    }
}

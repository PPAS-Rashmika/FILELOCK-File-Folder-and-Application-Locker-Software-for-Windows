using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace FileLock;

// An explicit file context-menu action records the user's intent to open a file.
// Background reads by Explorer, search, or a preview handler must not invoke it.
internal static class FileShellIntegration
{
    internal const string Verb = "FileLock.Open";
    internal const string ShellKey = @"Software\Classes\*\shell";
    internal const string VerbKey = ShellKey + @"\" + Verb;
    internal const string OwnerValue = "FileLockOwner";
    internal const string OwnerId = "FileLock.FileShellIntegration.v1";
    internal const string Title = "Unlock & open with FileLock";
    internal const string SettingsKey = @"Software\FileLock\FileShellIntegration";

    internal static void EnsureConfigured()
    {
        using var settings = Registry.CurrentUser.OpenSubKey(SettingsKey);
        if (settings?.GetValue("Disabled") is int disabled && disabled == 1) return;
        if (!IsEnabled) Enable();
    }

    internal static bool IsEnabled
    {
        get
        {
            using var verb = Registry.CurrentUser.OpenSubKey(VerbKey);
            if (!IsOwned(verb)) return false;
            using var command = verb!.OpenSubKey("command");
            var executable = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "FileLock", "App", "FileLock.exe");
            return string.Equals(command?.GetValue("") as string, BuildCommand(executable), StringComparison.OrdinalIgnoreCase);
        }
    }

    internal static void Enable()
    {
        var executable = FolderShellIntegration.InstalledExecutable;
        using (var existing = Registry.CurrentUser.OpenSubKey(VerbKey))
        {
            if (existing is not null && !IsOwned(existing))
                throw new IOException("The FileLock file menu entry belongs to another application and could not be replaced.");
        }

        using (var verb = Registry.CurrentUser.CreateSubKey(VerbKey))
        {
            verb.SetValue(OwnerValue, OwnerId, RegistryValueKind.String);
            verb.SetValue("", Title, RegistryValueKind.String);
            verb.SetValue("Icon", "\"" + executable + "\"", RegistryValueKind.String);
            verb.SetValue("MultiSelectModel", "Single", RegistryValueKind.String);
            using var command = verb.CreateSubKey("command");
            command.SetValue("", BuildCommand(executable), RegistryValueKind.String);
        }
        using (var settings = Registry.CurrentUser.OpenSubKey(SettingsKey, writable: true))
            settings?.DeleteValue("Disabled", throwOnMissingValue: false);
        // Never set the wildcard shell's default verb or change file associations.
        NotifyChanged();
    }

    internal static void Disable()
    {
        // Remember the choice even if this installation has no owned verb yet.
        using (var settings = Registry.CurrentUser.CreateSubKey(SettingsKey))
            settings.SetValue("Disabled", 1, RegistryValueKind.DWord);
        using (var existing = Registry.CurrentUser.OpenSubKey(VerbKey))
        {
            if (!IsOwned(existing)) return;
        }
        Registry.CurrentUser.DeleteSubKeyTree(VerbKey, throwOnMissingSubKey: false);
        NotifyChanged();
    }

    internal static string BuildCommand(string executable)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(executable);
        if (executable.Contains('"')) throw new ArgumentException("An executable path cannot contain a quotation mark.", nameof(executable));
        return "\"" + executable + "\" --open \"%1\"";
    }

    private static bool IsOwned(RegistryKey? verb) =>
        string.Equals(verb?.GetValue(OwnerValue) as string, OwnerId, StringComparison.Ordinal);

    private static void NotifyChanged() => SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero);

    [DllImport("shell32.dll")]
    private static extern void SHChangeNotify(uint eventId, uint flags, IntPtr first, IntPtr second);
}

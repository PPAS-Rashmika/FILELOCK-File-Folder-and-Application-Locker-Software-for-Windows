using System.Windows;
using System.Windows.Controls;
using FileLock.Shared;

namespace FileLock;

internal enum ManagerAccessResult
{
    Canceled,
    SetupRequired,
    Authenticated
}

internal static class ManagerAccessGate
{
    internal static Task<ManagerAccessResult> OpenAsync(GateClient client) => OpenAsync(
        client.StatusAsync,
        client.SignOutSettingsAsync,
        client.LoginAsync,
        async (key, pin) => (await client.RecoverAsync(key, pin)).RecoveryKey);

    internal static async Task<ManagerAccessResult> OpenAsync(
        Func<Task<ServiceStatus>> status,
        Func<Task> signOutSettings,
        Func<string, Task> login,
        Func<string, string, Task<string>>? recover = null)
    {
        var current = await status();
        EnsureService(current);
        if (!current.Initialized) return ManagerAccessResult.SetupRequired;

        // Authentication from a previous visible manager is never enough for a
        // new explicit open. Ending its settings session must leave item access
        // sessions alone so that an already open document is not interrupted.
        await signOutSettings();
        while (true)
        {
            var recoveryRequested = false;
            Button? forgot = null;
            var dialog = new PinDialog(null, "Open FileLock", "Enter your 6-digit master passcode to open FileLock.", "Open FileLock", verify: async pin =>
            {
                if (forgot is not null) forgot.IsEnabled = false;
                try { await login(pin); }
                finally { if (forgot is not null) forgot.IsEnabled = true; }
            });
            if (recover is not null)
            {
                forgot = new Button
                {
                    Content = "Forgot your passcode?", HorizontalAlignment = HorizontalAlignment.Left,
                    Margin = new Thickness(0, 0, 0, 18)
                };
                forgot.Click += (_, _) => { recoveryRequested = true; dialog.DialogResult = false; };
                var panel = (StackPanel)dialog.Content;
                panel.Children.Insert(panel.Children.Count - 1, forgot);
            }
            if (dialog.ShowDialog() == true) break;
            if (!recoveryRequested) return ManagerAccessResult.Canceled;
            if (new RecoverDialog(null, recover!).ShowDialog() == true) break;
        }
        // Confirm the broker session itself, rather than treating a dialog
        // result or a stale desktop token as approval to expose the manager.
        current = await status();
        EnsureService(current);
        if (!current.SessionAuthenticated)
            throw new GateException("FileLock could not verify the new settings session. Open it again and enter your master passcode.", "SESSION_EXPIRED");
        return ManagerAccessResult.Authenticated;
    }

    private static void EnsureService(ServiceStatus status)
    {
        if (!status.ServiceAvailable)
            throw new GateException("The FileLock Windows service is unavailable. Run FileLock Setup to install or repair it, then open FileLock again.", "SERVICE_UNAVAILABLE");
    }
}

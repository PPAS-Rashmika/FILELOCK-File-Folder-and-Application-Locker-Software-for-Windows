using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using FileLock.Shared;
using Microsoft.Win32;

namespace FileLock;

public partial class MainWindow : Window
{
    private readonly GateClient _client = new();
    private readonly bool _preview;
    private readonly DispatcherTimer _pollTimer = new() { Interval = TimeSpan.FromSeconds(1) };
    private readonly Queue<string> _openRequests = [];
    private List<ProtectedItem> _items = [];
    private ServiceStatus _status = new();
    private ProtectionKind? _filter;
    private string _page = "vault";
    private bool _busy;
    private bool _polling;
    private bool _prompting;
    private bool _exiting;
    private bool _agentStarted;
    private bool _processingOpen;
    private string? _activeOpenPath;
    private TrayIcon? _tray;
    private DateTimeOffset _lastConnectionCheck;

    public MainWindow(bool preview = false)
    {
        _preview = preview; InitializeComponent();
        Closing += Window_Closing;
        if (preview) { LoadPreview(); return; }
    }

    internal async Task StartPromptAgentAsync()
    {
        if (_preview || _agentStarted) return;
        _agentStarted = true;
        new System.Windows.Interop.WindowInteropHelper(this).EnsureHandle();
        _tray = new TrayIcon(this); _pollTimer.Tick += Poll_Tick; _pollTimer.Start();
        StartAccessMonitoring();
        await RefreshAsync();
        if (_status.Initialized)
            try { FileShellIntegration.EnsureConfigured(); }
            catch (Exception error) { SetStatus("Explorer commands need attention: " + error.Message, warning: true); }
        if (_status.ServiceAvailable && !_status.Initialized) Navigate("security");
    }

    internal async void ShowFromTray() => await RequestManagerOpenAsync();

    internal void QueueOpenPath(string path)
    {
        try
        {
            path = DesktopActivation.NormalizeOpenPath(path);
            if (_openRequests.Count >= 64) throw new IOException("Too many locations are waiting. Finish the current passcode prompt and try again.");
            if (!path.Equals(_activeOpenPath, StringComparison.OrdinalIgnoreCase)
                && !_openRequests.Contains(path, StringComparer.OrdinalIgnoreCase)) _openRequests.Enqueue(path);
            // Accept shell activation before starting any modal PIN dialog.
            // The caller can then exit without waiting for the user to type.
            Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => _ = ProcessOpenRequestsAsync()));
        }
        catch (Exception error) { Ui.ShowError(null, error); }
    }

    private async Task ProcessOpenRequestsAsync()
    {
        if (_exiting || _processingOpen || _prompting || _busy || _polling || _settingsSigningOut || _preview) return;
        _processingOpen = true;
        try
        {
            while (!_exiting && !_prompting && !_busy && !_settingsSigningOut && _openRequests.TryDequeue(out var requestedPath))
            {
                _activeOpenPath = requestedPath;
                try
                {
                    // Only an explicit shell command enters this queue. Audit
                    // denials from previews and background readers never do.
                    ProtectedItem? item;
                    try { item = await _client.ResolveAsync(requestedPath); }
                    catch (GateException error) when (error.Code is "SERVICE_UNAVAILABLE" or "UNTRUSTED_SERVICE")
                    {
                        try
                        {
                            // No permission changes: a fresh enumeration must
                            // already be allowed by Windows before this fallback.
                            if (File.GetAttributes(requestedPath).HasFlag(FileAttributes.Directory))
                            { using var probe = Directory.EnumerateFileSystemEntries(requestedPath).GetEnumerator(); _ = probe.MoveNext(); }
                            else
                            { using var probe = File.Open(requestedPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite); }
                        }
                        catch (Exception probeError) when (probeError is IOException or UnauthorizedAccessException)
                        { throw error; }
                        OpenUnprotectedLocation(requestedPath); continue;
                    }
                    if (_exiting) return;
                    if (item is null)
                    {
                        OpenUnprotectedLocation(requestedPath);
                    }
                    else await UnlockAndOpenAsync(item.Id, item.Name, requestedPath, automatic: true, previousRoot: item.OriginalPath);
                }
                catch (Exception error) { Ui.ShowError(null, error); }
                finally { _activeOpenPath = null; }
            }
        }
        finally { _processingOpen = false; }
    }

    private static Process? OpenFolder(string path)
    {
        // Use the built-in Explore verb. Passing a directory to explorer.exe
        // can re-enter its default verb and invoke our gate again on Windows.
        var start = new ProcessStartInfo(path) { UseShellExecute = true, Verb = "explore" };
        return Process.Start(start);
    }

    private static void OpenUnprotectedLocation(string path)
    {
        if (File.GetAttributes(path).HasFlag(FileAttributes.Directory)) _ = OpenFolder(path);
        else _ = Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
    }

    internal async void ExitFromTray()
    {
        const string question = "FileLock will close its active access sessions and stop showing passcode prompts until you open it again.\n\nExit FileLock?";
        var answer = IsVisible ? MessageBox.Show(this, question, "Exit FileLock", MessageBoxButton.YesNo, MessageBoxImage.Question)
            : MessageBox.Show(question, "Exit FileLock", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (answer != MessageBoxResult.Yes) return;
        _exiting = true;
        _pollTimer.Stop(); _useTimer.Stop();
        await EndAllAccessAsync();
        try { await _client.SignOutSettingsAsync(); } catch { }
        _tray?.Dispose(); Application.Current.Shutdown();
    }

    private async void Window_Closing(object? sender, CancelEventArgs e)
    {
        if (_exiting || _preview) return;
        e.Cancel = true; Hide();
        _items = []; RefreshRows();
        // This can overlap an independent item PIN dialog. Keep its prompt
        // state untouched and delay a fresh manager login until signout ends.
        await SignOutHiddenSettingsAsync();
    }

    private async Task RefreshAsync()
    {
        if (_preview) return;
        _status = await _client.StatusAsync(); _lastConnectionCheck = DateTimeOffset.UtcNow;
        if (_client.IsAuthenticated && _status.SessionAuthenticated)
        {
            try { _items = await _client.ListAsync(); }
            catch (GateException e) { _items = []; SetStatus(e.Message, warning: true); }
        }
        else _items = [];
        RefreshRows(); UpdateConnection();
        if (_page is "security" or "help") BuildInfo();
    }

    private void UpdateConnection()
    {
        AddButton.IsEnabled = !_preview;
        EmptyAddButton.IsEnabled = !_preview;
        VaultState.Text = !_status.ServiceAvailable ? "Setup required" : !_status.ProtectionAvailable ? "Protection needs attention" : "Windows protection active";
        if (!_status.ServiceAvailable || !_status.ProtectionAvailable)
        {
            VaultState.Foreground = new SolidColorBrush(Color.FromRgb(145, 94, 14));
            StatusBadge.Background = new SolidColorBrush(Color.FromRgb(255, 245, 222));
            SetStatus(!_status.ServiceAvailable ? "Enable Windows protection to start protecting locations." : _status.Message, warning: true);
        }
        else
        {
            VaultState.Foreground = new SolidColorBrush(Color.FromRgb(40, 122, 83));
            StatusBadge.Background = new SolidColorBrush(Color.FromRgb(233, 244, 238));
            SetStatus("Windows permissions protect original locations. Keep FileLock running for passcode prompts.");
        }
        if (_items.Count == 0)
        {
            if (!_status.ServiceAvailable || !_status.ProtectionAvailable)
            {
                EmptyTitle.Text = "Set up direct access protection";
                EmptySubtitle.Text = "Enable the FileLock Windows service with administrator access.\nThen create your 6-digit passcode and choose locations to protect.";
                EmptyAddButton.Content = !_status.ServiceAvailable ? "Enable Windows protection" : "Check protection";
            }
            else if (!CanManage)
            {
                EmptyTitle.Text = _status.Initialized ? "Unlock your settings" : "Make room for privacy";
                EmptySubtitle.Text = _status.Initialized ? "Enter your master passcode in Security & recovery.\nPasscode prompts for protected locations still run in the background." : "Set your 6-digit master passcode in Security & recovery.\nThen add files, folders, or applications.";
                EmptyAddButton.Content = _status.Initialized ? "Unlock settings" : "Create master passcode";
            }
            else
            {
                EmptyTitle.Text = "Make room for privacy";
                EmptySubtitle.Text = "Add a file, folder, or application to protect its original location.\nYou can also drag files and folders here.";
                EmptyAddButton.Content = "Protect your first location";
            }
        }
        UpdateSelection();
    }

    private bool CanManage => _client.IsAuthenticated && _status.SessionAuthenticated;

    private void RefreshRows()
    {
        if (ItemList is null) return;
        var selected = (ItemList.SelectedItem as ItemView)?.Id;
        var search = SearchBox.Text.Trim();
        var rows = _items.Where(i => _filter is null || i.Kind == _filter)
            .Where(i => search.Length == 0 || i.Name.Contains(search, StringComparison.OrdinalIgnoreCase) || i.OriginalPath.Contains(search, StringComparison.OrdinalIgnoreCase))
            .OrderBy(i => i.Kind).ThenBy(i => i.Name, StringComparer.CurrentCultureIgnoreCase)
            .Select(i => new ItemView(i, _status.ProtectionAvailable, _preview)).ToList();
        ItemList.ItemsSource = rows;
        if (selected is not null) ItemList.SelectedItem = rows.Find(i => i.Id == selected);
        EmptyPanel.Visibility = rows.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        if (search.Length != 0 && rows.Count == 0)
        {
            EmptyTitle.Text = "No matching locations"; EmptySubtitle.Text = "Try a different name or path.";
        }
        TotalCount.Text = _items.Count.ToString();
        var now = DateTimeOffset.UtcNow;
        var open = _items.Count(i => i.IsOpen && i.UnlockedUntilUtc > now);
        TotalSize.Text = _items.Count(i => i.ProtectionState == "Locked" && i.ProtectionError is null).ToString();
        OpenCount.Text = _status.ProtectionAvailable ? open.ToString() : "—";
        SearchPlaceholder.Visibility = SearchBox.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
        UpdateSelection();
    }

    private void SetStatus(string text, bool warning = false)
    {
        StatusText.Text = text;
        StatusIcon.Text = warning ? "\uE7BA" : "\uE73E";
        StatusIcon.Foreground = new SolidColorBrush(warning ? Color.FromRgb(171, 112, 24) : Color.FromRgb(50, 138, 97));
    }

    private async Task RunAsync(string message, Func<Task> action)
    {
        if (_busy || _preview) return;
        _busy = true; BusyMessage.Text = message; BusyOverlay.Visibility = Visibility.Visible;
        try { await action(); }
        catch (Exception error) { Ui.ShowError(this, error); }
        finally
        {
            _busy = false; BusyOverlay.Visibility = Visibility.Collapsed;
            await RefreshAsync();
        }
    }

    private void Navigate(string page, ProtectionKind? filter = null)
    {
        _page = page; _filter = filter;
        VaultPanel.Visibility = page == "vault" ? Visibility.Visible : Visibility.Collapsed;
        InfoPanel.Visibility = page == "vault" ? Visibility.Collapsed : Visibility.Visible;
        foreach (var nav in new[] { VaultNav, FilesNav, FoldersNav, AppsNav, SecurityNav, HelpNav }) nav.Background = Brushes.Transparent;
        var selected = page == "security" ? SecurityNav : page == "help" ? HelpNav : filter switch
        {
            ProtectionKind.File => FilesNav, ProtectionKind.Folder => FoldersNav, ProtectionKind.Application => AppsNav, _ => VaultNav
        };
        selected.Background = new SolidColorBrush(Color.FromRgb(225, 235, 246));
        PageTitle.Text = page == "security" ? "Security & recovery" : page == "help" ? "Getting started" : filter switch
        {
            ProtectionKind.File => "Protected files", ProtectionKind.Folder => "Protected folders", ProtectionKind.Application => "Protected applications", _ => "Protected locations"
        };
        PageSubtitle.Text = page == "security" ? "Your passcodes, your way back in." : page == "help" ? "Privacy at the original file and folder location." : "A little peace of mind for the things that matter.";
        if (page == "vault") { RefreshRows(); if (!_preview) UpdateConnection(); }
        else BuildInfo();
    }

    private void Vault_Click(object sender, RoutedEventArgs e) => Navigate("vault");
    private void Files_Click(object sender, RoutedEventArgs e) => Navigate("vault", ProtectionKind.File);
    private void Folders_Click(object sender, RoutedEventArgs e) => Navigate("vault", ProtectionKind.Folder);
    private void Apps_Click(object sender, RoutedEventArgs e) => Navigate("vault", ProtectionKind.Application);
    private void Security_Click(object sender, RoutedEventArgs e) => Navigate("security");
    private void Help_Click(object sender, RoutedEventArgs e) => Navigate("help");
    private void Search_TextChanged(object sender, TextChangedEventArgs e) => RefreshRows();
    private void Item_SelectionChanged(object sender, SelectionChangedEventArgs e) => UpdateSelection();
    private void UpdateSelection()
    {
        if (ItemOpenButton is null) return;
        var row = ItemList.SelectedItem as ItemView;
        ItemOpenButton.IsEnabled = row != null && !row.NeedsAttention && _status.ProtectionAvailable && !_preview;
        ItemMoreButton.IsEnabled = row != null && CanManage && !_preview;
        ItemOpenButton.Content = "Unlock & open";
        SelectionHint.Text = row is null ? "Double-click a location to unlock it." : row.NeedsAttention ? (row.ProtectionError ?? "Protection needs attention.") + " If renamed, use Manage → Repair moved location. If deleted, use Manage → Remove protection." : "Enter the location passcode for each open. Its observed window closing locks access again.";
    }

    private async void Add_Click(object sender, RoutedEventArgs e)
    {
        if (_preview) return;
        if (!_status.ServiceAvailable) { InstallProtection(); return; }
        if (!_status.ProtectionAvailable) { Navigate("security"); return; }
        if (!CanManage && !await EnsureManagementAsync()) return;
        var menu = new ContextMenu();
        foreach (var kind in Enum.GetValues<ProtectionKind>())
        {
            var option = new MenuItem { Header = kind switch { ProtectionKind.File => "Protect a file…", ProtectionKind.Folder => "Protect a folder…", _ => "Protect an application…" } };
            option.Click += async (_, _) => await PickAndAddAsync(kind); menu.Items.Add(option);
        }
        menu.PlacementTarget = AddButton; menu.IsOpen = true;
    }

    private async Task<bool> EnsureManagementAsync()
    {
        if (CanManage) return true;
        Navigate("security");
        if (!_status.ServiceAvailable || !_status.ProtectionAvailable || _prompting) return false;
        if (!_status.Initialized) await SetupAsync();
        else await LoginAsync();
        if (!CanManage) return false;
        Navigate("vault");
        return true;
    }

    private async Task PickAndAddAsync(ProtectionKind kind)
    {
        string? path;
        if (kind == ProtectionKind.Folder)
        {
            var dialog = new OpenFolderDialog { Title = "Select the folder to protect", Multiselect = false };
            if (dialog.ShowDialog(this) != true) return; path = dialog.FolderName;
        }
        else
        {
            var dialog = new OpenFileDialog { Title = kind == ProtectionKind.Application ? "Select the application's original executable" : "Select the original file to protect", CheckFileExists = true, Multiselect = false, Filter = kind == ProtectionKind.Application ? "Windows application (*.exe)|*.exe" : "All files (*.*)|*.*" };
            if (dialog.ShowDialog(this) != true) return; path = dialog.FileName;
        }
        await AddPathAsync(path, kind);
    }

    private async Task AddPathAsync(string path, ProtectionKind kind)
    {
        var selected = Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar);
        var runningApp = AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
        if (selected.Equals(runningApp, StringComparison.OrdinalIgnoreCase)
            || selected.StartsWith(runningApp + "\\", StringComparison.OrdinalIgnoreCase)
            || runningApp.StartsWith(selected + "\\", StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show(this, "FileLock's running application folder must stay accessible so it can show passcode prompts. Choose another location.", "FileLock", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var alreadyPrompting = _prompting; _prompting = true;
        try
        {
        var name = Path.GetFileName(path.TrimEnd(Path.DirectorySeparatorChar));
        var dialog = new PinDialog(this, "Protect this location", $"{name}\nThe original stays here. Choose the shared passcode or a separate 6-digit passcode.", "Protect location", confirm: true, offerShared: true);
        if (dialog.ShowDialog() != true) return;
        await RunAsync("Adding direct access protection…", async () =>
        {
            await _client.AddAsync(path, kind, dialog.UseShared ? null : dialog.Pin);
            FileShellIntegration.EnsureConfigured();
            if (kind == ProtectionKind.Folder) FolderShellIntegration.Enable();
            SetStatus("Location locked. Windows now restricts access at its original path.");
        });
        }
        finally { _prompting = alreadyPrompting; }
    }

    private async void Window_Drop(object sender, DragEventArgs e)
    {
        if (_busy || _prompting || _preview || !e.Data.GetDataPresent(DataFormats.FileDrop)) return;
        if (e.Data.GetData(DataFormats.FileDrop) is not string[] paths) return;
        if (!await EnsureManagementAsync()) return;
        _prompting = true;
        try
        {
            foreach (var path in paths)
            {
                var kind = Directory.Exists(path) ? ProtectionKind.Folder : Path.GetExtension(path).Equals(".exe", StringComparison.OrdinalIgnoreCase) ? ProtectionKind.Application : ProtectionKind.File;
                await AddPathAsync(path, kind);
            }
        }
        finally { _prompting = false; }
    }

    private async void Item_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (ItemList.SelectedItem is ItemView row && !row.NeedsAttention && _status.ProtectionAvailable && !_preview) await OpenRowAsync(row);
    }
    private async void ItemOpen_Click(object sender, RoutedEventArgs e)
    {
        if (ItemList.SelectedItem is ItemView row) await OpenRowAsync(row);
    }

    private async Task OpenRowAsync(ItemView row)
    {
        if (_busy || _prompting || _preview || !_status.ProtectionAvailable) return;
        await UnlockAndOpenAsync(row.Id, row.Name, row.OriginalPath, previousRoot: row.OriginalPath);
    }

    private async Task UnlockAndOpenAsync(string id, string name, string path, bool automatic = false, string? previousRoot = null)
    {
        if (_prompting) return;
        _prompting = true;
        ProtectedItem? launchFailed = null;
        try
        {
            var owner = automatic ? null : this;
            bool approved;
            try
            {
                approved = AccessPrompt.Show(owner, name, pin => _client.UnlockAsync(id, pin), granted =>
                {
                    try
                    {
                        var requested = granted.Kind == ProtectionKind.Folder && previousRoot != null
                            ? AccessPrompt.RebaseRequestedPath(granted, path, previousRoot) : path;
                        StartProtectedUse(granted, requested);
                    }
                    catch { launchFailed = granted; throw; }
                });
            }
            catch (Exception error)
            {
                if (launchFailed?.AccessToken is { } token) try { await _client.CloseAccessAsync(launchFailed.Id, token); } catch { }
                Ui.ShowError(owner, error); return;
            }
            if (!approved) return;
            await RefreshAsync();
            SetStatus("Access allowed for this use. Closing its observed window locks the location again.");
        }
        finally
        {
            _prompting = false;
        }
    }

    private void ItemMore_Click(object sender, RoutedEventArgs e)
    {
        if (ItemList.SelectedItem is not ItemView row || !CanManage || _preview) return;
        var menu = new ContextMenu();
        var pin = new MenuItem { Header = "Change this passcode…" }; pin.Click += async (_, _) => await ChangeItemPinAsync(row);
        var reset = new MenuItem { Header = "Reset a forgotten passcode…" }; reset.Click += async (_, _) => await ResetItemPinAsync(row);
        var repair = new MenuItem { Header = "Repair moved location…" }; repair.Click += async (_, _) => await RepairLocationAsync(row);
        var remove = new MenuItem { Header = "Remove protection…" }; remove.Click += async (_, _) =>
        {
            var explanation = row.NeedsAttention
                ? "FileLock will restore saved permissions on any original files that remain, then remove this item from its list. If the location was deleted or moved to the Recycle Bin, this also clears its recovery record after those checks succeed. Any remaining files are kept."
                : $"The original file or folder stays at {row.OriginalPath}.";
            if (MessageBox.Show(this, $"Remove protection from {row.Name}?\n\n{explanation}", "Remove protection", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            await RunAsync("Removing protection…", () => _client.RemoveAsync(row.Id));
        };
        var lockNow = new MenuItem { Header = "Lock now" };
        lockNow.Click += async (_, _) => await RunAsync("Locking this location…", () => _client.LockAsync(row.Id));
        menu.Items.Add(lockNow); menu.Items.Add(new Separator()); menu.Items.Add(pin); menu.Items.Add(reset); menu.Items.Add(new Separator()); menu.Items.Add(repair); menu.Items.Add(remove); menu.PlacementTarget = ItemMoreButton; menu.IsOpen = true;
    }

    private async Task RepairLocationAsync(ItemView row)
    {
        if (_busy || _prompting || _preview || !CanManage) return;
        _prompting = true;
        try
        {
            await RunAsync("Finding and repairing this location…", async () =>
            {
                try { await _client.RepairLocationAsync(row.Id); }
                catch (GateException error) when (error.Code == "LOCATION_NOT_FOUND")
                {
                    MessageBox.Show(this,
                        $"FileLock could not find {row.Name} automatically. Select that same file or folder at its current location on the same drive.\n\nYour passcodes and saved original permissions will be kept. An unrelated replacement cannot be selected. If you deleted the item, cancel and choose Manage → Remove protection. If its drive is unavailable, cancel and reconnect that drive before retrying.",
                        "Find the protected location", MessageBoxButton.OK, MessageBoxImage.Information);
                    string path;
                    if (row.Kind == ProtectionKind.Folder)
                    {
                        var dialog = new OpenFolderDialog { Title = "Select the renamed or moved protected folder", Multiselect = false };
                        if (dialog.ShowDialog(this) != true) return;
                        path = dialog.FolderName;
                    }
                    else
                    {
                        var dialog = new OpenFileDialog
                        {
                            Title = row.Kind == ProtectionKind.Application ? "Select the renamed or moved protected application" : "Select the renamed or moved protected file",
                            CheckFileExists = true, Multiselect = false,
                            Filter = row.Kind == ProtectionKind.Application ? "Windows application (*.exe)|*.exe" : "All files (*.*)|*.*"
                        };
                        if (dialog.ShowDialog(this) != true) return;
                        path = dialog.FileName;
                    }
                    await _client.RepairLocationAsync(row.Id, path);
                }
                catch (GateException error) when (error.Code == "LOCATION_DELETED")
                {
                    MessageBox.Show(this,
                        "This protected location was deleted or moved to the Recycle Bin. Choose Manage → Remove protection to restore saved permissions on any original files that remain and remove the item from FileLock. Any remaining files are kept.",
                        "Remove a deleted location", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                SetStatus("Location repaired and locked. Enter its location passcode to open it.");
            });
        }
        finally { _prompting = false; }
    }

    private async Task ChangeItemPinAsync(ItemView row)
    {
        if (_prompting) return; _prompting = true;
        try
        {
        var current = new PinDialog(this, "Current location passcode", $"Enter the current passcode for {row.Name}.");
        if (current.ShowDialog() != true) return;
        var next = new PinDialog(this, "Choose a new passcode", "Use the shared master passcode or set a separate 6-digit passcode.", "Save passcode", confirm: true, offerShared: true);
        if (next.ShowDialog() != true) return;
        await RunAsync("Updating the passcode…", () => _client.ChangeItemPinAsync(row.Id, current.Pin, next.UseShared ? null : next.Pin));
        }
        finally { _prompting = false; }
    }

    private async Task ResetItemPinAsync(ItemView row)
    {
        if (_prompting || !CanManage) return; _prompting = true;
        try
        {
            var master = new PinDialog(this, "Recover this location", $"Enter your master passcode to reset the forgotten passcode for {row.Name}.");
            if (master.ShowDialog() != true) return;
            var next = new PinDialog(this, "Choose a replacement", "Use the shared master passcode or create a new 6-digit passcode for this location.", "Reset passcode", confirm: true, offerShared: true);
            if (next.ShowDialog() != true) return;
            await RunAsync("Resetting the location passcode…", () => _client.ResetItemPinAsync(row.Id, master.Pin, next.UseShared ? null : next.Pin));
        }
        finally { _prompting = false; }
    }

    private async void Lock_Click(object sender, RoutedEventArgs e)
    {
        if (!CanManage || _preview) { Navigate("security"); return; }
        await RunAsync("Locking all locations…", async () => { await _client.LockAsync(); await _client.LogoutAsync(); });
    }

    private async void Poll_Tick(object? sender, EventArgs e)
    {
        if (_exiting || _busy || _polling || _prompting || _processingOpen || _settingsSigningOut || _preview) return;
        if (_managerOpenPending) { await RequestManagerOpenAsync(); return; }
        if (_openRequests.Count > 0) { await ProcessOpenRequestsAsync(); return; }
        _polling = true;
        try
        {
            if (DateTimeOffset.UtcNow - _lastConnectionCheck > TimeSpan.FromSeconds(15)) await RefreshAsync();
            if (!_status.ServiceAvailable || !_status.ProtectionAvailable) return;
            RefreshRows();
            await PollAuditNotificationsAsync();
        }
        catch (GateException) { /* A disconnected broker is displayed on the next status refresh. */ }
        catch (Exception error) { SetStatus(error.Message, warning: true); }
        finally { _polling = false; }
    }

    private void BuildInfo()
    {
        InfoContent.Children.Clear();
        if (_page == "help")
        {
            AddInfoCard("Protect the original location", "Choose a file, folder, or a portable application's executable on an NTFS drive. Windows permissions lock its original location. Your files stay where they are.");
            AddInfoCard("A passcode for each opening", "Open a protected folder normally, choose Unlock & open in FileLock, or right-click a file and choose Unlock & open with FileLock. Windows 11 may place this command under Show more options. These actions ask for the item's 6-digit passcode. Background scans and previews do not show prompts. The management window asks for your master passcode whenever you open it.");
            AddInfoCard("Lock automatically after use", "Close the observed Explorer view, document window, or application to lock its location again. Lock now ends access immediately. FileLock must stay running to observe use; if its background agent stops, the service relocks after its short 15-second deadline. Some document viewers and Explorer tabs cannot be identified reliably and can lock sooner. Original Windows permissions allow other permitted processes to read while an item is in use.");
            AddInfoCard("One passcode or one for each item", "Choose Shared to use your master passcode everywhere, or assign an individual 6-digit passcode to any location. Changing the master passcode also updates all shared locations.");
            AddInfoCard("Repair a renamed or moved location", "FileLock can find the same protected item after a rename or move on its original drive. If it shows Needs attention, choose Manage → Repair moved location. Repair keeps your passcode and saved original permissions and locks the location again. If you deleted the item, choose Manage → Remove protection to restore permissions on any remaining original files and clear it from FileLock. If its drive is unavailable, reconnect it before retrying.");
            AddInfoCard("What the lock covers", "Locked locations require the passcode, including when Windows offers Continue. A Windows administrator can still deliberately take ownership or use recovery privileges; SYSTEM also retains access. Files remain unencrypted, and existing open files or running applications can keep access. Close them before protecting a location. Windows system folders, network drives, links and files with multiple hard links cannot be added.");
            AddInfoCard("Enable Windows protection", "Install the FileLock Windows service once with administrator access, then create your master passcode and save the recovery key. Keep the app running for prompts. Locked permissions stay in place when the app is closed.", !_status.ServiceAvailable ? "Enable Windows protection" : "Open setup guide", !_status.ServiceAvailable ? InstallProtection : OpenGuide);
            return;
        }
        var connected = _status.ServiceAvailable && _status.ProtectionAvailable;
        AddInfoCard("Windows protection", connected ? "The FileLock service is connected. NTFS permissions block access at protected locations. Passcode prompts appear when you explicitly open an item with FileLock or its Explorer commands." : !_status.ServiceAvailable ? "Enable the Windows service to protect files and folders at their original locations. Windows will ask for administrator permission during setup." : _status.Message, !_status.ServiceAvailable ? "Enable Windows protection" : "Refresh connection", !_status.ServiceAvailable ? InstallProtection : async () => await RunAsync("Checking Windows protection…", RefreshAsync));
        if (_status.ServiceAvailable && !_status.Initialized)
            AddInfoCard("Set your master passcode", "Start with a 6-digit passcode. This secures your settings and is the shared passcode for locations that use Shared.", "Create passcode", Setup);
        else if (_status.ServiceAvailable && !CanManage)
            AddInfoCard("Settings are locked", "Enter your master passcode to manage protected locations and security settings.", "Unlock settings", Login);
        else if (CanManage)
        {
            AddInfoCard("Master passcode", "Use exactly six digits. Shared locations use this same passcode; individual passcodes stay separate.", "Change master passcode", ChangeMaster);
            AddInfoCard("Lock your settings", "Close all access windows and require your master passcode again to manage locations. Existing open file handles may remain usable until closed.", "Lock all & sign out", async () => await RunAsync("Locking all locations…", async () => { await _client.LockAsync(); await _client.LogoutAsync(); }));
        }
        AddInfoCard("Password recovery", "Use your saved recovery key to choose a new master passcode. You receive a replacement recovery key after the reset. To recover an individual location, unlock settings and choose Manage → Reset a forgotten passcode. Keep your recovery key outside protected locations.", "Recover master passcode", Recover);
        if (!_preview)
        {
            var folderPrompts = new CheckBox { Content = "Ask for a passcode when opening protected folders", IsChecked = FolderShellIntegration.IsEnabled, Margin = new Thickness(0, 0, 0, 6) };
            folderPrompts.Checked += (_, _) =>
            {
                try { FolderShellIntegration.Enable(); }
                catch (Exception error) { Ui.ShowError(this, error); }
            };
            folderPrompts.Unchecked += (_, _) =>
            {
                try { FolderShellIntegration.Disable(); }
                catch (Exception error) { Ui.ShowError(this, error); }
            };
            var folderCard = new StackPanel(); folderCard.Children.Add(folderPrompts);
            folderCard.Children.Add(Ui.Text("Opening an original folder asks for its passcode before Explorer opens it. Other folders open normally.", 12, "#637083"));
            InfoContent.Children.Add(Ui.Card(folderCard));
            var fileCommands = new CheckBox { Content = "Show Unlock & open with FileLock for files", IsChecked = FileShellIntegration.IsEnabled, Margin = new Thickness(0, 0, 0, 6) };
            fileCommands.Checked += (_, _) => { try { FileShellIntegration.Enable(); } catch (Exception error) { Ui.ShowError(this, error); } };
            fileCommands.Unchecked += (_, _) => { try { FileShellIntegration.Disable(); } catch (Exception error) { Ui.ShowError(this, error); } };
            var fileCard = new StackPanel(); fileCard.Children.Add(fileCommands);
            fileCard.Children.Add(Ui.Text("Right-click a file and choose this command to enter its passcode. On Windows 11, use Show more options. Background previews and scans stay silent.", 12, "#637083"));
            InfoContent.Children.Add(Ui.Card(fileCard));
            var startup = new CheckBox { Content = "Keep FileLock ready when I sign in to Windows", Margin = new Thickness(0, 0, 0, 6) };
            const string runKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
            using (var key = Registry.CurrentUser.OpenSubKey(runKey)) startup.IsChecked = key?.GetValue("FileLock") is string;
            startup.Checked += (_, _) =>
            {
                try
                {
                    var installed = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "FileLock", "App", "FileLock.exe");
                    var executable = File.Exists(installed) ? installed : Path.Combine(AppContext.BaseDirectory, "FileLock.exe");
                    if (!File.Exists(executable)) throw new IOException("Build or install FileLock before enabling startup.");
                    using var key = Registry.CurrentUser.CreateSubKey(runKey); key.SetValue("FileLock", "\"" + executable + "\" --background");
                }
                catch (Exception error) { Ui.ShowError(this, error); }
            };
            startup.Unchecked += (_, _) =>
            {
                try { using var key = Registry.CurrentUser.OpenSubKey(runKey, writable: true); key?.DeleteValue("FileLock", throwOnMissingValue: false); }
                catch (Exception error) { Ui.ShowError(this, error); }
            };
            var card = new StackPanel(); card.Children.Add(startup); card.Children.Add(Ui.Text("Start quietly in the notification area. Access prompts show only the passcode dialog.", 12, "#637083")); InfoContent.Children.Add(Ui.Card(card));
        }
    }

    private void AddInfoCard(string title, string description, string? action = null, Action? handler = null)
    {
        var panel = new StackPanel(); panel.Children.Add(Ui.Text(title, 17, weight: FontWeights.SemiBold));
        var body = Ui.Text(description, 13, "#637083"); body.LineHeight = 22; body.Margin = new Thickness(0, 10, 0, 0); panel.Children.Add(body);
        if (action is not null)
        {
            var button = new Button { Content = action, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 17, 0, 0), IsEnabled = !_preview };
            button.Click += (_, _) => handler?.Invoke(); panel.Children.Add(button);
        }
        InfoContent.Children.Add(Ui.Card(panel));
    }

    private async void Login() => await LoginAsync();

    private async Task LoginAsync()
    {
        if (!_status.ServiceAvailable || _prompting) return;
        _prompting = true;
        try
        {
            var dialog = new PinDialog(this, "Welcome back", "Enter your 6-digit master passcode to manage protected locations.", "Unlock settings", verify: _client.LoginAsync);
            dialog.ShowDialog(); await RefreshAsync();
        }
        finally { _prompting = false; }
    }
    private async void Setup() => await SetupAsync();

    private async Task SetupAsync()
    {
        if (!_status.ServiceAvailable || _prompting) return;
        _prompting = true;
        try
        {
            SetupResult? result = null;
            var dialog = new PinDialog(this, "Your access. Your choice.", "Create a 6-digit master passcode for your settings and shared locations.", "Create passcode", confirm: true, verify: async pin => result = await _client.SetupAsync(pin));
            if (dialog.ShowDialog() == true && result is not null) new RecoveryKeyDialog(this, result.RecoveryKey).ShowDialog();
            await RefreshAsync();
        }
        finally { _prompting = false; }
    }
    private async void Recover()
    {
        if (!_status.ServiceAvailable || !_status.Initialized)
        {
            MessageBox.Show(this, "Recovery requires the initialized FileLock Windows service.", "FileLock", MessageBoxButton.OK, MessageBoxImage.Information); return;
        }
        if (_prompting) return; _prompting = true;
        try { new RecoverDialog(this, async (key, pin) => (await _client.RecoverAsync(key, pin)).RecoveryKey).ShowDialog(); await RefreshAsync(); }
        finally { _prompting = false; }
    }
    private async void ChangeMaster()
    {
        if (!CanManage || _prompting) return;
        _prompting = true;
        try
        {
            var old = new PinDialog(this, "Current master passcode", "Enter your current 6-digit master passcode."); if (old.ShowDialog() != true) return;
            var next = new PinDialog(this, "New master passcode", "Choose a new 6-digit passcode. All shared locations use the new passcode.", "Save passcode", confirm: true, verify: pin => _client.ChangePinAsync(old.Pin, pin)); next.ShowDialog(); await RefreshAsync();
        }
        finally { _prompting = false; }
    }

    private void OpenGuide()
    {
        var path = Path.Combine(AppContext.BaseDirectory, "README.md");
        if (!File.Exists(path)) path = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "README.md"));
        try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); }
        catch (Exception error) { Ui.ShowError(this, error); }
    }

    private async void InstallProtection()
    {
        if (_busy || _preview) return;
        await RunAsync("Enabling Windows protection…", async () =>
        {
            var installer = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "scripts", "install.ps1"));
            if (!File.Exists(installer))
                throw new IOException("The installer is missing. Extract the complete FileLock package, then run install.cmd.");
            // Quote literal script paths. Windows filenames cannot contain a double quote.
            using var process = Process.Start(new ProcessStartInfo("powershell.exe")
            {
                UseShellExecute = true,
                Verb = "runas",
                WindowStyle = ProcessWindowStyle.Hidden,
                Arguments = "-NoProfile -ExecutionPolicy Bypass -File \"" + installer + "\" -NoElevation"
            }) ?? throw new IOException("Windows could not start the installer.");
            await process.WaitForExitAsync();
            if (process.ExitCode != 0)
                throw new IOException("Windows protection was not installed. Run install.cmd from the package to see the installation result.");
            await RefreshAsync();
            if (!_status.ServiceAvailable || !_status.ProtectionAvailable)
                throw new IOException("The service did not become ready. " + _status.Message);
            Navigate("security");
        });
    }

    private void LoadPreview()
    {
        _status = new() { ProtectionAvailable = false, ServiceAvailable = false };
        _items = [
            new() { Id = "sample-1", Name = "Personal documents", OriginalPath = @"C:\Users\You\Documents\Personal", Kind = ProtectionKind.Folder, UsesSharedPin = true },
            new() { Id = "sample-2", Name = "Project notes.docx", OriginalPath = @"C:\Users\You\Documents\Project notes.docx", Kind = ProtectionKind.File, UsesSharedPin = false },
            new() { Id = "sample-3", Name = "Photo collection", OriginalPath = @"D:\Photos\Photo collection", Kind = ProtectionKind.Folder, UsesSharedPin = true },
            new() { Id = "sample-4", Name = "Budget 2026.xlsx", OriginalPath = @"C:\Users\You\Documents\Budget 2026.xlsx", Kind = ProtectionKind.File, UsesSharedPin = false },
            new() { Id = "sample-5", Name = "Notes.exe", OriginalPath = @"D:\Apps\Notes\Notes.exe", Kind = ProtectionKind.Application, UsesSharedPin = true }
        ];
        RefreshRows(); TotalSize.Text = "—"; OpenCount.Text = "—";
        VaultState.Text = "Design preview"; VaultState.Foreground = new SolidColorBrush(Color.FromRgb(145, 94, 14));
        StatusBadge.Background = new SolidColorBrush(Color.FromRgb(255, 245, 222));
        SetStatus("Design preview with sample locations. Windows protection is inactive.", warning: true);
        AddButton.IsEnabled = false; ItemOpenButton.IsEnabled = false;
    }
}

internal sealed class ItemView
{
    internal ItemView(ProtectedItem item, bool available, bool preview)
    {
        Id = item.Id; Name = item.Name; OriginalPath = item.OriginalPath; Kind = item.Kind;
        ProtectionError = item.ProtectionError;
        NeedsAttention = !preview && (item.ProtectionError != null || item.ProtectionState is not ("Locked" or "Open"));
        IsOpen = item.IsOpen && item.UnlockedUntilUtc > DateTimeOffset.UtcNow;
        PinLabel = item.UsesSharedPin ? "Shared passcode" : "Individual";
        Detail = item.OriginalPath; SizeLabel = item.Kind.ToString();
        Glyph = item.Kind switch { ProtectionKind.Folder => "\uE8B7", ProtectionKind.Application => "\uE71D", _ => "\uE8A5" };
        IconColor = item.Kind switch { ProtectionKind.Folder => "#BE8A22", ProtectionKind.Application => "#7959AA", _ => "#2772B3" };
        IconBackground = item.Kind switch { ProtectionKind.Folder => "#FFF6DE", ProtectionKind.Application => "#F1EBF8", _ => "#EAF3FC" };
        Status = preview ? "Sample" : NeedsAttention ? "Needs attention" : IsOpen ? "Access allowed" : "Locked";
        StatusColor = NeedsAttention || IsOpen ? "#9B6616" : preview ? "#7D899A" : "#387457";
        StatusBackground = NeedsAttention || IsOpen ? "#FFF4DE" : preview ? "#F0F3F7" : "#ECF5EF";
    }
    public string Id { get; }
    public string Name { get; }
    public string OriginalPath { get; }
    public ProtectionKind Kind { get; }
    public bool IsOpen { get; }
    public bool NeedsAttention { get; }
    public string? ProtectionError { get; }
    public string Detail { get; }
    public string PinLabel { get; }
    public string SizeLabel { get; }
    public string Glyph { get; }
    public string IconColor { get; }
    public string IconBackground { get; }
    public string Status { get; }
    public string StatusColor { get; }
    public string StatusBackground { get; }
}


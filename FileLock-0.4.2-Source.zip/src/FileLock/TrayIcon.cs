using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;

namespace FileLock;

internal sealed class TrayIcon : IDisposable
{
    private const uint Callback = 0x8000 + 141;
    private readonly MainWindow _window;
    private readonly HwndSource _source;
    private NotifyData _data;

    internal TrayIcon(MainWindow window)
    {
        _window = window;
        var handle = new WindowInteropHelper(window).Handle;
        _source = HwndSource.FromHwnd(handle); _source.AddHook(Hook);
        _data = new NotifyData
        {
            Size = (uint)Marshal.SizeOf<NotifyData>(), Window = handle, Id = 1, Flags = 1 | 2 | 4,
            CallbackMessage = Callback, Icon = ExtractIcon(IntPtr.Zero, Environment.ProcessPath!, 0),
            Tip = "FileLock · Original-location protection", Info = "", InfoTitle = ""
        };
        Shell_NotifyIcon(0, ref _data);
    }

    private IntPtr Hook(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg != Callback) return IntPtr.Zero;
        if (lParam.ToInt32() is 0x202 or 0x203) { _window.ShowFromTray(); handled = true; }
        else if (lParam.ToInt32() == 0x205)
        {
            _window.Activate();
            var menu = new ContextMenu();
            var open = new MenuItem { Header = "Open FileLock" }; open.Click += (_, _) => _window.ShowFromTray();
            var quit = new MenuItem { Header = "Exit FileLock…" }; quit.Click += (_, _) => _window.ExitFromTray();
            menu.Items.Add(open); menu.Items.Add(new Separator()); menu.Items.Add(quit); menu.IsOpen = true; handled = true;
        }
        return IntPtr.Zero;
    }

    public void Dispose()
    {
        Shell_NotifyIcon(2, ref _data); _source.RemoveHook(Hook);
        if (_data.Icon != IntPtr.Zero && _data.Icon.ToInt64() > 1) DestroyIcon(_data.Icon);
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct NotifyData
    {
        public uint Size; public IntPtr Window; public uint Id; public uint Flags; public uint CallbackMessage; public IntPtr Icon;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string Tip;
        public uint State; public uint StateMask;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string Info;
        public uint Timeout;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string InfoTitle;
        public uint InfoFlags; public Guid Guid; public IntPtr BalloonIcon;
    }
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)] private static extern bool Shell_NotifyIcon(uint operation, ref NotifyData data);
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)] private static extern IntPtr ExtractIcon(IntPtr instance, string file, uint index);
    [DllImport("user32.dll")] private static extern bool DestroyIcon(IntPtr icon);
}

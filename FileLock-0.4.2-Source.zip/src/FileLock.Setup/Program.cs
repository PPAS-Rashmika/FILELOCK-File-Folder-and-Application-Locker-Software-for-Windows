using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

[assembly: AssemblyTitle("FileLock Setup")]
[assembly: AssemblyDescription("Installs or removes FileLock for Windows")]
[assembly: AssemblyCompany("FileLock")]
[assembly: AssemblyProduct("FileLock")]
[assembly: AssemblyVersion("0.4.2.0")]
[assembly: AssemblyFileVersion("0.4.2.0")]

namespace FileLock.Setup
{
    internal static class Program
    {
        internal const string Version = "0.4.2";
        internal const string RuntimeUrl = "https://dotnet.microsoft.com/en-us/download/dotnet/10.0";
        internal const string PayloadName = "FileLock.Payload.zip";
        internal static string InstallRoot { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "FileLock"); } }

        [STAThread]
        private static int Main(string[] args)
        {
            try
            {
                bool payload = Assembly.GetExecutingAssembly().GetManifestResourceNames().Contains(PayloadName);
                if (args.Length == 2 && (args[0] == "--verify-package" || args[0] == "--verify-runtime"))
                {
                    object report = args[0] == "--verify-package" ? Payload.VerifyReport(payload) : (object)Runtime.Check();
                    File.WriteAllText(Path.GetFullPath(args[1]), new JavaScriptSerializer().Serialize(report), new UTF8Encoding(false));
                    return 0;
                }
                bool uninstall = args.Length == 1 && args[0] == "--uninstall";
                if ((!payload && !uninstall) || (payload && args.Length != 0) || (!uninstall && args.Length != 0))
                    throw new InvalidOperationException("Run FileLock Setup to install, or choose FileLock in Windows Installed apps to uninstall.");
                if (uninstall && ShadowMaintenance()) return 0;
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new SetupForm(uninstall));
                if (uninstall) ScheduleShadowCleanup();
                return 0;
            }
            catch (Exception exception)
            {
                if (args.Length == 2 && (args[0] == "--verify-package" || args[0] == "--verify-runtime"))
                {
                    try { File.WriteAllText(Path.GetFullPath(args[1]), new JavaScriptSerializer().Serialize(new { Passed = false, Error = exception.Message }), new UTF8Encoding(false)); } catch { }
                }
                else MessageBox.Show(exception.Message, "FileLock Setup", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }

        private static bool ShadowMaintenance()
        {
            string current = Path.GetFullPath(Assembly.GetExecutingAssembly().Location);
            string installed = Path.Combine(InstallRoot, "Setup", "FileLock.Maintenance.exe");
            if (!current.Equals(installed, StringComparison.OrdinalIgnoreCase)) return false;
            TemporaryDirectory shadow = TemporaryDirectory.Create();
            try
            {
                string copy = Path.Combine(shadow.Path, "FileLock.Maintenance.exe");
                File.Copy(current, copy, false);
                // Leave Program Files before uninstall removes its executable.
                // The child has no payload and no install mode.
                Process.Start(new ProcessStartInfo(copy, "--uninstall") { UseShellExecute = false, WorkingDirectory = shadow.Path });
                // The running child schedules cleanup of this unique directory
                // after its own exit; the parent must not delete the child's EXE.
                shadow.HandOffCleanup();
            }
            finally { shadow.Dispose(); }
            return true;
        }

        private static void ScheduleShadowCleanup()
        {
            string current = Path.GetFullPath(Assembly.GetExecutingAssembly().Location);
            string parent = Path.GetDirectoryName(current);
            if (!Path.GetFileName(current).Equals("FileLock.Maintenance.exe", StringComparison.OrdinalIgnoreCase)) return;
            try { TemporaryDirectory.AssertSafe(parent, true); } catch { return; }
            string expectedTemp = Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar);
            string script = "$ErrorActionPreference = 'Stop'\r\n" +
                "$target = '" + parent.Replace("'", "''") + "'\r\n" +
                "$expectedParent = '" + expectedTemp.Replace("'", "''") + "'\r\n" +
                "$resolved = [IO.Path]::GetFullPath($target).TrimEnd('\\')\r\n" +
                "if ([IO.Path]::GetDirectoryName($resolved) -ine $expectedParent -or [IO.Path]::GetFileName($resolved) -ne '" + Path.GetFileName(parent) + "') { exit 1 }\r\n" +
                "$running = Get-Process -Id " + Process.GetCurrentProcess().Id + " -ErrorAction SilentlyContinue\r\n" +
                "if ($running) { $running | Wait-Process }\r\n" +
                "if (-not (Test-Path -LiteralPath $resolved)) { exit 0 }\r\n" +
                "$cursor = $resolved\r\n" +
                "while ($cursor) {\r\n" +
                "  if (Test-Path -LiteralPath $cursor) { if (((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Cleanup does not follow links.' } }\r\n" +
                "  $parent = [IO.Path]::GetDirectoryName($cursor)\r\n" +
                "  if ($parent -eq $cursor) { break }\r\n" +
                "  $cursor = $parent\r\n" +
                "}\r\n" +
                "function Assert-CleanupTree([string]$path) {\r\n" +
                "  $entry = Get-Item -LiteralPath $path -Force\r\n" +
                "  if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Cleanup does not follow links.' }\r\n" +
                "  if ($entry.PSIsContainer) { foreach ($child in Get-ChildItem -LiteralPath $path -Force) { Assert-CleanupTree $child.FullName } }\r\n" +
                "}\r\n" +
                "Assert-CleanupTree $resolved\r\n" +
                "Remove-Item -LiteralPath $resolved -Recurse -Force\r\n";
            string powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
            string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
            try { Process.Start(new ProcessStartInfo(powershell, "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + encoded) { UseShellExecute = false, CreateNoWindow = true }); } catch { }
        }

        internal static string Quote(string value)
        {
            if (value.IndexOfAny(new[] { '"', '\r', '\n', '\0' }) >= 0) throw new InvalidOperationException("Invalid setup path.");
            int trailing = value.Length - value.TrimEnd('\\').Length;
            return "\"" + value + new string('\\', trailing) + "\"";
        }

        internal static bool IsAdministrator()
        {
            using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
                return new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator);
        }
    }

    internal sealed class RuntimeStatus
    {
        public bool Passed { get; set; }
        public bool Windows64Bit { get; set; }
        public bool DesktopRuntime10 { get; set; }
        public bool CoreRuntime10 { get; set; }
        public string DownloadUrl { get; set; }
    }

    internal static class Runtime
    {
        internal static RuntimeStatus Check()
        {
            string shared = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet", "shared");
            bool desktop = HasStable10(Path.Combine(shared, "Microsoft.WindowsDesktop.App"));
            bool core = HasStable10(Path.Combine(shared, "Microsoft.NETCore.App"));
            bool windows64 = Environment.OSVersion.Platform == PlatformID.Win32NT && Environment.Is64BitOperatingSystem;
            return new RuntimeStatus { Passed = windows64 && desktop && core, Windows64Bit = windows64, DesktopRuntime10 = desktop, CoreRuntime10 = core, DownloadUrl = Program.RuntimeUrl };
        }

        private static bool HasStable10(string directory)
        {
            if (!Directory.Exists(directory)) return false;
            return Directory.GetDirectories(directory).Any(delegate(string path)
            {
                Version parsed;
                return Version.TryParse(Path.GetFileName(path), out parsed) && parsed.Major == 10 &&
                    (File.Exists(Path.Combine(path, "System.Private.CoreLib.dll")) || File.Exists(Path.Combine(path, "PresentationFramework.dll")));
            });
        }
    }

    internal static class Payload
    {
        private static readonly string[] Required = { "FileLock/FileLock.exe", "FileLock/FileLock.dll", "FileLock/FileLock.runtimeconfig.json", "Service/FileLock.Service.exe", "Service/FileLock.Service.dll", "Service/FileLock.Service.runtimeconfig.json", "scripts/install.ps1", "scripts/uninstall.ps1", "scripts/installer-common.ps1", "Setup/FileLock.Maintenance.exe" };

        internal static object VerifyReport(bool present)
        {
            if (!present) throw new InvalidOperationException("This maintenance application has no installation package.");
            using (Stream resource = Assembly.GetExecutingAssembly().GetManifestResourceStream(Program.PayloadName))
            using (ZipArchive archive = new ZipArchive(resource, ZipArchiveMode.Read, false))
            {
                List<ZipArchiveEntry> entries = Validate(archive);
                return new { Passed = true, Version = Program.Version, Files = entries.Count, UncompressedBytes = entries.Sum(e => e.Length), RequiredFiles = Required, Prerequisites = Runtime.Check() };
            }
        }

        internal static void Extract(string root)
        {
            TemporaryDirectory.AssertSafe(root, true);
            using (Stream resource = Assembly.GetExecutingAssembly().GetManifestResourceStream(Program.PayloadName))
            using (ZipArchive archive = new ZipArchive(resource, ZipArchiveMode.Read, false))
            {
                List<ZipArchiveEntry> entries = Validate(archive);
                foreach (ZipArchiveEntry entry in entries)
                {
                    string relative = entry.FullName.Replace('/', Path.DirectorySeparatorChar).Replace('\\', Path.DirectorySeparatorChar);
                    string destination = Path.GetFullPath(Path.Combine(root, relative));
                    if (!destination.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("The package contains an unsafe path.");
                    string directory = Path.GetDirectoryName(destination);
                    Directory.CreateDirectory(directory);
                    TemporaryDirectory.AssertNoReparse(directory);
                    using (Stream input = entry.Open())
                    using (FileStream output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None)) input.CopyTo(output);
                    if (new FileInfo(destination).Length != entry.Length) throw new InvalidDataException("The package could not be extracted completely.");
                }
            }
        }

        private static List<ZipArchiveEntry> Validate(ZipArchive archive)
        {
            List<ZipArchiveEntry> files = new List<ZipArchiveEntry>();
            HashSet<string> names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            long length = 0;
            foreach (ZipArchiveEntry entry in archive.Entries)
            {
                string name = entry.FullName.Replace('\\', '/');
                bool directory = name.EndsWith("/", StringComparison.Ordinal);
                name = name.TrimEnd('/');
                if (String.IsNullOrEmpty(name) || name.StartsWith("/", StringComparison.Ordinal) || name.IndexOf(':') >= 0 || name.IndexOf('\0') >= 0 || Path.IsPathRooted(name)) throw new InvalidDataException("The package contains an unsafe path.");
                foreach (string part in name.Split('/'))
                {
                    string device = part.Split('.')[0].ToUpperInvariant();
                    if (part.Length == 0 || part == "." || part == ".." || part.EndsWith(".", StringComparison.Ordinal) || part.EndsWith(" ", StringComparison.Ordinal) || part.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || device == "CON" || device == "PRN" || device == "AUX" || device == "NUL" || (device.Length == 4 && (device.StartsWith("COM", StringComparison.Ordinal) || device.StartsWith("LPT", StringComparison.Ordinal)) && device[3] >= '1' && device[3] <= '9')) throw new InvalidDataException("The package contains an unsupported file name.");
                }
                if (!names.Add(name)) throw new InvalidDataException("The package contains duplicate paths.");
                if (((entry.ExternalAttributes >> 16) & 0xF000) == 0xA000 || (entry.ExternalAttributes & 0x400) != 0) throw new InvalidDataException("Package links are unsupported.");
                if (archive.Entries.Count > 10000 || entry.Length < 0 || entry.Length > 268435456L || (length += entry.Length) > 268435456L) throw new InvalidDataException("The package exceeds the supported size.");
                if (!directory) files.Add(entry);
            }
            foreach (string required in Required)
                if (!files.Any(e => e.FullName.Replace('\\', '/').Equals(required, StringComparison.OrdinalIgnoreCase))) throw new InvalidDataException("The package is incomplete: " + required);
            return files;
        }
    }

    internal sealed class TemporaryDirectory : IDisposable
    {
        private const string Prefix = "FileLock-Setup-";
        internal string Path { get; private set; }
        private bool handedOff;

        internal static TemporaryDirectory Create()
        {
            string path = System.IO.Path.Combine(System.IO.Path.GetTempPath(), Prefix + Guid.NewGuid().ToString("N"));
            if (Directory.Exists(path) || File.Exists(path)) throw new IOException("The temporary setup path already exists.");
            AssertNoReparse(System.IO.Path.GetTempPath());
            Directory.CreateDirectory(path);
            AssertSafe(path, true);
            return new TemporaryDirectory { Path = path };
        }

        internal static void AssertSafe(string path, bool tree)
        {
            string full = System.IO.Path.GetFullPath(path).TrimEnd(System.IO.Path.DirectorySeparatorChar);
            string parent = System.IO.Path.GetFullPath(System.IO.Path.GetTempPath()).TrimEnd(System.IO.Path.DirectorySeparatorChar);
            string name = System.IO.Path.GetFileName(full);
            Guid id;
            if (!System.IO.Path.GetDirectoryName(full).Equals(parent, StringComparison.OrdinalIgnoreCase) || !name.StartsWith(Prefix, StringComparison.Ordinal) || !Guid.TryParseExact(name.Substring(Prefix.Length), "N", out id)) throw new IOException("The temporary setup path could not be verified.");
            AssertNoReparse(full);
            if (tree && Directory.Exists(full))
                foreach (string entry in Directory.GetFileSystemEntries(full)) AssertTreeNoReparse(entry);
        }

        private static void AssertTreeNoReparse(string path)
        {
            if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0) throw new IOException("Setup does not follow symbolic links or junctions.");
            if (Directory.Exists(path)) foreach (string child in Directory.GetFileSystemEntries(path)) AssertTreeNoReparse(child);
        }

        internal static void AssertNoReparse(string path)
        {
            string cursor = System.IO.Path.GetFullPath(path);
            while (!String.IsNullOrEmpty(cursor))
            {
                if ((File.Exists(cursor) || Directory.Exists(cursor)) && (File.GetAttributes(cursor) & FileAttributes.ReparsePoint) != 0) throw new IOException("Setup does not follow symbolic links or junctions.");
                string parent = System.IO.Path.GetDirectoryName(cursor);
                if (parent == cursor) break;
                cursor = parent;
            }
        }

        internal void HandOffCleanup() { handedOff = true; }

        public void Dispose()
        {
            if (handedOff || !Directory.Exists(Path)) return;
            AssertSafe(Path, true);
            Directory.Delete(Path, true);
        }
    }

    internal sealed class SetupForm : Form
    {
        private readonly bool uninstall;
        private readonly bool verifyUninstallOnly;
        private readonly Label status;
        private readonly Label description;
        private readonly Button action;
        private readonly Button close;
        private readonly Button runtimeLink;
        private readonly Button logLink;
        private readonly ProgressBar progress;
        private readonly Timer logTimer;
        private bool busy;
        private bool completed;
        private string logPath;
        private TemporaryDirectory extracted;

        internal SetupForm(bool remove) : this(remove, false) { }

        internal SetupForm(bool remove, bool verifyOnly)
        {
            uninstall = remove;
            verifyUninstallOnly = remove && verifyOnly;
            Text = remove ? "Uninstall FileLock" : "FileLock Setup";
            Font = new Font("Segoe UI", 9F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(620, 410);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            BackColor = SystemColors.Window;
            try { Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location); } catch { }
            Label title = new Label { Text = remove ? "Remove FileLock" : "Install FileLock", Font = new Font("Segoe UI", 21F), ForeColor = Color.FromArgb(0, 80, 160), AutoSize = true, Location = new Point(28, 25) };
            Controls.Add(title);
            Controls.Add(new Label { Text = "FileLock " + Program.Version + " for Windows", AutoSize = true, ForeColor = SystemColors.GrayText, Location = new Point(30, 75) });
            description = new Label { Location = new Point(30, 115), Size = new Size(555, 78), Text = remove ? "Remove protection from every locked item before uninstalling. FileLock keeps your account and recovery information for a future reinstall." : "Protect files, folders and applications with a six-digit passcode. Setup installs FileLock and its Windows protection service. Windows will ask for administrator approval." };
            Controls.Add(description);
            Controls.Add(new Label { Location = new Point(30, 200), Size = new Size(555, 35), ForeColor = SystemColors.GrayText, Text = "Location: " + Program.InstallRoot });
            status = new Label { Location = new Point(30, 246), Size = new Size(555, 42), AutoEllipsis = true };
            Controls.Add(status);
            progress = new ProgressBar { Location = new Point(30, 295), Size = new Size(555, 8), Visible = false, Style = ProgressBarStyle.Marquee, MarqueeAnimationSpeed = 25 };
            Controls.Add(progress);
            runtimeLink = new Button { Text = "Get .NET runtime", Location = new Point(30, 319), Size = new Size(145, 29), Visible = false };
            runtimeLink.Click += delegate { Process.Start(new ProcessStartInfo(Program.RuntimeUrl) { UseShellExecute = true }); };
            Controls.Add(runtimeLink);
            logLink = new Button { Text = "View log", Location = new Point(30, 319), Size = new Size(100, 29), Visible = false };
            logLink.Click += delegate { if (!String.IsNullOrEmpty(logPath) && File.Exists(logPath)) Process.Start(new ProcessStartInfo(logPath) { UseShellExecute = true }); };
            Controls.Add(logLink);
            Panel bottom = new Panel { Dock = DockStyle.Bottom, Height = 55, BackColor = SystemColors.Control };
            action = new Button { Text = remove ? "Uninstall" : "Install", Size = new Size(122, 29), Location = new Point(345, 13) };
            close = new Button { Text = "Cancel", Size = new Size(105, 29), Location = new Point(480, 13) };
            bottom.Controls.Add(action);
            bottom.Controls.Add(close);
            Controls.Add(bottom);
            AcceptButton = action;
            CancelButton = close;
            action.Click += async delegate { await BeginOperation(); };
            close.Click += delegate { Close(); };
            FormClosing += delegate(object sender, FormClosingEventArgs e) { if (busy) e.Cancel = true; };
            logTimer = new Timer { Interval = 500 };
            logTimer.Tick += delegate { RefreshLog(); };
            CheckPrerequisites();
        }

        private void CheckPrerequisites()
        {
            if (uninstall)
            {
                bool installed = File.Exists(System.IO.Path.Combine(Program.InstallRoot, "scripts", "uninstall.ps1"));
                status.Text = installed ? "Ready to uninstall. Windows will ask for administrator approval." : "FileLock is not installed at this location.";
                action.Enabled = installed;
                return;
            }
            RuntimeStatus runtime = Runtime.Check();
            runtimeLink.Visible = !runtime.Passed && runtime.Windows64Bit;
            action.Text = runtime.Passed ? "Install" : "Check again";
            action.Enabled = runtime.Windows64Bit;
            status.Text = !runtime.Windows64Bit ? "FileLock requires 64-bit Windows." : runtime.Passed ? "Ready to install." : "Install Microsoft's .NET 10 Windows Desktop Runtime (x64), then choose Check again.";
        }

        private async Task BeginOperation()
        {
            if (completed)
            {
                try { Process.Start(new ProcessStartInfo(System.IO.Path.Combine(Program.InstallRoot, "App", "FileLock.exe")) { UseShellExecute = true }); Close(); }
                catch (Exception exception) { MessageBox.Show(this, exception.Message, "Open FileLock", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                return;
            }
            if (!uninstall && action.Text == "Check again") { CheckPrerequisites(); return; }
            if (!uninstall && !Runtime.Check().Passed) { CheckPrerequisites(); return; }
            busy = true;
            action.Enabled = false;
            close.Enabled = false;
            runtimeLink.Visible = false;
            logLink.Visible = false;
            progress.Visible = true;
            logPath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "FileLock-" + (uninstall ? "uninstall-" : "install-") + Guid.NewGuid().ToString("N") + ".log");
            status.Text = uninstall ? "Preparing to uninstall..." : "Preparing installation files...";
            logTimer.Start();
            try
            {
                int exitCode = await Task.Run(delegate
                {
                    string script;
                    string arguments;
                    if (uninstall)
                    {
                        script = System.IO.Path.Combine(Program.InstallRoot, "scripts", "uninstall.ps1");
                        TemporaryDirectory.AssertNoReparse(script);
                        arguments = "-LogPath " + Program.Quote(logPath) + (verifyUninstallOnly ? " -VerifyOnly" : "");
                    }
                    else
                    {
                        extracted = TemporaryDirectory.Create();
                        Payload.Extract(extracted.Path);
                        script = System.IO.Path.Combine(extracted.Path, "scripts", "install.ps1");
                        arguments = "-PackageRoot " + Program.Quote(extracted.Path) + " -LogPath " + Program.Quote(logPath);
                    }
                    string powershell = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
                    ProcessStartInfo start = new ProcessStartInfo(powershell, "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + Program.Quote(script) + " " + arguments) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true, WorkingDirectory = uninstall ? System.IO.Path.GetTempPath() : System.IO.Path.GetDirectoryName(script) };
                    StringBuilder diagnostic = new StringBuilder();
                    using (Process process = new Process { StartInfo = start })
                    {
                        process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (e.Data != null) lock (diagnostic) { diagnostic.AppendLine(e.Data); } };
                        process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (e.Data != null) lock (diagnostic) { diagnostic.AppendLine(e.Data); } };
                        process.Start();
                        process.BeginOutputReadLine();
                        process.BeginErrorReadLine();
                        process.WaitForExit();
                        if (process.ExitCode != 0 && !File.Exists(logPath)) File.WriteAllText(logPath, diagnostic.ToString(), new UTF8Encoding(false));
                        return process.ExitCode;
                    }
                });
                if (exitCode != 0) throw new InvalidOperationException(FailureFromLog());
                completed = !uninstall;
                description.Text = uninstall ? "FileLock has been removed. Your account and recovery information are retained for a future reinstall." : "FileLock is installed. Open the app to manage protected files and folders.";
                status.Text = uninstall ? "Uninstall complete." : "Installation complete.";
                action.Text = "Open FileLock";
                action.Visible = !uninstall;
                // The setup manifest keeps ordinary launches at the user's token.
                // A user who explicitly ran setup elevated can open the app from
                // Start instead of giving the desktop app an elevated token.
                action.Enabled = !uninstall && !Program.IsAdministrator();
                if (!uninstall && !action.Enabled) status.Text = "Installation complete. Open FileLock from the Start menu.";
            }
            catch (Exception exception)
            {
                status.Text = "Setup could not finish.";
                description.Text = exception.Message;
                action.Text = uninstall ? "Try again" : "Retry";
                action.Enabled = true;
            }
            finally
            {
                logTimer.Stop();
                progress.Visible = false;
                logLink.Visible = File.Exists(logPath);
                close.Text = "Close";
                close.Enabled = true;
                busy = false;
                if (extracted != null)
                {
                    try { extracted.Dispose(); } catch { /* A verified temp directory may remain if another process still uses it. */ }
                    extracted = null;
                }
            }
        }

        private void RefreshLog()
        {
            try
            {
                if (String.IsNullOrEmpty(logPath) || !File.Exists(logPath)) return;
                string last = File.ReadAllLines(logPath).LastOrDefault(s => !String.IsNullOrWhiteSpace(s));
                if (!String.IsNullOrEmpty(last)) status.Text = last.Length > 21 && last[4] == '-' && last[10] == ' ' ? last.Substring(21) : last;
            }
            catch (IOException) { }
        }

        private string FailureFromLog()
        {
            try
            {
                if (File.Exists(logPath))
                {
                    string line = File.ReadAllLines(logPath).LastOrDefault(s => s.IndexOf("ERROR:", StringComparison.OrdinalIgnoreCase) >= 0);
                    if (line != null) return line.Substring(line.IndexOf("ERROR:", StringComparison.OrdinalIgnoreCase) + 6).Trim();
                }
            }
            catch (IOException) { }
            return "Installation did not complete. Administrator approval may have been cancelled. View the log, then try again.";
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) logTimer.Dispose();
            base.Dispose(disposing);
        }
    }
}

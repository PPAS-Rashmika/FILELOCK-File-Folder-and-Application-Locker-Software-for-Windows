[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$SetupExe,
    [Parameter(Mandatory)][string]$MaintenanceExe,
    [Parameter(Mandatory)][string]$OutputPath
)

$ErrorActionPreference = 'Stop'
$SetupExe = [IO.Path]::GetFullPath($SetupExe)
$MaintenanceExe = [IO.Path]::GetFullPath($MaintenanceExe)
$OutputPath = [IO.Path]::GetFullPath($OutputPath)
New-Item -ItemType Directory -Path (Split-Path -Parent $OutputPath) -Force | Out-Null
Add-Type -AssemblyName System.IO.Compression
$assembly = [Reflection.Assembly]::LoadFrom($SetupExe)
$payloadType = $assembly.GetType('FileLock.Setup.Payload', $true)
$validate = $payloadType.GetMethod('Validate', [Reflection.BindingFlags]'Static,NonPublic')
$tempType = $assembly.GetType('FileLock.Setup.TemporaryDirectory', $true)
$assertSafe = $tempType.GetMethod('AssertSafe', [Reflection.BindingFlags]'Static,NonPublic')
$checks = New-Object 'Collections.Generic.List[string]'
$required = @('FileLock/FileLock.exe', 'FileLock/FileLock.dll', 'FileLock/FileLock.runtimeconfig.json', 'Service/FileLock.Service.exe', 'Service/FileLock.Service.dll', 'Service/FileLock.Service.runtimeconfig.json', 'scripts/install.ps1', 'scripts/uninstall.ps1', 'scripts/installer-common.ps1', 'Setup/FileLock.Maintenance.exe')

function Test-PayloadCase {
    param([string]$Name, [string[]]$Extras, [switch]$Symlink, [switch]$MissingRequired, [switch]$Accept)
    $memory = New-Object IO.MemoryStream
    try {
        $zip = New-Object IO.Compression.ZipArchive($memory, [IO.Compression.ZipArchiveMode]::Create, $true)
        try {
            if (-not $MissingRequired) { foreach ($path in $required) { $null = $zip.CreateEntry($path) } }
            foreach ($path in $Extras) {
                $entry = $zip.CreateEntry($path)
                if ($Symlink) { $entry.ExternalAttributes = [int](-1610612736) }
            }
        } finally { $zip.Dispose() }
        $memory.Position = 0
        $zip = New-Object IO.Compression.ZipArchive($memory, [IO.Compression.ZipArchiveMode]::Read, $true)
        try {
            $rejected = $false
            $arguments = [object[]]::new(1)
            $arguments[0] = $zip.PSObject.BaseObject
            try { $null = $validate.Invoke($null, $arguments) }
            catch {
                $cause = $_.Exception
                while ($cause.InnerException) { $cause = $cause.InnerException }
                if ($cause -isnot [IO.InvalidDataException]) { throw }
                $rejected = $true
            }
            if ($rejected -eq $Accept.IsPresent) { throw ('Unexpected package validation result: ' + $Name) }
            $checks.Add($Name)
        } finally { $zip.Dispose() }
    } finally { $memory.Dispose() }
}

Test-PayloadCase 'Complete package accepted' -Accept
Test-PayloadCase 'Traversal rejected' -Extras @('../escape.txt')
Test-PayloadCase 'Rooted path rejected' -Extras @('/escape.txt')
Test-PayloadCase 'Windows absolute path rejected' -Extras @('C:/escape.txt')
Test-PayloadCase 'Alternate data stream rejected' -Extras @('safe.txt:stream')
Test-PayloadCase 'Duplicate paths rejected' -Extras @('scripts/install.ps1')
Test-PayloadCase 'Case-insensitive duplicates rejected' -Extras @('Scripts/INSTALL.ps1')
Test-PayloadCase 'Reserved Windows name rejected' -Extras @('AUX.txt')
Test-PayloadCase 'Trailing dot rejected' -Extras @('trailing.')
Test-PayloadCase 'Symbolic link rejected' -Extras @('linked.txt') -Symlink
Test-PayloadCase 'Missing required files rejected' -MissingRequired
foreach ($badPath in @($env:TEMP, (Join-Path $env:TEMP 'FileLock-Setup-invalid'), (Split-Path -Parent $SetupExe))) {
    $rejected = $false
    $arguments = [object[]]::new(2)
    $arguments[0] = $badPath.PSObject.BaseObject
    $arguments[1] = $false
    try { $null = $assertSafe.Invoke($null, $arguments) }
    catch {
        $cause = $_.Exception
        while ($cause.InnerException) { $cause = $cause.InnerException }
        if ($cause -isnot [IO.IOException]) { throw }
        $rejected = $true
    }
    if (-not $rejected) { throw 'A cleanup target outside the unique FileLock setup directory was accepted.' }
}
$checks.Add('Cleanup restricted to unique created TEMP directory')

$payloadReport = $OutputPath + '.payload.json'
$runtimeReport = $OutputPath + '.runtime.json'
$process = Start-Process -FilePath $SetupExe -ArgumentList @('--verify-package', ('"' + $payloadReport + '"')) -Wait -PassThru
if ($process.ExitCode -ne 0) { throw 'Embedded package validation failed.' }
$package = Get-Content -LiteralPath $payloadReport -Raw | ConvertFrom-Json
if (-not $package.Passed) { throw 'Embedded package validation failed.' }
$checks.Add('Embedded installation package verified without extraction or installation')
$process = Start-Process -FilePath $MaintenanceExe -ArgumentList @('--verify-runtime', ('"' + $runtimeReport + '"')) -Wait -PassThru
if ($process.ExitCode -ne 0) { throw 'Maintenance passive runtime check failed.' }
$runtime = Get-Content -LiteralPath $runtimeReport -Raw | ConvertFrom-Json
$checks.Add('Maintenance runtime verification does not invoke uninstall')
@{ Passed = $true; Version = $package.Version; Count = $checks.Count; Checks = @($checks.ToArray()); Files = $package.Files; UncompressedBytes = $package.UncompressedBytes; Runtime = $runtime; Limitations = 'The privileged install and uninstall actions were not invoked by these passive checks.' } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
Write-Host ('{0} setup safety checks passed.' -f $checks.Count)

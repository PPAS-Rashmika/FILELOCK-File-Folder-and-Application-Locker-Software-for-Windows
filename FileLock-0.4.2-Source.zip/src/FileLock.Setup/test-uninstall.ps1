[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$MaintenancePath,
    [Parameter(Mandatory)][string]$OutputPath,
    [switch]$Worker
)

# Opt-in end-to-end removal check. Only run when uninstalling this installation
# is intended. The real uninstaller retains its atomic protected-item guard.
# This test never removes protection, changes PINs, installs, or resets state.
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..')).TrimEnd('\')
$MaintenancePath = [IO.Path]::GetFullPath($MaintenancePath)
$OutputPath = [IO.Path]::GetFullPath($OutputPath)
$windowsPowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

function Assert-UninstallTestPath([string]$Path) {
    if (-not $Path.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'The uninstall test uses only input/output files inside this workspace.' }
    $cursor = $Path
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            if (((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'The uninstall test does not follow links.' }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
}

function Quote-UninstallTestArgument([string]$Value) {
    if ($Value.IndexOfAny([char[]]@('"', "`r", "`n", [char]0)) -ge 0) { throw 'Invalid test argument.' }
    $trailing = $Value.Length - $Value.TrimEnd('\').Length
    return '"' + $Value + ('\' * $trailing) + '"'
}

Assert-UninstallTestPath $MaintenancePath
Assert-UninstallTestPath $OutputPath
if (-not (Test-Path -LiteralPath $MaintenancePath -PathType Leaf)) { throw 'Build the payload-free maintenance executable first.' }
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
try {
    if ((New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run this check with an ordinary desktop token. The graphical uninstaller requests elevation itself.'
    }
} finally { $identity.Dispose() }
New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($OutputPath)) -Force | Out-Null

if (-not $Worker) {
    $arguments = @('-NoLogo', '-NoProfile', '-NonInteractive', '-STA', '-ExecutionPolicy', 'Bypass', '-File',
        (Quote-UninstallTestArgument $PSCommandPath), '-Worker', '-MaintenancePath', (Quote-UninstallTestArgument $MaintenancePath),
        '-OutputPath', (Quote-UninstallTestArgument $OutputPath))
    $process = Start-Process -FilePath $windowsPowerShell -ArgumentList ($arguments -join ' ') -PassThru -Wait -WindowStyle Hidden -WorkingDirectory ([IO.Path]::GetTempPath())
    if ($process.ExitCode -ne 0) { throw "The graphical uninstall check failed. Read $OutputPath" }
    Get-Content -LiteralPath $OutputPath -Raw
    exit 0
}

if (-not [Environment]::Is64BitProcess -or [Threading.Thread]::CurrentThread.ApartmentState -ne 'STA' -or $PSVersionTable.PSVersion.Major -ne 5) {
    throw 'The GUI worker requires 64-bit STA Windows PowerShell 5.1.'
}
# Neither this worker nor its child may hold the installation as its current
# directory. Load the maintenance assembly from bytes to avoid an EXE handle.
Set-Location -LiteralPath ([IO.Path]::GetTempPath())
[Environment]::CurrentDirectory = [IO.Path]::GetTempPath()
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Reuse only the constant C# status probe, without executing test-install.ps1.
$tokens = $null
$parseErrors = $null
$probeAst = [Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'test-install.ps1'), [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count -ne 0) { throw 'Cannot parse the trusted status-probe source.' }
$probeDefinitions = @($probeAst.FindAll({
    param($node)
    $node -is [Management.Automation.Language.StringConstantExpressionAst] -and
        $node.StringConstantType -eq [Management.Automation.Language.StringConstantType]::SingleQuotedHereString -and
        $node.Value.Contains('public static class FileLockSetupStatusProbe')
}, $true))
if ($probeDefinitions.Count -ne 1) { throw 'Cannot uniquely identify the trusted broker status probe.' }
Add-Type -TypeDefinition $probeDefinitions[0].Value

function Get-TrustedUninstallBrokerStatus {
    $response = [FileLockSetupStatusProbe]::StatusAsync().GetAwaiter().GetResult() | ConvertFrom-Json
    if (-not $response.Ok -or -not $response.Status.ServiceAvailable -or $null -eq $response.Status.TotalProtectedItems) {
        throw 'The trusted running SYSTEM broker did not return a usable status.'
    }
    return $response.Status
}

$workRoot = [IO.Path]::GetFullPath((Join-Path $workspace ('obj\uninstall-proof-' + [Guid]::NewGuid().ToString('N'))))
Assert-UninstallTestPath $workRoot
New-Item -ItemType Directory -Path $workRoot -Force | Out-Null
$hashScript = Join-Path $workRoot 'hash-state.ps1'
@'
param([Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference = 'Stop'
try {
    $state = [IO.Path]::GetFullPath((Join-Path ([Environment]::GetFolderPath('CommonApplicationData')) 'FileLockPathGate\state.dpapi'))
    $cursor = $state
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            if (((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'The state-hash check does not follow links.' }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
    $exists = Test-Path -LiteralPath $state -PathType Leaf
    $hash = $null
    if ($exists) {
        if ((Get-Acl -LiteralPath $state).GetOwner([Security.Principal.SecurityIdentifier]).Value -ne 'S-1-5-18') { throw 'The broker state must be owned by SYSTEM.' }
        # Hash encrypted bytes only; never decrypt, deserialize, or print state.
        $hash = (Get-FileHash -LiteralPath $state -Algorithm SHA256).Hash
    }
    [pscustomobject]@{ Passed = $true; Exists = [bool]$exists; Sha256 = $hash } | ConvertTo-Json | Set-Content -LiteralPath $OutputPath -Encoding UTF8
    exit 0
} catch {
    [pscustomobject]@{ Passed = $false; Error = $_.Exception.Message } | ConvertTo-Json | Set-Content -LiteralPath $OutputPath -Encoding UTF8
    exit 1
}
'@ | Set-Content -LiteralPath $hashScript -Encoding UTF8

function Get-EncryptedStateProof([string]$Phase) {
    $path = Join-Path $workRoot ('state-' + $Phase + '.json')
    $arguments = @('-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File',
        (Quote-UninstallTestArgument $hashScript), '-OutputPath', (Quote-UninstallTestArgument $path))
    $process = Start-Process -FilePath $windowsPowerShell -ArgumentList ($arguments -join ' ') -Verb RunAs -WindowStyle Hidden -WorkingDirectory ([IO.Path]::GetTempPath()) -Wait -PassThru
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'The read-only state-hash helper produced no result.' }
    $proof = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    if ($process.ExitCode -ne 0 -or -not $proof.Passed) { throw ('The encrypted-state hash could not be verified: ' + $proof.Error) }
    return $proof
}

$flags = [Reflection.BindingFlags]'Instance,NonPublic'
function Read-UninstallFormField($Form, [string]$Name) { return $Form.GetType().GetField($Name, $flags).GetValue($Form) }
function Invoke-OwnUninstallForm($Assembly) {
    if ((Get-TrustedUninstallBrokerStatus).TotalProtectedItems -ne 0) { throw 'Protected items remain; the removal test is refused.' }
    $type = $Assembly.GetType('FileLock.Setup.SetupForm', $true)
    $form = [Activator]::CreateInstance($type, $flags, $null, [object[]]@($true, $false), $null)
    $form.ShowInTaskbar = $false
    $state = @{ Task = $null; Error = $null; Result = $null }
    $timer = New-Object Windows.Forms.Timer
    $timer.Interval = 200
    $readField = ${function:Read-UninstallFormField}.GetNewClosure()
    $readStatus = ${function:Get-TrustedUninstallBrokerStatus}.GetNewClosure()
    $shown = {
        try {
            if ((& $readStatus).TotalProtectedItems -ne 0) { throw 'Protected items changed before removal; the test is refused.' }
            $action = & $readField $form 'action'
            if (-not $action.Enabled -or $action.Text -ne 'Uninstall') { throw 'The own maintenance form is not ready to uninstall.' }
            $state.Task = $type.GetMethod('BeginOperation', $flags).Invoke($form, [object[]]@())
            $timer.Start()
        } catch { $state.Error = $_.Exception.ToString(); $form.Close() }
    }.GetNewClosure()
    $tick = {
        if ($state.Task -and $state.Task.IsCompleted) {
            $timer.Stop()
            try {
                $state.Task.GetAwaiter().GetResult()
                $path = & $readField $form 'logPath'
                $state.Result = [pscustomobject]@{
                    Status = (& $readField $form 'status').Text
                    Description = (& $readField $form 'description').Text
                    ActionVisible = (& $readField $form 'action').Visible
                    Busy = [bool](& $readField $form 'busy')
                    LogPath = $path
                    Log = if ($path -and (Test-Path -LiteralPath $path -PathType Leaf)) { Get-Content -LiteralPath $path -Raw } else { '' }
                }
            } catch { $state.Error = $_.Exception.ToString() }
            $form.Close()
        }
    }.GetNewClosure()
    try {
        $form.add_Shown($shown)
        $timer.add_Tick($tick)
        [Windows.Forms.Application]::Run($form)
        if ($state.Error) { throw $state.Error }
        if (-not $state.Result) { throw 'The own maintenance form closed before its operation completed.' }
        return $state.Result
    } finally { $timer.Stop(); $timer.Dispose(); $form.Dispose() }
}

$report = [ordered]@{
    Passed = $false; GuiUninstallComplete = $false; Checks = @(); Errors = @(); ProtectedItemsBefore = $null
    MaintenanceVersion = $null; PowerShellVersion = $PSVersionTable.PSVersion.ToString(); UninstallLog = $null
    StateBefore = $null; StateAfter = $null; WorkerDirectory = [Environment]::CurrentDirectory
}
try {
    $before = Get-TrustedUninstallBrokerStatus
    $report.ProtectedItemsBefore = [int]$before.TotalProtectedItems
    if ($before.TotalProtectedItems -ne 0) { throw 'Remove protection from every item first; this test does not bypass the uninstaller guard.' }
    $report.Checks += 'Ordinary token verifies the running SYSTEM broker and zero protected items'
    $report.StateBefore = Get-EncryptedStateProof 'before'
    if ($before.Initialized -and -not $report.StateBefore.Exists) { throw 'Initialized account state was missing before uninstall.' }
    $assembly = [Reflection.Assembly]::Load([IO.File]::ReadAllBytes($MaintenancePath))
    $report.MaintenanceVersion = $assembly.GetName().Version.ToString()
    if ($assembly.GetManifestResourceNames() -contains 'FileLock.Payload.zip' -or $assembly.Location) { throw 'Use the payload-free maintenance assembly loaded from bytes.' }
    $report.Checks += 'Payload-free maintenance loads from memory with no installed executable handle'
    [Windows.Forms.Application]::EnableVisualStyles()
    [Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)
    $removed = Invoke-OwnUninstallForm $assembly
    $report.UninstallLog = $removed.LogPath
    if ($removed.Busy -or $removed.ActionVisible -or $removed.Status -ne 'Uninstall complete.' -or
        $removed.Log -notmatch 'FileLock service and installed application removed\.') { throw ('GUI uninstall failed: ' + $removed.Description) }
    $report.GuiUninstallComplete = $true
    $report.Checks += 'Real graphical maintenance operation requests elevation and reports Uninstall complete'
    $installRoot = [IO.Path]::GetFullPath((Join-Path $env:ProgramFiles 'FileLock'))
    if (Test-Path -LiteralPath $installRoot) { throw 'The FileLock installation directory remains after uninstall.' }
    $report.Checks += 'Program Files FileLock installation directory is removed'
    $deadline = [DateTime]::UtcNow.AddSeconds(10)
    do {
        $service = Get-Service -Name FileLockPathGateBroker -ErrorAction SilentlyContinue
        if (-not $service) { break }
        Start-Sleep -Milliseconds 200
    } while ([DateTime]::UtcNow -lt $deadline)
    if ($service) { throw 'The FileLock broker remains registered after uninstall.' }
    $report.Checks += 'Windows service registration is removed'
    $registry = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, [Microsoft.Win32.RegistryView]::Registry64)
    try {
        $key = $registry.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\FileLock')
        if ($key) { $key.Dispose(); throw 'Windows Installed apps still contains FileLock.' }
    } finally { $registry.Dispose() }
    $report.Checks += 'Windows Installed apps uninstall entry is removed'
    $startMenu = Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'FileLock'
    foreach ($name in @('FileLock.lnk', 'Uninstall FileLock.lnk')) {
        if (Test-Path -LiteralPath (Join-Path $startMenu $name)) { throw 'A FileLock Start menu shortcut remains.' }
    }
    $report.Checks += 'Application and uninstall Start menu shortcuts are removed'
    $report.StateAfter = Get-EncryptedStateProof 'after'
    if ($report.StateBefore.Exists -ne $report.StateAfter.Exists -or $report.StateBefore.Sha256 -cne $report.StateAfter.Sha256) {
        throw 'The encrypted account/recovery state changed during uninstall.'
    }
    $report.Checks += 'Protected ProgramData account/recovery ciphertext is retained byte-for-byte'
    $report.Passed = $true
} catch { $report.Errors += $_.Exception.ToString() }
finally {
    $report | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
    Assert-UninstallTestPath $workRoot
    if ([IO.Path]::GetDirectoryName($workRoot) -ine (Join-Path $workspace 'obj') -or [IO.Path]::GetFileName($workRoot) -notmatch '^uninstall-proof-[a-f0-9]{32}$') { throw 'Cannot verify the test proof cleanup path.' }
    foreach ($entry in Get-ChildItem -LiteralPath $workRoot -Force -Recurse) {
        if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Refusing proof cleanup through a link.' }
    }
    Remove-Item -LiteralPath $workRoot -Recurse -Force
}
if (-not $report.Passed) { exit 1 }
exit 0

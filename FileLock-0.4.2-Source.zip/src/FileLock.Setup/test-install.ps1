[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$SetupPath,
    [Parameter(Mandatory)][string]$OutputPath,
    [switch]$Worker
)

# Opt-in integration check. Installs/upgrades FileLock with the real graphical
# setup path. A removal attempt is allowed only while protected items exist,
# and must be refused. This script never creates, unlocks or removes an item.
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..')).TrimEnd('\')
$SetupPath = [IO.Path]::GetFullPath($SetupPath)
$OutputPath = [IO.Path]::GetFullPath($OutputPath)

function Assert-TestPath([string]$Path) {
    if (-not $Path.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'The setup test uses only files inside this workspace.' }
    $cursor = $Path
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            if (((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'The setup test does not follow links.' }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
}

function Quote-TestArgument([string]$Value) {
    if ($Value.IndexOfAny([char[]]@('"', "`r", "`n", [char]0)) -ge 0) { throw 'Invalid test argument.' }
    $trailing = $Value.Length - $Value.TrimEnd('\').Length
    return '"' + $Value + ('\' * $trailing) + '"'
}

Assert-TestPath $SetupPath
Assert-TestPath $OutputPath
if (-not (Test-Path -LiteralPath $SetupPath -PathType Leaf)) { throw 'Build the graphical FileLock installer first.' }
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
try {
    if (([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run this check with an ordinary desktop token. Setup itself requests elevation.' }
} finally { $identity.Dispose() }
New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($OutputPath)) -Force | Out-Null

if (-not $Worker) {
    $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $arguments = @('-NoLogo', '-NoProfile', '-NonInteractive', '-STA', '-ExecutionPolicy', 'Bypass', '-File', (Quote-TestArgument $PSCommandPath), '-Worker', '-SetupPath', (Quote-TestArgument $SetupPath), '-OutputPath', (Quote-TestArgument $OutputPath))
    $process = Start-Process -FilePath $powershell -ArgumentList ($arguments -join ' ') -PassThru -Wait -WindowStyle Hidden
    if ($process.ExitCode -ne 0) { throw "The setup integration check failed. Read $OutputPath" }
    Get-Content -LiteralPath $OutputPath -Raw
    exit 0
}

if (-not [Environment]::Is64BitProcess -or [Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') { throw 'The GUI worker requires 64-bit STA Windows PowerShell.' }
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32.SafeHandles;
public static class FileLockSetupStatusProbe {
    [StructLayout(LayoutKind.Sequential)] private struct ServiceStatus { public uint Type, State, Controls, Win32Exit, ServiceExit, Checkpoint, WaitHint, Pid, Flags; }
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] private static extern SafePipeHandle CreateFile(string path, uint access, uint share, IntPtr security, uint creation, uint flags, IntPtr template);
    [DllImport("kernel32.dll", SetLastError=true)] private static extern bool GetNamedPipeServerProcessId(SafePipeHandle pipe, out uint pid);
    [DllImport("advapi32.dll")] private static extern uint GetSecurityInfo(SafePipeHandle handle, int type, uint information, out IntPtr owner, out IntPtr group, out IntPtr dacl, out IntPtr sacl, out IntPtr descriptor);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
    [DllImport("advapi32.dll", CharSet=CharSet.Unicode)] private static extern IntPtr OpenSCManager(string machine, string database, uint access);
    [DllImport("advapi32.dll", CharSet=CharSet.Unicode)] private static extern IntPtr OpenService(IntPtr manager, string name, uint access);
    [DllImport("advapi32.dll")] private static extern bool QueryServiceStatusEx(IntPtr service, int level, out ServiceStatus status, int size, out int needed);
    [DllImport("advapi32.dll")] private static extern bool CloseServiceHandle(IntPtr handle);
    private static NamedPipeClientStream Connect() {
        DateTime deadline = DateTime.UtcNow.AddSeconds(3);
        while (true) {
            SafePipeHandle handle = CreateFile(@"\\.\pipe\FileLock.PathGate.v1", 0x0012019B, 0, IntPtr.Zero, 3, 0x40120000, IntPtr.Zero);
            if (!handle.IsInvalid) return new NamedPipeClientStream(PipeDirection.InOut, true, true, handle);
            int error = Marshal.GetLastWin32Error(); handle.Dispose();
            if ((error != 2 && error != 231) || DateTime.UtcNow >= deadline) throw new Win32Exception(error);
            Thread.Sleep(50);
        }
    }
    private static void Verify(NamedPipeClientStream pipe) {
        IntPtr owner, group, dacl, sacl, descriptor;
        if (GetSecurityInfo(pipe.SafePipeHandle, 6, 1, out owner, out group, out dacl, out sacl, out descriptor) != 0) throw new IOException("Cannot verify the service pipe.");
        try { if (owner == IntPtr.Zero || !new SecurityIdentifier(owner).IsWellKnown(WellKnownSidType.LocalSystemSid)) throw new IOException("The service pipe must be owned by SYSTEM."); }
        finally { if (descriptor != IntPtr.Zero) LocalFree(descriptor); }
        uint pid;
        if (!GetNamedPipeServerProcessId(pipe.SafePipeHandle, out pid)) throw new IOException("Cannot verify the service process.");
        IntPtr manager = OpenSCManager(null, null, 1);
        if (manager == IntPtr.Zero) throw new IOException("Cannot query Windows services.");
        try {
            IntPtr service = OpenService(manager, "FileLockPathGateBroker", 4);
            if (service == IntPtr.Zero) throw new IOException("FileLock is not installed.");
            try {
                ServiceStatus status; int needed;
                if (!QueryServiceStatusEx(service, 0, out status, Marshal.SizeOf(typeof(ServiceStatus)), out needed) || status.State != 4 || status.Pid != pid) throw new IOException("The pipe must belong to the installed running broker.");
            } finally { CloseServiceHandle(service); }
        } finally { CloseServiceHandle(manager); }
    }
    public static async Task<string> StatusAsync() {
        using (var timeout = new CancellationTokenSource(15000))
        using (var pipe = Connect()) {
            Verify(pipe);
            byte[] request = Encoding.UTF8.GetBytes("{\"Operation\":\"Status\"}\n");
            await pipe.WriteAsync(request, 0, request.Length, timeout.Token).ConfigureAwait(false);
            await pipe.FlushAsync(timeout.Token).ConfigureAwait(false);
            using (var data = new MemoryStream()) {
                byte[] one = new byte[1];
                while (data.Length < 65536) {
                    if (await pipe.ReadAsync(one, 0, 1, timeout.Token).ConfigureAwait(false) != 1) throw new IOException("The broker returned an incomplete status.");
                    if (one[0] == 10) return Encoding.UTF8.GetString(data.ToArray());
                    data.WriteByte(one[0]);
                }
                throw new IOException("The broker status exceeded its message limit.");
            }
        }
    }
}
'@

function Get-SafeBrokerStatus {
    $response = [FileLockSetupStatusProbe]::StatusAsync().GetAwaiter().GetResult() | ConvertFrom-Json
    if (-not $response.Ok -or -not $response.Status.ServiceAvailable -or $null -eq $response.Status.TotalProtectedItems) { throw 'The broker did not return a usable status.' }
    return $response.Status
}

$flags = [Reflection.BindingFlags]'Instance,NonPublic'
function Get-SetupField($Form, [string]$Name) { return $Form.GetType().GetField($Name, $flags).GetValue($Form) }

function Invoke-OwnSetupForm($Assembly, [bool]$Uninstall) {
    if ($Uninstall -and (Get-SafeBrokerStatus).TotalProtectedItems -le 0) { return [pscustomobject]@{ Skipped = $true; Reason = 'No protected items exist; removal must never be tested.' } }
    $type = $Assembly.GetType('FileLock.Setup.SetupForm', $true)
    # The verification-only maintenance overload exits before any removal even
    # if the user concurrently removes the last protected item during this test.
    $form = [Activator]::CreateInstance($type, $flags, $null, [object[]]@($Uninstall, $Uninstall), $null)
    $form.ShowInTaskbar = $false
    $state = @{ Task = $null; Error = $null; Result = $null }
    $timer = [Windows.Forms.Timer]::new()
    $timer.Interval = 200
    # Event callbacks use independent module closures; capture their readers
    # explicitly rather than depending on script-scope function lookup.
    $readField = ${function:Get-SetupField}.GetNewClosure()
    $readStatus = ${function:Get-SafeBrokerStatus}.GetNewClosure()
    $shown = {
        try {
            if ($Uninstall -and (& $readStatus).TotalProtectedItems -le 0) {
                $state.Result = [pscustomobject]@{ Skipped = $true; Reason = 'Protected items changed to zero before the removal check.' }
                $form.Close()
                return
            }
            $action = & $readField $form 'action'
            if (-not $action.Enabled -or (!$Uninstall -and $action.Text -ne 'Install')) { throw 'The own setup form is not ready to perform its operation.' }
            $state.Task = $type.GetMethod('BeginOperation', $flags).Invoke($form, [object[]]@())
            $timer.Start()
        } catch { $state.Error = $_.Exception.ToString(); $form.Close() }
    }.GetNewClosure()
    $tick = {
        if ($state.Task -and $state.Task.IsCompleted) {
            $timer.Stop()
            try {
                $state.Task.GetAwaiter().GetResult()
                $path = & $readField $form 'logPath'
                $state.Result = [pscustomobject]@{
                    Skipped = $false
                    Completed = [bool](& $readField $form 'completed')
                    Status = (& $readField $form 'status').Text
                    Description = (& $readField $form 'description').Text
                    LogPath = $path
                    Log = if ($path -and (Test-Path -LiteralPath $path -PathType Leaf)) { Get-Content -LiteralPath $path -Raw } else { '' }
                    Busy = [bool](& $readField $form 'busy')
                }
            } catch { $state.Error = $_.Exception.ToString() }
            $form.Close()
        }
    }.GetNewClosure()
    try {
        $form.add_Shown($shown)
        $timer.add_Tick($tick)
        [Windows.Forms.Application]::Run($form)
        if ($state.Error) { throw $state.Error }
        if (-not $state.Result) { throw 'The own setup form closed before completing its operation.' }
        return $state.Result
    } finally {
        $timer.Stop()
        $timer.Dispose()
        $form.Dispose()
    }
}

$report = [ordered]@{ Passed = $false; Checks = @(); Errors = @(); ProtectedItemsBefore = $null; ProtectedItemsAfter = $null; InstallLog = $null; UninstallRefusalLog = $null; UninstallRefusalSkipped = $false }
try {
    [Windows.Forms.Application]::EnableVisualStyles()
    [Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)
    $before = Get-SafeBrokerStatus
    $report.ProtectedItemsBefore = [int]$before.TotalProtectedItems
    $report.Checks += 'Ordinary-token request verifies the running SYSTEM broker before testing'
    $assembly = [Reflection.Assembly]::LoadFrom($SetupPath)
    if ($assembly.GetManifestResourceNames() -notcontains 'FileLock.Payload.zip') { throw 'Use the embedded installer, not the maintenance application.' }
    $installed = Invoke-OwnSetupForm $assembly $false
    $report.InstallLog = $installed.LogPath
    if (-not $installed.Completed -or $installed.Busy -or $installed.Status -ne 'Installation complete.' -or $installed.Log -notmatch 'Registered FileLock in Windows Installed apps and the Start menu\.') { throw ('GUI installation failed: ' + $installed.Description) }
    $report.Checks += 'Real setup form extracts its embedded payload, requests elevation and completes installation'
    $after = Get-SafeBrokerStatus
    if (-not $after.ProtectionAvailable -or $after.TotalProtectedItems -ne $before.TotalProtectedItems -or $after.Initialized -ne $before.Initialized) { throw 'The installation changed existing account/item state or left protection unavailable.' }
    $report.Checks += 'Upgrade retains existing account initialization and protected-item count with protection available'
    $installRoot = [IO.Path]::GetFullPath((Join-Path $env:ProgramFiles 'FileLock'))
    $app = Join-Path $installRoot 'App\FileLock.exe'
    $maintenance = Join-Path $installRoot 'Setup\FileLock.Maintenance.exe'
    foreach ($path in @($app, $maintenance, (Join-Path $installRoot 'scripts\uninstall.ps1'))) { if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'The installed app or maintenance host is missing.' } }
    $maintenanceAssembly = [Reflection.Assembly]::LoadFile($maintenance)
    if ($maintenanceAssembly.GetManifestResourceNames() -contains 'FileLock.Payload.zip') { throw 'The installed maintenance host must not contain another installer payload.' }
    $report.Checks += 'Installed maintenance host is present without an embedded installation payload'
    $registry = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, [Microsoft.Win32.RegistryView]::Registry64)
    try {
        $key = $registry.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\FileLock')
        if (-not $key) { throw 'FileLock is not registered in Windows Installed apps.' }
        try {
            if ($key.GetValue('DisplayName') -ne 'FileLock' -or $key.GetValue('InstallLocation') -ine $installRoot -or $key.GetValue('UninstallString') -cne ('"' + $maintenance + '" --uninstall')) { throw 'Windows Installed apps contains an invalid application/maintenance path.' }
        } finally { $key.Dispose() }
    } finally { $registry.Dispose() }
    $report.Checks += 'Windows Installed apps registers the actual installed executable and uninstall command'
    $startMenu = Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'FileLock'
    $shell = New-Object -ComObject WScript.Shell
    try {
        foreach ($entry in @(@('FileLock.lnk', $app, ''), @('Uninstall FileLock.lnk', $maintenance, '--uninstall'))) {
            $shortcutPath = Join-Path $startMenu $entry[0]
            if (-not (Test-Path -LiteralPath $shortcutPath -PathType Leaf)) { throw 'A FileLock Start menu shortcut is missing.' }
            $shortcut = $shell.CreateShortcut($shortcutPath)
            try { if ($shortcut.TargetPath -ine $entry[1] -or $shortcut.Arguments -cne $entry[2]) { throw 'A FileLock Start menu shortcut points to an invalid target.' } }
            finally { [Runtime.InteropServices.Marshal]::FinalReleaseComObject($shortcut) | Out-Null }
        }
    } finally { [Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell) | Out-Null }
    $report.Checks += 'Start menu app and uninstall shortcuts resolve to their installed targets'
    $refusal = Invoke-OwnSetupForm $assembly $true
    if ($refusal.Skipped) {
        $report.UninstallRefusalSkipped = $true
        $report.Checks += 'Removal check safely skipped because no protected items remain'
    } else {
        $report.UninstallRefusalLog = $refusal.LogPath
        if ($refusal.Completed -or $refusal.Busy -or $refusal.Status -ne 'Setup could not finish.' -or $refusal.Description -notmatch 'Remove protection from every item' -or $refusal.Log -notmatch 'ERROR: Remove protection from every item') { throw 'The graphical maintenance operation did not clearly refuse removal while items remain protected.' }
        $report.Checks += 'Graphical maintenance refuses uninstall while protected items remain'
    }
    $final = Get-SafeBrokerStatus
    $report.ProtectedItemsAfter = [int]$final.TotalProtectedItems
    if (-not $final.ProtectionAvailable -or $final.TotalProtectedItems -ne $before.TotalProtectedItems -or $final.Initialized -ne $before.Initialized) { throw 'The service/account/item state changed after maintenance verification.' }
    $report.Checks += 'Service remains running and existing protected-item/account state remains intact'
    $report.Passed = $true
} catch { $report.Errors += $_.Exception.ToString() }
finally { $report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $OutputPath -Encoding UTF8 }
if (-not $report.Passed) { exit 1 }
exit 0

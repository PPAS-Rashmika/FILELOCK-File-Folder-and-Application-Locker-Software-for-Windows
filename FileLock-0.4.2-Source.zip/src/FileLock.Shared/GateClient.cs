using System.ComponentModel;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text.Json;
using Microsoft.Win32.SafeHandles;

namespace FileLock.Shared;

public sealed class GateClient
{
    public string? SessionToken { get; private set; }
    public bool IsAuthenticated => SessionToken != null;

    public async Task<ServiceStatus> StatusAsync()
    {
        try { return (await SendAsync(new() { Operation = "Status" })).Status!; }
        catch (GateException error) when (error.Code is "SERVICE_UNAVAILABLE" or "UNTRUSTED_SERVICE")
        {
            return new() { Message = error.Message, ServiceAvailable = false };
        }
    }

    public async Task<SetupResult> SetupAsync(string pin)
    {
        PinRules.Ensure(pin);
        var result = (await SendAsync(new() { Operation = "Setup", Pin = pin })).Setup!;
        SessionToken = result.SessionToken;
        return result;
    }

    public async Task PrepareUninstallAsync() => await SendAsync(new() { Operation = "PrepareUninstall" });

    public async Task LoginAsync(string pin)
    {
        PinRules.Ensure(pin);
        SessionToken = (await SendAsync(new() { Operation = "Login", Pin = pin })).SessionToken;
    }

    public async Task<List<ProtectedItem>> ListAsync()
    {
        var items = new List<ProtectedItem>();
        while (true)
        {
            var response = await SendAsync(new() { Operation = "List", Offset = items.Count });
            items.AddRange(response.Items ?? []);
            if (!response.HasMore) return items;
            if (response.Items is not { Count: > 0 }) throw new GateException("Invalid service page.");
        }
    }

    public async Task<ProtectedItem> AddAsync(string path, ProtectionKind kind, string? itemPin)
    {
        if (itemPin != null) PinRules.Ensure(itemPin);
        return (await SendAsync(new() { Operation = "Add", Path = path, Kind = kind, ItemPin = itemPin })).Item!;
    }

    public async Task<ProtectedItem> UnlockAsync(string itemId, string pin)
    {
        PinRules.Ensure(pin);
        if (!(await StatusAsync()).SupportsAccessSessions)
            throw new GateException("Install the new FileLock Setup before opening protected items. This version needs its matching Windows service.", "UPGRADE_REQUIRED");
        return (await SendAsync(new() { Operation = "Unlock", ItemId = itemId, Pin = pin })).Item!;
    }

    public async Task LockAsync(string? itemId = null) => await SendAsync(new() { Operation = "Lock", ItemId = itemId });
    public async Task RenewAccessAsync(string itemId, string accessToken) => await SendAsync(new() { Operation = "RenewAccess", ItemId = itemId, AccessToken = accessToken });
    public async Task CloseAccessAsync(string itemId, string accessToken) => await SendAsync(new() { Operation = "CloseAccess", ItemId = itemId, AccessToken = accessToken });
    public async Task<List<PendingChallenge>> PollAsync() => (await SendAsync(new() { Operation = "Poll" })).Challenges ?? [];
    public async Task<ProtectedItem?> ResolveAsync(string path) => (await SendAsync(new() { Operation = "Resolve", Path = path })).Item;
    public async Task RemoveAsync(string itemId) => await SendAsync(new() { Operation = "Remove", ItemId = itemId });
    public async Task<ProtectedItem> RepairLocationAsync(string itemId, string? path = null)
    {
        var status = await StatusAsync();
        if (!status.ServiceAvailable) throw new GateException(status.Message, "SERVICE_UNAVAILABLE");
        if (!status.SupportsLocationRecovery)
            throw new GateException("Install FileLock 0.4.1 or newer with its matching Windows service before repairing a moved location.", "UPGRADE_REQUIRED");
        return (await SendAsync(new() { Operation = "RepairLocation", ItemId = itemId, Path = path })).Item
            ?? throw new GateException("The service did not return the repaired location.", "INVALID_RESPONSE");
    }
    public async Task ChangePinAsync(string currentPin, string newPin)
    {
        PinRules.Ensure(currentPin); PinRules.Ensure(newPin);
        var response = await SendAsync(new() { Operation = "ChangePin", Pin = currentPin, NewPin = newPin });
        SessionToken = response.SessionToken;
    }
    public async Task ChangeItemPinAsync(string itemId, string currentPin, string? newPin)
    {
        PinRules.Ensure(currentPin);
        if (newPin != null) PinRules.Ensure(newPin);
        await SendAsync(new() { Operation = "ChangeItemPin", ItemId = itemId, Pin = currentPin, NewPin = newPin });
    }
    public async Task ResetItemPinAsync(string itemId, string masterPin, string? newPin)
    {
        PinRules.Ensure(masterPin);
        if (newPin != null) PinRules.Ensure(newPin);
        await SendAsync(new() { Operation = "ResetItemPin", ItemId = itemId, Pin = masterPin, NewPin = newPin });
    }
    public async Task<SetupResult> RecoverAsync(string recoveryKey, string newPin)
    {
        PinRules.Ensure(newPin);
        var result = (await SendAsync(new() { Operation = "Recover", RecoveryKey = recoveryKey, NewPin = newPin })).Setup!;
        SessionToken = result.SessionToken;
        return result;
    }
    public async Task LogoutAsync()
    {
        try { await SendAsync(new() { Operation = "Logout" }); }
        finally { SessionToken = null; }
    }

    public async Task SignOutSettingsAsync()
    {
        try
        {
            if (!(await StatusAsync()).SupportsAccessSessions)
                throw new GateException("Install the new FileLock Setup before opening this version. It needs its matching Windows service.", "UPGRADE_REQUIRED");
            await SendAsync(new() { Operation = "SignOutSettings" });
        }
        finally { SessionToken = null; }
    }

    private async Task<BrokerResponse> SendAsync(BrokerRequest request)
    {
        request.SessionToken = SessionToken;
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(35));
        try
        {
            using var pipe = await ConnectAsync(timeout.Token);
            VerifyServer(pipe);
            await BrokerProtocol.WriteLineAsync(pipe, request, timeout.Token);
            var bytes = await BrokerProtocol.ReadLineAsync(pipe, timeout.Token);
            var response = JsonSerializer.Deserialize<BrokerResponse>(bytes, BrokerProtocol.JsonOptions)
                ?? throw new IOException("The service returned an invalid response.");
            if (!response.Ok)
            {
                if (response.ErrorCode == "SESSION_EXPIRED") SessionToken = null;
                throw new GateException(response.Error ?? "The service rejected this action.", response.ErrorCode ?? "ERROR");
            }
            return response;
        }
        catch (GateException) { throw; }
        catch (Exception error) when (error is IOException or TimeoutException or OperationCanceledException or Win32Exception)
        {
            throw new GateException("The FileLock Windows service is unavailable. Enable Windows protection with administrator access before protecting original paths.", "SERVICE_UNAVAILABLE");
        }
    }

    private static async Task<NamedPipeClientStream> ConnectAsync(CancellationToken cancellationToken)
    {
        var until = DateTimeOffset.UtcNow.AddMilliseconds(2500);
        while (true)
        {
            // Specific rights exclude FILE_CREATE_PIPE_INSTANCE (0x4), which
            // GENERIC_WRITE would otherwise grant to every authenticated user.
            var handle = CreateFile("\\\\.\\pipe\\" + BrokerProtocol.PipeName, 0x0012019B, 0, IntPtr.Zero, 3, 0x40120000, IntPtr.Zero);
            if (!handle.IsInvalid) return new NamedPipeClientStream(PipeDirection.InOut, true, true, handle);
            var error = Marshal.GetLastWin32Error();
            handle.Dispose();
            if (error is not (2 or 231) || DateTimeOffset.UtcNow >= until) throw new Win32Exception(error);
            await Task.Delay(50, cancellationToken);
        }
    }

    private static void VerifyServer(NamedPipeClientStream pipe)
    {
        // Reading a LocalSystem process token fails for ordinary desktop users.
        // The pipe owner is readable through READ_CONTROL and cannot be assigned
        // to SYSTEM by a standard user impersonating the broker.
        if (GetSecurityInfo(pipe.SafePipeHandle, 6, 1, out var owner, out _, out _, out _, out var descriptor) != 0)
            throw new GateException("Could not verify the FileLock service pipe owner.", "UNTRUSTED_SERVICE");
        try
        {
            if (owner == IntPtr.Zero || !new SecurityIdentifier(owner).IsWellKnown(WellKnownSidType.LocalSystemSid))
                throw new GateException("The FileLock pipe is not owned by the LocalSystem Windows service.", "UNTRUSTED_SERVICE");
        }
        finally { if (descriptor != IntPtr.Zero) LocalFree(descriptor); }
        if (!GetNamedPipeServerProcessId(pipe.SafePipeHandle, out var pid)) throw new Win32Exception();
        var manager = OpenSCManager(null, null, 1);
        if (manager == IntPtr.Zero) throw new GateException("Could not verify the installed FileLock service.", "UNTRUSTED_SERVICE");
        try
        {
            var service = OpenService(manager, BrokerProtocol.ServiceName, 4);
            if (service == IntPtr.Zero) throw new GateException("The FileLock Windows service is not installed.", "UNTRUSTED_SERVICE");
            try
            {
                if (!QueryServiceStatusEx(service, 0, out var status, Marshal.SizeOf<ServiceStatusProcess>(), out _) || status.CurrentState != 4 || status.ProcessId != pid)
                    throw new GateException("The FileLock pipe does not belong to the installed running service.", "UNTRUSTED_SERVICE");
            }
            finally { CloseServiceHandle(service); }
        }
        finally { CloseServiceHandle(manager); }
    }

    [DllImport("kernel32.dll", SetLastError = true)] private static extern bool GetNamedPipeServerProcessId(SafePipeHandle pipe, out uint serverProcessId);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern SafePipeHandle CreateFile(string path, uint access, uint share, IntPtr attributes, uint creation, uint flags, IntPtr template);
    [DllImport("advapi32.dll")] private static extern uint GetSecurityInfo(SafePipeHandle handle, int objectType, uint information, out IntPtr owner, out IntPtr group, out IntPtr dacl, out IntPtr sacl, out IntPtr descriptor);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr OpenSCManager(string? machine, string? database, uint access);
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr OpenService(IntPtr manager, string name, uint access);
    [DllImport("advapi32.dll", SetLastError = true)] private static extern bool QueryServiceStatusEx(IntPtr service, int level, out ServiceStatusProcess status, int size, out int needed);
    [DllImport("advapi32.dll")] private static extern bool CloseServiceHandle(IntPtr handle);
    [StructLayout(LayoutKind.Sequential)] private struct ServiceStatusProcess
    {
        public uint Type, CurrentState, AcceptedControls, Win32ExitCode, ServiceExitCode, Checkpoint, WaitHint, ProcessId, Flags;
    }
}

using System.Text.Json;
using System.Text.Encodings.Web;

namespace FileLock.Shared;

public enum ProtectionKind { File, Folder, Application }

public sealed class ProtectedItem
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string OriginalPath { get; set; } = "";
    public ProtectionKind Kind { get; set; }
    public bool UsesSharedPin { get; set; }
    public bool IsOpen { get; set; }
    public DateTimeOffset? UnlockedUntilUtc { get; set; }
    public DateTimeOffset AddedUtc { get; set; }
    public string ProtectionState { get; set; } = "Locked";
    public string? ProtectionError { get; set; }
    // Returned only by fresh PIN approval; never persisted or exposed by List/Resolve.
    public string? AccessToken { get; set; }
}

public sealed class ServiceStatus
{
    public bool Initialized { get; set; }
    public bool ProtectionAvailable { get; set; }
    public bool SupportsAccessSessions { get; set; }
    public bool SupportsLocationRecovery { get; set; }
    public string Backend { get; set; } = "Windows NTFS permissions";
    public int AccessWindowSeconds { get; set; } = 15;
    public int TotalProtectedItems { get; set; }
    public bool ServiceAvailable { get; set; }
    public bool SessionAuthenticated { get; set; }
    public string Message { get; set; } = "";
}

public sealed class SetupResult
{
    public string RecoveryKey { get; set; } = "";
    public string SessionToken { get; set; } = "";
}

public sealed class PendingChallenge
{
    public string Id { get; set; } = "";
    public string ItemId { get; set; } = "";
    public string Name { get; set; } = "";
    public string OriginalPath { get; set; } = "";
    public ProtectionKind Kind { get; set; }
    public uint ProcessId { get; set; }
    public DateTimeOffset RequestedUtc { get; set; }
}

public static class PinRules
{
    public static bool IsValid(string? pin) => pin is { Length: 6 } && pin.All(c => c is >= '0' and <= '9');
    public static void Ensure(string? pin)
    {
        if (!IsValid(pin)) throw new ArgumentException("Enter exactly six digits (0–9).");
    }
}

public sealed class GateException : Exception
{
    public string Code { get; }
    public GateException(string message, string code = "ERROR") : base(message) => Code = code;
}

public sealed class BrokerRequest
{
    public string Operation { get; set; } = "";
    public string? SessionToken { get; set; }
    public string? Pin { get; set; }
    public string? NewPin { get; set; }
    public string? RecoveryKey { get; set; }
    public string? ItemId { get; set; }
    public string? Path { get; set; }
    public ProtectionKind Kind { get; set; }
    public string? ItemPin { get; set; }
    public int Offset { get; set; }
    public string? AccessToken { get; set; }
}

public sealed class BrokerResponse
{
    public bool Ok { get; set; }
    public string? Error { get; set; }
    public string? ErrorCode { get; set; }
    public ServiceStatus? Status { get; set; }
    public SetupResult? Setup { get; set; }
    public string? SessionToken { get; set; }
    public ProtectedItem? Item { get; set; }
    public List<ProtectedItem>? Items { get; set; }
    public List<PendingChallenge>? Challenges { get; set; }
    public bool HasMore { get; set; }
}

public static class BrokerProtocol
{
    public const string PipeName = "FileLock.PathGate.v1";
    public const string ServiceName = "FileLockPathGateBroker";
    public const int MaximumMessageBytes = 64 * 1024;
    public static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = false,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        MaxDepth = 16
    };

    // The line framing is bounded before deserialization. A peer cannot allocate
    // arbitrary amounts of memory by supplying a huge or unterminated JSON line.
    public static async Task<byte[]> ReadLineAsync(Stream stream, CancellationToken cancellationToken)
    {
        using var data = new MemoryStream();
        var one = new byte[1];
        while (data.Length < MaximumMessageBytes)
        {
            if (await stream.ReadAsync(one, cancellationToken) != 1)
                throw new IOException("The service connection ended before its response.");
            if (one[0] == '\n') return data.ToArray();
            data.WriteByte(one[0]);
        }
        throw new IOException("The service message is too large.");
    }

    public static async Task WriteLineAsync<T>(Stream stream, T message, CancellationToken cancellationToken)
    {
        var bytes = JsonSerializer.SerializeToUtf8Bytes(message, JsonOptions);
        if (bytes.Length >= MaximumMessageBytes) throw new IOException("The service message is too large.");
        await stream.WriteAsync(bytes, cancellationToken);
        await stream.WriteAsync(new byte[] { (byte)'\n' }, cancellationToken);
        await stream.FlushAsync(cancellationToken);
    }
}

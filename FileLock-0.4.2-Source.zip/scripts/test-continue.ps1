# Dot-sourced only by the elevated disposable native integration harness.
# This helper uses its default elevated administrator token. It never enables
# takeover/backup/restore privileges and accepts only the fresh test fixture.
function Invoke-FileLockContinueProbe {
    param([string]$FixtureRoot, [string]$Path, [string]$CallerSid, [string]$Id)
    $fixture = [IO.Path]::GetFullPath($FixtureRoot).TrimEnd('\')
    $probe = [IO.Path]::GetFullPath($Path).TrimEnd('\')
    if ([IO.Path]::GetFileName($fixture) -notmatch '^native-[a-f0-9]{32}$' -or
        [IO.Path]::GetFileName([IO.Path]::GetDirectoryName($fixture)) -ne '.work' -or
        [IO.Path]::GetFileName([IO.Path]::GetDirectoryName([IO.Path]::GetDirectoryName($fixture))) -ne 'tests' -or
        [IO.Path]::GetDirectoryName($probe) -ine $fixture -or
        [IO.Path]::GetFileName($probe) -notin @('broker-shared-folder', 'broker-individual-folder') -or
        $CallerSid -notmatch '^S-1-5-21-[0-9-]+$' -or $Id -notmatch '^[a-f0-9]{32}$') {
        throw 'Continue probes may only access the isolated broker folder fixtures.'
    }
    $directory = Get-Item -LiteralPath $probe -Force
    for ($parent = $directory; $null -ne $parent; $parent = $parent.Parent) {
        if ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'A Continue probe ancestor is a reparse point.' }
    }
    if (-not ('FileLockContinueProbeNative' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
public static class FileLockContinueProbeNative {
    [StructLayout(LayoutKind.Sequential)] struct Luid { public uint Low; public int High; }
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool GetTokenInformation(IntPtr token, int kind, IntPtr buffer, uint length, out uint returned);
    [DllImport("advapi32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern bool LookupPrivilegeValue(string system, string name, out Luid luid);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern SafeFileHandle CreateFile(string path, uint access, uint share, IntPtr security, uint disposition, uint flags, IntPtr template);
    public static bool PrivilegeEnabled(IntPtr token, string name) {
        Luid target; if (!LookupPrivilegeValue(null, name, out target)) throw new Win32Exception();
        uint length; GetTokenInformation(token, 3, IntPtr.Zero, 0, out length);
        if (length == 0 || length > 65536) throw new InvalidOperationException("Invalid token privilege buffer.");
        IntPtr buffer = Marshal.AllocHGlobal((int)length);
        try {
            if (!GetTokenInformation(token, 3, buffer, length, out length)) throw new Win32Exception();
            int count = Marshal.ReadInt32(buffer);
            for (int index=0; index<count; index++) {
                IntPtr entry = IntPtr.Add(buffer, 4 + index*12);
                var luid = (Luid)Marshal.PtrToStructure(entry, typeof(Luid));
                if (luid.Low == target.Low && luid.High == target.High) return (Marshal.ReadInt32(entry, 8) & 2) != 0;
            }
            return false;
        } finally { Marshal.FreeHGlobal(buffer); }
    }
    public static int OpenWriteRight(string path, uint access) {
        using (var handle = CreateFile(path, access, 7, IntPtr.Zero, 3, 0x02200000, IntPtr.Zero)) {
            return handle.IsInvalid ? Marshal.GetLastWin32Error() : 0;
        }
    }
}
'@
    }
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        $principal = [Security.Principal.WindowsPrincipal]::new($identity)
        $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        $takeEnabled = [FileLockContinueProbeNative]::PrivilegeEnabled($identity.Token, 'SeTakeOwnershipPrivilege')
        $restoreEnabled = [FileLockContinueProbeNative]::PrivilegeEnabled($identity.Token, 'SeRestorePrivilege')
        $backupEnabled = [FileLockContinueProbeNative]::PrivilegeEnabled($identity.Token, 'SeBackupPrivilege')
        if (-not $isAdmin -or $identity.IsSystem -or $identity.User.Value -ne $CallerSid -or $takeEnabled -or $restoreEnabled -or $backupEnabled) {
            throw 'The Continue probe requires the original elevated administrator with default disabled takeover/restore/backup privileges.'
        }
        $info = [IO.DirectoryInfo]::new($probe)
        $sections = [Security.AccessControl.AccessControlSections]'Access,Owner'
        $before = $info.GetAccessControl($sections)
        $owner = $before.GetOwner([Security.Principal.SecurityIdentifier]).Value
        $beforeSddl = $before.GetSecurityDescriptorSddlForm($sections)
        $enumerationDenied = $false
        $readDenied = $false
        try { $null = [IO.Directory]::GetFileSystemEntries($probe) } catch {
            $failure = $_.Exception
            while ($null -ne $failure.InnerException) { $failure = $failure.InnerException }
            if ($failure -isnot [UnauthorizedAccessException]) { throw }
            $enumerationDenied = $true
        }
        try { $null = [IO.File]::ReadAllBytes((Join-Path $probe 'nested\child.txt')) } catch {
            $failure = $_.Exception
            while ($null -ne $failure.InnerException) { $failure = $failure.InnerException }
            if ($failure -isnot [UnauthorizedAccessException]) { throw }
            $readDenied = $true
        }
        $writeDacError = [FileLockContinueProbeNative]::OpenWriteRight($probe, 0x00040000)
        $writeOwnerError = [FileLockContinueProbeNative]::OpenWriteRight($probe, 0x00080000)
        # Explorer Continue grants inherited FullControl to the user's SID.
        $acl = $info.GetAccessControl([Security.AccessControl.AccessControlSections]::Access)
        $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new(
            [Security.Principal.SecurityIdentifier]::new($CallerSid),
            [Security.AccessControl.FileSystemRights]::FullControl,
            [Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit',
            [Security.AccessControl.PropagationFlags]::None,
            [Security.AccessControl.AccessControlType]::Allow))
        $grantDenied = $false
        $grantError = $null
        try { $info.SetAccessControl($acl) } catch {
            $failure = $_.Exception
            while ($null -ne $failure.InnerException) { $failure = $failure.InnerException }
            if ($failure -isnot [UnauthorizedAccessException]) { throw }
            $grantDenied = $true
            $grantError = $failure.Message
        }
        $afterSddl = $info.GetAccessControl($sections).GetSecurityDescriptorSddlForm($sections)
        return @{
            Id = $Id; ProcessId = $PID; UserSid = $identity.User.Value; IsAdministrator = $isAdmin;
            TakeOwnershipEnabled = $takeEnabled; RestoreEnabled = $restoreEnabled; BackupEnabled = $backupEnabled;
            OwnerSid = $owner; EnumerationDenied = $enumerationDenied; ReadDenied = $readDenied;
            WriteDacError = $writeDacError; WriteOwnerError = $writeOwnerError;
            GrantDenied = $grantDenied; GrantError = $grantError; DescriptorUnchanged = ($beforeSddl -ceq $afterSddl)
        }
    } finally { $identity.Dispose() }
}

[CmdletBinding()]
param(
    [switch]$Elevated,
    [string]$FixtureRoot,
    [string]$CallerSid,
    [uint32]$CallerProcessId
)

$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot)).TrimEnd('\')
$workRoot = Join-Path $workspace 'tests\.work'
$buildRoot = Join-Path $workspace 'tests\FileLock.Smoke\bin\Release\net10.0-windows'
$testExecutable = Join-Path $buildRoot 'FileLock.Smoke.exe'
if (-not (Test-Path -LiteralPath $testExecutable -PathType Leaf)) {
    throw 'Build the test executable first: scripts/build.ps1 -Test.'
}
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
$administrator = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $Elevated) {
    if ($administrator) { throw 'Start this script from a normal PowerShell window. The test must retain a normal Windows token.' }
    $CallerSid = $identity.User.Value
    $CallerProcessId = $PID
    $FixtureRoot = Join-Path $workRoot ('native-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path (Join-Path $FixtureRoot 'folder\nested') -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $FixtureRoot 'empty-folder') | Out-Null
    [IO.File]::WriteAllText((Join-Path $FixtureRoot 'single.txt'), 'A disposable original-path lock fixture.')
    [IO.File]::WriteAllText((Join-Path $FixtureRoot 'folder\nested\child.txt'), 'A disposable nested folder fixture.')
    Copy-Item -LiteralPath (Join-Path $env:WINDIR 'System32\whoami.exe') -Destination (Join-Path $FixtureRoot 'application.exe')
    $arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -Elevated -FixtureRoot "' + $FixtureRoot + '" -CallerSid "' + $CallerSid + '" -CallerProcessId ' + $CallerProcessId
    $helper = Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -Verb RunAs -WindowStyle Hidden -PassThru
    # Content access must also be attempted by this actual normal process.
    # A SYSTEM process impersonation alone may suppress Windows access audits.
    $lastProbeId = ''
    $probeRequest = Join-Path $FixtureRoot 'probe-request.json'
    $probeResponse = Join-Path $FixtureRoot 'probe-response.json'
    $probeDeadline = [DateTime]::UtcNow.AddSeconds(120)
    while (-not $helper.HasExited -and [DateTime]::UtcNow -lt $probeDeadline) {
        if (Test-Path -LiteralPath $probeRequest -PathType Leaf) {
            try {
                $request = Get-Content -LiteralPath $probeRequest -Raw | ConvertFrom-Json
                if ($request.Id -ne $lastProbeId -and $request.Id -match '^[a-f0-9]{32}$') {
                    $probePath = [IO.Path]::GetFullPath([string]$request.Path)
                    $fixturePrefix = [IO.Path]::GetFullPath($FixtureRoot).TrimEnd('\') + '\'
                    if (-not $probePath.StartsWith($fixturePrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'The normal-token probe requested a path outside its disposable fixture.' }
                    $operation = [string]$request.Operation
                    if ($operation -notin @('Read', 'Enumerate', 'Execute')) { throw 'The normal-token probe requested an unsupported operation.' }
                    $readSucceeded = $false
                    $probeSucceeded = $false
                    $probeErrorType = $null
                    $probeErrorMessage = $null
                    $probeNativeErrorCode = $null
                    $probeEntryCount = $null
                    try {
                        if ($operation -eq 'Read') {
                            $null = [IO.File]::ReadAllBytes($probePath)
                            $readSucceeded = $true
                            $probeSucceeded = $true
                        } elseif ($operation -eq 'Enumerate') {
                            # Use the actual Windows directory API so an access
                            # denial cannot become a successful empty listing.
                            $entries = @([IO.Directory]::GetFileSystemEntries($probePath))
                            $probeEntryCount = $entries.Count
                            $probeSucceeded = $true
                        } else {
                            $startInfo = [Diagnostics.ProcessStartInfo]::new()
                            $startInfo.FileName = $probePath
                            $startInfo.UseShellExecute = $false
                            $startInfo.CreateNoWindow = $true
                            $startInfo.RedirectStandardOutput = $true
                            $startInfo.RedirectStandardError = $true
                            $probeProcess = [Diagnostics.Process]::Start($startInfo)
                            try {
                                $outputTask = $probeProcess.StandardOutput.ReadToEndAsync()
                                $errorTask = $probeProcess.StandardError.ReadToEndAsync()
                                if (-not $probeProcess.WaitForExit(10000)) {
                                    $probeProcess.Kill()
                                    $probeProcess.WaitForExit()
                                    throw 'The disposable application execution probe timed out.'
                                }
                                $null = $outputTask.GetAwaiter().GetResult()
                                $null = $errorTask.GetAwaiter().GetResult()
                                if ($probeProcess.ExitCode -ne 0) { throw 'The disposable application exited unsuccessfully.' }
                                $probeSucceeded = $true
                            } finally { $probeProcess.Dispose() }
                        }
                    } catch {
                        $probeError = $_.Exception
                        while ($null -ne $probeError.InnerException) { $probeError = $probeError.InnerException }
                        $probeErrorType = $probeError.GetType().FullName
                        $probeErrorMessage = $probeError.Message
                        if ($probeError -is [ComponentModel.Win32Exception]) { $probeNativeErrorCode = $probeError.NativeErrorCode }
                    }
                    $response = @{ Id = [string]$request.Id; Operation = $operation; Succeeded = $probeSucceeded; ReadSucceeded = $readSucceeded; EntryCount = $probeEntryCount; ErrorType = $probeErrorType; ErrorMessage = $probeErrorMessage; NativeErrorCode = $probeNativeErrorCode; ProcessId = $PID }
                    $responseTemporary = $probeResponse + '.next'
                    [IO.File]::WriteAllText($responseTemporary, ($response | ConvertTo-Json -Compress))
                    Move-Item -LiteralPath $responseTemporary -Destination $probeResponse -Force
                    $lastProbeId = [string]$request.Id
                }
            } catch {
                # The service commits complete JSON atomically; a short-lived
                # sharing conflict is retried without reading unrelated paths.
            }
        }
        Start-Sleep -Milliseconds 50
        $helper.Refresh()
    }
    if (-not $helper.HasExited) { throw 'The elevated native test helper exceeded its timeout.' }
    $resultPath = Join-Path $FixtureRoot 'result.json'
    if (Test-Path -LiteralPath $resultPath -PathType Leaf) {
        $result = Get-Content -LiteralPath $resultPath -Raw | ConvertFrom-Json
        foreach ($check in $result.Checks) { Write-Output ('PASS ' + $check) }
        foreach ($failure in $result.Errors) { Write-Output ('FAIL ' + $failure) }
        Write-Output ('Retained test evidence: ' + $resultPath)
        if (-not $result.Passed) { exit 1 }
        exit 0
    }
    throw ('The elevated native test did not produce a result. Installer auditing must be enabled. Fixture: ' + $FixtureRoot)
}

if (-not $administrator) { throw 'Windows administrator elevation is required for the temporary LocalSystem test service.' }
$resolvedFixture = [IO.Path]::GetFullPath($FixtureRoot).TrimEnd('\')
$expectedParent = [IO.Path]::GetFullPath($workRoot).TrimEnd('\')
if ([IO.Path]::GetDirectoryName($resolvedFixture) -ne $expectedParent -or [IO.Path]::GetFileName($resolvedFixture) -notmatch '^native-[a-f0-9]{32}$') {
    throw 'Tests may only operate on a fresh tests/.work/native-<guid> fixture in this workspace.'
}
if ($CallerSid -notmatch '^S-1-5-21-[0-9-]+$' -or $CallerProcessId -eq 0) { throw 'The original unelevated Windows caller is missing.' }
$fixtureDirectory = Get-Item -LiteralPath $resolvedFixture
for ($parent = $fixtureDirectory; $null -ne $parent; $parent = $parent.Parent) {
    if ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'A test fixture ancestor is a junction or symbolic link.' }
}

$operationId = [Guid]::NewGuid().ToString('N').Substring(0, 16)
$serviceName = 'FileLockNativeTest-' + $operationId
$protectedParent = Join-Path $env:ProgramFiles 'FileLockNativeTest'
$protectedBuild = Join-Path $protectedParent $operationId
$systemSid = [Security.Principal.SecurityIdentifier]::new('S-1-5-18')
$adminSid = [Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
$usersSid = [Security.Principal.SecurityIdentifier]::new('S-1-5-32-545')

function Set-ProtectedTestDirectory([string]$Path) {
    $acl = [Security.AccessControl.DirectorySecurity]::new()
    $acl.SetAccessRuleProtection($true, $false)
    $acl.SetOwner($adminSid)
    $acl.SetGroup($adminSid)
    $inherit = [Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit'
    $propagate = [Security.AccessControl.PropagationFlags]::None
    $allow = [Security.AccessControl.AccessControlType]::Allow
    $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($systemSid, 'FullControl', $inherit, $propagate, $allow))
    $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($adminSid, 'FullControl', $inherit, $propagate, $allow))
    $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($usersSid, 'ReadAndExecute', $inherit, $propagate, $allow))
    Set-Acl -LiteralPath $Path -AclObject $acl
}

if (Test-Path -LiteralPath $protectedParent) {
    $parent = Get-Item -LiteralPath $protectedParent
    if ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'The temporary native test installation path is a reparse point.' }
    $parentOwner = (Get-Acl -LiteralPath $protectedParent).GetOwner([Security.Principal.SecurityIdentifier]).Value
    if ($parentOwner -notin @($systemSid.Value, $adminSid.Value)) { throw 'The temporary service installation parent is not owned by SYSTEM or Administrators.' }
} else {
    New-Item -ItemType Directory -Path $protectedParent | Out-Null
    Set-ProtectedTestDirectory $protectedParent
}
New-Item -ItemType Directory -Path $protectedBuild | Out-Null
Set-ProtectedTestDirectory $protectedBuild
$createdService = $false
. (Join-Path $PSScriptRoot 'test-continue.ps1')
$lastAdminProbeId = ''
$adminProbeRequest = Join-Path $resolvedFixture 'admin-probe-request.json'
$adminProbeResponse = Join-Path $resolvedFixture 'admin-probe-response.json'
try {
    Get-ChildItem -LiteralPath $buildRoot -File | Copy-Item -Destination $protectedBuild
    $protectedExecutable = Join-Path $protectedBuild 'FileLock.Smoke.exe'
    $binary = '"' + $protectedExecutable + '" --native-service ' + $serviceName + ' "' + $resolvedFixture + '" ' + $CallerSid + ' ' + $CallerProcessId
    New-Service -Name $serviceName -BinaryPathName $binary -StartupType Manual -DisplayName 'FileLock disposable native integration test' | Out-Null
    $createdService = $true
    Start-Service -Name $serviceName
    $deadline = [DateTime]::UtcNow.AddSeconds(90)
    do {
        Start-Sleep -Milliseconds 250
        # Use this real elevated helper's default token for Explorer Continue
        # regression. The LocalSystem service must not impersonate its own
        # unrestricted service identity for this check.
        if (Test-Path -LiteralPath $adminProbeRequest -PathType Leaf) {
            try {
                $adminRequest = Get-Content -LiteralPath $adminProbeRequest -Raw | ConvertFrom-Json
                if ($adminRequest.Id -ne $lastAdminProbeId -and $adminRequest.Id -match '^[a-f0-9]{32}$') {
                    try {
                        $adminResponse = Invoke-FileLockContinueProbe -FixtureRoot $resolvedFixture -Path ([string]$adminRequest.Path) -CallerSid $CallerSid -Id ([string]$adminRequest.Id)
                    } catch {
                        $adminResponse = @{ Id = [string]$adminRequest.Id; Error = $_.Exception.ToString() }
                    }
                    $adminResponseTemporary = $adminProbeResponse + '.next'
                    [IO.File]::WriteAllText($adminResponseTemporary, ($adminResponse | ConvertTo-Json -Compress))
                    Move-Item -LiteralPath $adminResponseTemporary -Destination $adminProbeResponse -Force
                    $lastAdminProbeId = [string]$adminRequest.Id
                }
            } catch {
                # Atomically committed requests may have a transient sharing
                # conflict; retry without looking outside the fresh fixture.
            }
        }
        $service = Get-Service -Name $serviceName
        if ($service.Status -eq 'Stopped') { break }
    } while ([DateTime]::UtcNow -lt $deadline)
    if ($service.Status -ne 'Stopped') { throw 'The native integration test exceeded its timeout.' }
    $resultPath = Join-Path $resolvedFixture 'result.json'
    if (-not (Test-Path -LiteralPath $resultPath -PathType Leaf)) { throw 'The temporary native test service stopped before producing a report.' }
    $result = Get-Content -LiteralPath $resultPath -Raw | ConvertFrom-Json
    if (-not $result.Passed) { throw 'Native integration tests failed. See result.json and the retained permission journal in the fixture.' }
} finally {
    if ($createdService) {
        $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
        if ($null -ne $service -and $service.Status -ne 'Stopped') { Stop-Service -Name $serviceName -ErrorAction SilentlyContinue }
        & sc.exe delete $serviceName | Out-Null
    }
    # Verify the exact absolute target before removing this disposable helper.
    $resolvedBuild = [IO.Path]::GetFullPath($protectedBuild).TrimEnd('\')
    $resolvedParent = [IO.Path]::GetFullPath($protectedParent).TrimEnd('\')
    if ([IO.Path]::GetDirectoryName($resolvedBuild) -ne $resolvedParent -or [IO.Path]::GetFileName($resolvedBuild) -ne $operationId) {
        throw 'Refusing to remove a temporary helper outside the verified native test directory.'
    }
    Remove-Item -LiteralPath $resolvedBuild -Recurse -Force -ErrorAction SilentlyContinue
}

[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..')).TrimEnd('\')
$workRoot = [IO.Path]::GetFullPath((Join-Path $workspace ('obj\script-compatibility-' + [Guid]::NewGuid().ToString('N'))))
$resultPath = Join-Path $workspace 'obj\script-compatibility-result.json'
$windowsPowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
if (-not (Test-Path -LiteralPath $windowsPowerShell -PathType Leaf)) {
    throw 'Windows PowerShell 5.1 is required to check the installer scripts.'
}

function Assert-CompatibilityWorkRoot {
    if (-not $workRoot.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase) -or
        [IO.Path]::GetDirectoryName($workRoot) -ine (Join-Path $workspace 'obj') -or
        [IO.Path]::GetFileName($workRoot) -notmatch '^script-compatibility-[a-f0-9]{32}$') {
        throw 'Cannot verify the compatibility test directory.'
    }
    $cursor = $workRoot
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw 'A junction or symbolic link is unsupported in the compatibility test path.'
            }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ($cursor -eq $parent) { break }
        $cursor = $parent
    }
}

# Parse the source without dot-sourcing it: no registry, service, privilege, or
# native helper method is invoked by this regression test.
$blocks = @()
foreach ($name in @('installer-common.ps1', 'uninstall.ps1')) {
    $sourcePath = Join-Path $PSScriptRoot $name
    $tokens = $null
    $parseErrors = $null
    $sourceAst = [Management.Automation.Language.Parser]::ParseFile($sourcePath, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count -ne 0) { throw ('Cannot parse {0}: {1}' -f $name, ($parseErrors.Message -join '; ')) }
    $commands = $sourceAst.FindAll({
        param($node)
        $node -is [Management.Automation.Language.CommandAst] -and $node.GetCommandName() -ieq 'Add-Type'
    }, $true)
    foreach ($command in $commands) {
        for ($index = 0; $index -lt $command.CommandElements.Count; $index++) {
            $element = $command.CommandElements[$index]
            if ($element -isnot [Management.Automation.Language.CommandParameterAst] -or $element.ParameterName -ine 'TypeDefinition') { continue }
            $definition = $element.Argument
            if (-not $definition -and $index + 1 -lt $command.CommandElements.Count) { $definition = $command.CommandElements[$index + 1] }
            $constant = $definition -is [Management.Automation.Language.StringConstantExpressionAst] -or
                ($definition -is [Management.Automation.Language.ExpandableStringExpressionAst] -and $definition.NestedExpressions.Count -eq 0)
            if (-not $constant -or $definition.StringConstantType -notin @(
                [Management.Automation.Language.StringConstantType]::SingleQuotedHereString,
                [Management.Automation.Language.StringConstantType]::DoubleQuotedHereString)) {
                throw ('Expected a constant Add-Type here-string in {0} at line {1}.' -f $name, $command.Extent.StartLineNumber)
            }
            $blocks += [pscustomobject]@{
                Script = $name
                Line = $command.Extent.StartLineNumber
                Code = $definition.Value
            }
        }
    }
}
if ($blocks.Count -eq 0) { throw 'No installer Add-Type definitions were found.' }

Assert-CompatibilityWorkRoot
New-Item -ItemType Directory -Path $workRoot -Force | Out-Null
$checks = @()
try {
    $runnerPath = Join-Path $workRoot 'compile.ps1'
    @'
param([string]$SourcePath, [string]$ResultPath, [string]$TemporaryPath)
$ErrorActionPreference = 'Stop'
$env:TEMP = $TemporaryPath
$env:TMP = $TemporaryPath
$compiler = Join-Path ([Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()) 'csc.exe'
$result = [ordered]@{
    Passed = $false
    PowerShellVersion = $PSVersionTable.PSVersion.ToString()
    Edition = [string]$PSVersionTable.PSEdition
    ClrVersion = $PSVersionTable.CLRVersion.ToString()
    CompilerPath = $compiler
    CompilerVersion = (Get-Item -LiteralPath $compiler).VersionInfo.FileVersion
    Error = $null
}
try {
    if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSEdition -ne 'Desktop') {
        throw 'The compatibility test must use Windows PowerShell 5.1, not PowerShell Core.'
    }
    # Compile only. Do not call any static method or constructor in these types.
    Add-Type -TypeDefinition ([IO.File]::ReadAllText($SourcePath)) -ErrorAction Stop
    $result.Passed = $true
} catch { $result.Error = $_.Exception.Message }
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $ResultPath -Encoding UTF8
if ($result.Passed) { exit 0 }
exit 1
'@ | Set-Content -LiteralPath $runnerPath -Encoding UTF8
    for ($index = 0; $index -lt $blocks.Count; $index++) {
        $block = $blocks[$index]
        $blockRoot = Join-Path $workRoot ('block-' + $index)
        New-Item -ItemType Directory -Path $blockRoot -Force | Out-Null
        $sourcePath = Join-Path $blockRoot 'definition.cs'
        $blockResultPath = Join-Path $blockRoot 'result.json'
        [IO.File]::WriteAllText($sourcePath, $block.Code, (New-Object Text.UTF8Encoding($false)))
        # A separate legacy process per block also catches duplicate type-name
        # issues without loading installer types in the caller's newer runtime.
        $childOutput = & $windowsPowerShell -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $runnerPath $sourcePath $blockResultPath $blockRoot 2>&1
        $childExitCode = $LASTEXITCODE
        if (-not (Test-Path -LiteralPath $blockResultPath -PathType Leaf)) {
            throw ('Windows PowerShell produced no result for {0}:{1}: {2}' -f $block.Script, $block.Line, ($childOutput -join ' '))
        }
        $check = Get-Content -LiteralPath $blockResultPath -Raw | ConvertFrom-Json
        $check | Add-Member -NotePropertyName Script -NotePropertyValue $block.Script
        $check | Add-Member -NotePropertyName Line -NotePropertyValue $block.Line
        $check | Add-Member -NotePropertyName ExitCode -NotePropertyValue $childExitCode
        $checks += $check
        if ($check.Passed -and $childExitCode -eq 0) {
            Write-Host ('PASS: {0}:{1} compiles in Windows PowerShell {2} (Framework compiler {3}).' -f $block.Script, $block.Line, $check.PowerShellVersion, $check.CompilerVersion)
        } else {
            Write-Host ('FAIL: {0}:{1}: {2}' -f $block.Script, $block.Line, $check.Error)
        }
    }
    $failed = @($checks | Where-Object { -not $_.Passed -or $_.ExitCode -ne 0 })
    [pscustomobject]@{
        Passed = ($failed.Count -eq 0)
        BlocksChecked = $checks.Count
        Checks = $checks
    } | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath $resultPath -Encoding UTF8
    if ($failed.Count -ne 0) { throw ('{0} installer C# definition(s) failed Windows PowerShell 5.1 compilation. See {1}.' -f $failed.Count, $resultPath) }
    Write-Host ('Installer script compatibility: {0} C# definitions passed; no Windows settings were changed.' -f $checks.Count)
} finally {
    Assert-CompatibilityWorkRoot
    if (Test-Path -LiteralPath $workRoot -PathType Container) {
        foreach ($entry in Get-ChildItem -LiteralPath $workRoot -Force -Recurse) {
            if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Refusing to remove a compatibility test tree containing a junction or symbolic link.' }
        }
        Remove-Item -LiteralPath $workRoot -Recurse -Force
    }
}

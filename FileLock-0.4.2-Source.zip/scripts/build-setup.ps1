[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$PackageRoot,
    [Parameter(Mandatory)][string]$OutputPath
)

$ErrorActionPreference = 'Stop'
$repositoryRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$PackageRoot = [IO.Path]::GetFullPath($PackageRoot).TrimEnd('\')
$OutputPath = [IO.Path]::GetFullPath($OutputPath)
$compiler = Join-Path $env:SystemRoot 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler -PathType Leaf)) { throw 'The 64-bit .NET Framework C# compiler is required to build the Windows setup application.' }
if (-not (Test-Path -LiteralPath $PackageRoot -PathType Container)) { throw 'Publish the FileLock package before building setup.' }
if ($OutputPath.StartsWith($PackageRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Place the setup output outside the package being embedded.' }

function Assert-SetupBuildPath {
    param([string]$Path)
    $cursor = [IO.Path]::GetFullPath($Path)
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            if (((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Setup build does not follow symbolic links or junctions: $cursor" }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
}

Assert-SetupBuildPath $PackageRoot
Assert-SetupBuildPath $OutputPath
foreach ($entry in Get-ChildItem -LiteralPath $PackageRoot -Recurse -Force) {
    if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Package links are unsupported: $($entry.FullName)" }
}
foreach ($relative in @('FileLock\FileLock.exe', 'FileLock\FileLock.dll', 'Service\FileLock.Service.exe', 'Service\FileLock.Service.dll', 'scripts\install.ps1', 'scripts\uninstall.ps1', 'scripts\installer-common.ps1')) {
    if (-not (Test-Path -LiteralPath (Join-Path $PackageRoot $relative) -PathType Leaf)) { throw "The package is incomplete: $relative" }
}
$source = Join-Path $repositoryRoot 'src\FileLock.Setup\Program.cs'
$manifest = Join-Path $repositoryRoot 'src\FileLock.Setup\setup.manifest'
$icon = Join-Path $repositoryRoot 'assets\filelock.ico'
$setupDirectory = Join-Path $PackageRoot 'Setup'
New-Item -ItemType Directory -Path $setupDirectory -Force | Out-Null
$maintenance = Join-Path $setupDirectory 'FileLock.Maintenance.exe'
$references = @('System.dll', 'System.Core.dll', 'System.Drawing.dll', 'System.Windows.Forms.dll', 'System.IO.Compression.dll', 'System.IO.Compression.FileSystem.dll', 'System.Web.Extensions.dll')
$commonArguments = @('/nologo', '/target:winexe', '/platform:x64', '/optimize+', '/debug-', ('/win32manifest:' + $manifest), ('/win32icon:' + $icon)) + @($references | ForEach-Object { '/reference:' + $_ })
& $compiler @commonArguments ('/out:' + $maintenance) $source
if ($LASTEXITCODE -ne 0) { throw 'The FileLock maintenance application could not be compiled.' }

$intermediateRoot = Join-Path $repositoryRoot 'obj\setup'
Assert-SetupBuildPath $intermediateRoot
New-Item -ItemType Directory -Path $intermediateRoot -Force | Out-Null
$intermediate = Join-Path $intermediateRoot ([Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $intermediate | Out-Null
$payload = Join-Path $intermediate 'FileLock.Payload.zip'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
try {
    $output = [IO.File]::Open($payload, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $archive = New-Object IO.Compression.ZipArchive($output, [IO.Compression.ZipArchiveMode]::Create, $false)
        try {
            foreach ($file in Get-ChildItem -LiteralPath $PackageRoot -File -Recurse -Force | Sort-Object FullName) {
                $relative = $file.FullName.Substring($PackageRoot.Length + 1).Replace('\', '/')
                $entry = $archive.CreateEntry($relative, [IO.Compression.CompressionLevel]::Optimal)
                $input = [IO.File]::OpenRead($file.FullName)
                try {
                    $destination = $entry.Open()
                    try { $input.CopyTo($destination) } finally { $destination.Dispose() }
                } finally { $input.Dispose() }
            }
        } finally { $archive.Dispose() }
    } finally { $output.Dispose() }
    New-Item -ItemType Directory -Path (Split-Path -Parent $OutputPath) -Force | Out-Null
    & $compiler @commonArguments ('/out:' + $OutputPath) ('/resource:' + $payload + ',FileLock.Payload.zip') $source
    if ($LASTEXITCODE -ne 0) { throw 'The FileLock setup application could not be compiled.' }
    $verification = Join-Path $intermediate 'verify-package.json'
    $process = Start-Process -FilePath $OutputPath -ArgumentList @('--verify-package', ('"' + $verification + '"')) -Wait -PassThru
    if ($process.ExitCode -ne 0) { throw 'The embedded setup package failed validation.' }
    $report = Get-Content -LiteralPath $verification -Raw | ConvertFrom-Json
    if (-not $report.Passed) { throw 'The embedded setup package failed validation.' }
    Write-Host ('Built FileLock Setup {0}: {1} files, {2:N0} package bytes.' -f $report.Version, $report.Files, $report.UncompressedBytes)
    Write-Host $OutputPath
} finally {
    $resolved = [IO.Path]::GetFullPath($intermediate)
    $expectedParent = [IO.Path]::GetFullPath($intermediateRoot).TrimEnd('\')
    if ([IO.Path]::GetDirectoryName($resolved) -ine $expectedParent -or [IO.Path]::GetFileName($resolved) -notmatch '^[0-9a-f]{32}$') { throw 'The intermediate setup directory could not be verified for cleanup.' }
    Assert-SetupBuildPath $resolved
    foreach ($entry in Get-ChildItem -LiteralPath $resolved -Recurse -Force) {
        if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'The intermediate setup directory contains a link; cleanup stopped.' }
    }
    Remove-Item -LiteralPath $resolved -Recurse -Force
}

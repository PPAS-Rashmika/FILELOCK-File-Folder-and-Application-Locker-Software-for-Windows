[CmdletBinding()]
param([switch]$Test, [switch]$SkipBuild)

$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..')).TrimEnd('\')
$package = Join-Path $workspace 'dist'
$release = Join-Path $workspace 'release'
[xml]$project = Get-Content -LiteralPath (Join-Path $workspace 'src\FileLock\FileLock.csproj') -Raw
$version = [string]$project.Project.PropertyGroup.Version
if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'Set a three-part application Version before releasing.' }
New-Item -ItemType Directory -Path $release -Force | Out-Null
if (-not $SkipBuild) {
    # Release output always starts fresh so older binaries or diagnostics
    # cannot silently enter a new distributable archive.
    if (Test-Path -LiteralPath $package) {
        $resolvedPackage = (Get-Item -LiteralPath $package -Force).FullName
        if ($resolvedPackage -ine (Join-Path $workspace 'dist') -or [IO.Path]::GetDirectoryName($resolvedPackage) -ine $workspace) { throw 'Cannot verify the generated package directory.' }
        foreach ($entry in @((Get-Item -LiteralPath $resolvedPackage -Force)) + @(Get-ChildItem -LiteralPath $resolvedPackage -Force -Recurse)) {
            if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Release cleanup does not follow links.' }
        }
        Remove-Item -LiteralPath $resolvedPackage -Recurse -Force
    }
    & (Join-Path $PSScriptRoot 'build.ps1') -Test:$Test
    if ($LASTEXITCODE -ne 0) { throw 'The application build failed.' }
}
$setup = Join-Path $release ('FileLock-' + $version + '-Setup.exe')
& (Join-Path $PSScriptRoot 'build-setup.ps1') -PackageRoot $package -OutputPath $setup
if ($LASTEXITCODE -ne 0) { throw 'Setup compilation or package verification failed.' }
if ($Test) {
    & (Join-Path $workspace 'src\FileLock.Setup\test-setup.ps1') -SetupExe $setup -MaintenanceExe (Join-Path $package 'Setup\FileLock.Maintenance.exe') -OutputPath (Join-Path $workspace 'artifacts\setup-validation.json')
}
$applicationArchive = Join-Path $release ('FileLock-' + $version + '-Windows.zip')
Compress-Archive -Path (Join-Path $package '*') -DestinationPath $applicationArchive -Force

# An explicit source allow-list excludes runtime state, fixtures, old releases,
# build output and machine diagnostics, even when Git is not installed.
Add-Type -AssemblyName System.IO.Compression.FileSystem
$sourceArchive = Join-Path $release ('FileLock-' + $version + '-Source.zip')
if (Test-Path -LiteralPath $sourceArchive) { Remove-Item -LiteralPath $sourceArchive -Force }
$files = [Collections.Generic.List[IO.FileInfo]]::new()
foreach ($name in @('.gitignore', '.gitattributes', '.editorconfig', 'global.json', 'NuGet.Config', 'FileLock.slnx', 'README.md', 'FileLock.cmd', 'install.cmd', 'uninstall.cmd')) {
    $files.Add((Get-Item -LiteralPath (Join-Path $workspace $name) -Force))
}
foreach ($directory in @('src', 'scripts', 'assets', 'tests', 'docs', '.github')) {
    $root = Join-Path $workspace $directory
    $pendingDirectories = [Collections.Generic.Queue[string]]::new()
    $pendingDirectories.Enqueue($root)
    while ($pendingDirectories.Count -gt 0) {
        $sourceDirectory = $pendingDirectories.Dequeue()
        if ((Get-Item -LiteralPath $sourceDirectory -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
            throw 'Source archives do not follow directory links.'
        }
        foreach ($entry in Get-ChildItem -LiteralPath $sourceDirectory -Force) {
            if ($entry.PSIsContainer) {
                # Do not enumerate generated/system-owned test state at all.
                # Filtering after -Recurse both reads excluded state and fails
                # when the native fixture correctly restricts its permissions.
                if ($entry.Name -in @('bin', 'obj', '.work', 'TestData')) { continue }
                $pendingDirectories.Enqueue($entry.FullName)
            } else {
                if ($entry.Extension -in @('.exe', '.dll', '.pdb', '.zip', '.log', '.dpapi')) { continue }
                $files.Add($entry)
            }
        }
    }
}
$archive = [IO.Compression.ZipFile]::Open($sourceArchive, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($file in $files | Sort-Object FullName -Unique) {
        $absolute = [IO.Path]::GetFullPath($file.FullName)
        if (-not $absolute.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase) -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'Source archives accept only regular files in this workspace.'
        }
        $relative = $absolute.Substring($workspace.Length + 1).Replace('\', '/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $absolute, $relative, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $archive.Dispose() }

$checksums = foreach ($path in @($setup, $applicationArchive, $sourceArchive)) {
    (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() + '  ' + [IO.Path]::GetFileName($path)
}
[IO.File]::WriteAllLines((Join-Path $release 'SHA256SUMS.txt'), $checksums, [Text.UTF8Encoding]::new($false))
Write-Host ('Application installer: ' + $setup)
Write-Host ('Application package: ' + $applicationArchive)
Write-Host ('GitHub source archive: ' + $sourceArchive)

[CmdletBinding()]
param([switch]$Elevated, [string]$OutputPath)
$ErrorActionPreference = 'Stop'
if (-not $OutputPath) { $OutputPath = Join-Path (Split-Path $PSScriptRoot -Parent) 'artifacts\folder-diagnostics.json' }
$OutputPath = [IO.Path]::GetFullPath($OutputPath)
New-Item -ItemType Directory -Path (Split-Path -Parent $OutputPath) -Force | Out-Null
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$admin = ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) {
    if ($Elevated) { throw 'This read-only diagnostic requires administrator access.' }
    $arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -Elevated -OutputPath "' + $OutputPath + '"'
    $helper = Start-Process powershell.exe -ArgumentList $arguments -Verb RunAs -WindowStyle Hidden -PassThru -Wait
    exit $helper.ExitCode
}
$report = [ordered]@{ CapturedUtc = [DateTime]::UtcNow.ToString('o'); Service = $null; Processes = @(); Items = @(); Errors = @() }
try {
    $report.Service = Get-CimInstance Win32_Service -Filter "Name='FileLockPathGateBroker'" | Select-Object State, StartMode, StartName, PathName
    $report.Processes = @(Get-Process FileLock -ErrorAction SilentlyContinue | Select-Object Id, Path, MainWindowTitle)
    $stateFile = Join-Path $env:ProgramData 'FileLockPathGate\state.dpapi'
    if (Test-Path -LiteralPath $stateFile) {
        Add-Type -AssemblyName System.Security
        $plaintext = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($stateFile), $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
        try {
            $state = [Text.Encoding]::UTF8.GetString($plaintext) | ConvertFrom-Json
            foreach ($user in $state.Users) {
                foreach ($item in $user.Items) {
                    $entry = [ordered]@{ Id = $item.Id; Path = $item.OriginalPath; Kind = $item.Kind; Phase = $item.ProtectionPhase; Error = $item.ProtectionError; LeaseUntilUtc = $item.ActiveLeaseUntilUtc; JournalCount = @($item.PermissionJournal).Count; RootPermissions = $null }
                    try {
                        $acl = Get-Acl -LiteralPath $item.OriginalPath
                        $entry.RootPermissions = $acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]'Owner,Group,Access')
                    } catch { $entry.RootPermissions = 'Cannot inspect: ' + $_.Exception.Message }
                    $report.Items += [pscustomobject]$entry
                }
            }
        } finally { [Array]::Clear($plaintext, 0, $plaintext.Length); $state = $null }
    }
} catch { $report.Errors += $_.Exception.Message }
# Deliberately omit PIN hashes, salts, root secrets and recovery material.
$report | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
if ($report.Errors.Count) { exit 1 }

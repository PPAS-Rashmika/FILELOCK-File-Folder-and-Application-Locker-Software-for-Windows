[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$workspace = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$installed = Join-Path $env:ProgramFiles 'FileLock\App\FileLock.exe'
$published = Join-Path $workspace 'dist\FileLock\FileLock.exe'
$executable = if (Test-Path -LiteralPath $published -PathType Leaf) { $published } elseif (Test-Path -LiteralPath $installed -PathType Leaf) { $installed } else { $published }

if (-not (Test-Path -LiteralPath $executable -PathType Leaf)) {
    & (Join-Path $PSScriptRoot 'build.ps1')
}

# Open the desktop only; this script makes no machine-wide changes.
Start-Process -FilePath $executable -WorkingDirectory (Split-Path -Parent $executable) -WindowStyle Normal

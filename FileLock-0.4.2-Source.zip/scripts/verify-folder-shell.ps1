[CmdletBinding()]
param([string]$OutputPath)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Split-Path $PSScriptRoot -Parent))
if (-not $OutputPath) { $OutputPath = Join-Path $workspace 'artifacts\folder-shell-verification.json' }
$OutputPath = [IO.Path]::GetFullPath($OutputPath)
New-Item -ItemType Directory -Path (Split-Path -Parent $OutputPath) -Force | Out-Null
$executable = Join-Path $env:ProgramFiles 'FileLock\App\FileLock.exe'
if (-not (Test-Path -LiteralPath $executable -PathType Leaf)) { throw 'Install the completed FileLock package first.' }
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
if (([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Verify Explorer behavior with an ordinary desktop token.' }
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class FileLockShellProbe {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] public struct ExecuteInfo {
        public int Size; public uint Mask; public IntPtr Window;
        [MarshalAs(UnmanagedType.LPWStr)] public string Verb;
        [MarshalAs(UnmanagedType.LPWStr)] public string File;
        [MarshalAs(UnmanagedType.LPWStr)] public string Parameters;
        [MarshalAs(UnmanagedType.LPWStr)] public string Directory;
        public int Show; public IntPtr Instance, IdList;
        [MarshalAs(UnmanagedType.LPWStr)] public string Class;
        public IntPtr ClassKey; public uint HotKey; public IntPtr Icon, Process;
    }
    [DllImport("shell32.dll", CharSet = CharSet.Unicode, SetLastError = true)] public static extern bool ShellExecuteEx(ref ExecuteInfo info);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] public static extern bool QueryFullProcessImageName(IntPtr process, uint flags, StringBuilder name, ref uint size);
    [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr handle);
    public delegate bool WindowCallback(IntPtr window, IntPtr data);
    [DllImport("user32.dll")] public static extern bool EnumWindows(WindowCallback callback, IntPtr data);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr window);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr window, out uint pid);
    public static int VisibleFor(uint pid) {
        int count = 0;
        EnumWindows((window, data) => { uint owner; GetWindowThreadProcessId(window, out owner); if (owner == pid && IsWindowVisible(window)) count++; return true; }, IntPtr.Zero);
        return count;
    }
}
'@
$report = [ordered]@{ Passed = $false; Checks = @(); Errors = @(); DefaultActionExecutable = $null; AgentVisibleWindows = $null }
$fixture = Join-Path $workspace ('tests\.work\shell-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $fixture | Out-Null
try {
    $configure = Start-Process -FilePath $executable -ArgumentList '--enable-folder-prompts' -PassThru -Wait -WindowStyle Hidden
    if ($configure.ExitCode -ne 0) { throw 'Explorer integration configuration failed.' }
    $shellKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Software\Classes\Directory\shell')
    try { if ($shellKey.GetValue('') -ne 'FileLock.Open') { throw 'The Explorer folder default action is not configured.' } } finally { $shellKey.Dispose() }
    $report.Checks += 'Current-user original-folder verb enabled'
    $info = New-Object FileLockShellProbe+ExecuteInfo
    $info.Size = [Runtime.InteropServices.Marshal]::SizeOf($info)
    $info.Mask = 0x40 -bor 0x100; $info.File = $fixture; $info.Show = 1
    if (-not [FileLockShellProbe]::ShellExecuteEx([ref]$info)) { throw 'Windows failed to invoke the original folder default action.' }
    try {
        if ($info.Process -eq [IntPtr]::Zero) { throw 'The original folder action did not launch the FileLock gate.' }
        $name = [Text.StringBuilder]::new(2048); [uint32]$length = 2048
        if (-not [FileLockShellProbe]::QueryFullProcessImageName($info.Process, 0, $name, [ref]$length)) { throw 'Cannot verify the invoked folder handler.' }
        $report.DefaultActionExecutable = $name.ToString()
        if (-not $name.ToString().Equals($executable, [StringComparison]::OrdinalIgnoreCase)) { throw 'Windows bypassed the configured folder handler.' }
    } finally { if ($info.Process -ne [IntPtr]::Zero) { $null = [FileLockShellProbe]::CloseHandle($info.Process) } }
    $report.Checks += 'Real-folder default opening invokes installed FileLock directly'
    $deadline = [DateTime]::UtcNow.AddSeconds(15)
    $foundWindow = $null
    $shell = New-Object -ComObject Shell.Application
    do {
        foreach ($window in @($shell.Windows())) {
            try {
                if ($window.Document.Folder.Self.Path -eq $fixture) { $foundWindow = $window; break }
            } catch { }
        }
        if ($foundWindow) { break }
        Start-Sleep -Milliseconds 200
    } while ([DateTime]::UtcNow -lt $deadline)
    if (-not $foundWindow) { throw 'The ordinary folder was not forwarded to Explorer.' }
    $report.Checks += 'Unprotected original folder opens normally in Explorer'
    $agents = @(Get-Process FileLock -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $executable })
    if ($agents.Count -ne 1) { throw 'Expected exactly one background FileLock agent.' }
    $report.AgentVisibleWindows = [FileLockShellProbe]::VisibleFor([uint32]$agents[0].Id)
    if ($report.AgentVisibleWindows -ne 0) { throw 'Folder opening unexpectedly displayed a FileLock window.' }
    $report.Checks += 'Folder opening starts only one invisible background agent'
    $foundWindow.Quit()
    $report.Passed = $true
} catch { $report.Errors += $_.Exception.ToString() }
finally { $report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $OutputPath -Encoding UTF8 }
if (-not $report.Passed) { exit 1 }

[CmdletBinding()]
param(
    [ValidateSet('Debug', 'Release')]
    [string]$Configuration = 'Release',
    [switch]$Test,
    [switch]$Setup,
    [string]$OutputRoot
)

$ErrorActionPreference = 'Stop'
$workspace = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$publishRoot = if ($OutputRoot) {
    if (-not [System.IO.Path]::IsPathRooted($OutputRoot)) { throw 'OutputRoot must be an absolute path.' }
    [System.IO.Path]::GetFullPath($OutputRoot).TrimEnd('\')
} else { Join-Path $workspace 'dist' }
if ($publishRoot -ieq $workspace) { throw 'Choose a separate package output directory.' }
$desktopProject = Join-Path $workspace 'src\FileLock\FileLock.csproj'
$serviceProject = Join-Path $workspace 'src\FileLock.Service\FileLock.Service.csproj'
$testProject = Join-Path $workspace 'tests\FileLock.Smoke\FileLock.Smoke.csproj'
$uiTestProject = Join-Path $workspace 'tests\FileLock.UiSmoke\FileLock.UiSmoke.csproj'
$offlineFeed = Join-Path $workspace 'obj\offline-feed'

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'Install the .NET 10 SDK for Windows, then run this script again.'
}

# No package downloads, installation, or service registration.
New-Item -ItemType Directory -Path $offlineFeed -Force | Out-Null
$env:DOTNET_CLI_HOME = Join-Path $workspace 'obj\dotnet-home'
New-Item -ItemType Directory -Path $env:DOTNET_CLI_HOME -Force | Out-Null
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_SKIP_FIRST_TIME_EXPERIENCE = '1'
$env:DOTNET_GENERATE_ASPNET_CERTIFICATE = 'false'
$env:DOTNET_ADD_GLOBAL_TOOLS_TO_PATH = 'false'
$env:MSBuildEnableWorkloadResolver = 'false'

function Invoke-DotNet {
    param([string[]]$Arguments)
    & dotnet @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Build command failed (exit $LASTEXITCODE)."
    }
}

foreach ($target in @(
    @{ Project = $desktopProject; Output = (Join-Path $publishRoot 'FileLock') },
    @{ Project = $serviceProject; Output = (Join-Path $publishRoot 'Service') }
)) {
    Invoke-DotNet -Arguments @('restore', $target.Project, '--source', $offlineFeed, '-p:NuGetAudit=false', '-m:1', '-nr:false')
    Invoke-DotNet -Arguments @('publish', $target.Project, '--no-restore', '--configuration', $Configuration,
        '--self-contained', 'false', '--output', $target.Output, '-p:UseAppHost=true', '-m:1', '-nr:false')
}
Copy-Item -LiteralPath (Join-Path $workspace 'README.md') -Destination (Join-Path $publishRoot 'FileLock\README.md') -Force
Copy-Item -LiteralPath (Join-Path $workspace 'docs') -Destination (Join-Path $publishRoot 'FileLock') -Recurse -Force

# Building packages these scripts without executing them or changing Windows.
$packageScripts = Join-Path $publishRoot 'scripts'
New-Item -ItemType Directory -Path $packageScripts -Force | Out-Null
foreach ($name in @('installer-common.ps1', 'install.ps1', 'uninstall.ps1')) {
    Copy-Item -LiteralPath (Join-Path $workspace ('scripts\' + $name)) -Destination $packageScripts -Force
}
foreach ($name in @('README.md', 'FileLock.cmd', 'install.cmd', 'uninstall.cmd')) {
    Copy-Item -LiteralPath (Join-Path $workspace $name) -Destination $publishRoot -Force
}
Copy-Item -LiteralPath (Join-Path $workspace 'docs') -Destination $publishRoot -Recurse -Force

if ($Test) {
    & (Join-Path $PSScriptRoot 'test-script-compatibility.ps1')
    Invoke-DotNet -Arguments @('restore', $testProject, '--source', $offlineFeed, '-p:NuGetAudit=false', '-m:1', '-nr:false')
    Invoke-DotNet -Arguments @('build', $testProject, '--no-restore', '--configuration', $Configuration, '-m:1', '-nr:false')
    Invoke-DotNet -Arguments @((Join-Path $workspace "tests\FileLock.Smoke\bin\$Configuration\net10.0-windows\FileLock.Smoke.dll"))
    Invoke-DotNet -Arguments @('restore', $uiTestProject, '--source', $offlineFeed, '-p:NuGetAudit=false', '-m:1', '-nr:false')
    Invoke-DotNet -Arguments @('build', $uiTestProject, '--no-restore', '--configuration', $Configuration, '-m:1', '-nr:false')
    Invoke-DotNet -Arguments @((Join-Path $workspace "tests\FileLock.UiSmoke\bin\$Configuration\net10.0-windows\FileLock.UiSmoke.dll"))
}

if ($Setup) {
    [xml]$versionProject = Get-Content -LiteralPath $desktopProject -Raw
    $setupVersion = [string]$versionProject.Project.PropertyGroup.Version
    $setupOutput = Join-Path $workspace ('release\FileLock-' + $setupVersion + '-Setup.exe')
    & (Join-Path $PSScriptRoot 'build-setup.ps1') -PackageRoot $publishRoot -OutputPath $setupOutput
    if ($LASTEXITCODE -ne 0) { throw 'The application installer build failed.' }
}

Write-Host "Desktop: $(Join-Path $publishRoot 'FileLock\FileLock.exe')"
Write-Host "Service: $(Join-Path $publishRoot 'Service\FileLock.Service.exe')"
Write-Host "Installer: $(Join-Path $publishRoot 'install.cmd')"
Write-Host 'Run the installer with administrator approval to enable the native Windows permission service. No custom driver is required.'

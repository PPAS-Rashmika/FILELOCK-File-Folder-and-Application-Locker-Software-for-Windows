using System.Security.AccessControl;
using FileLock.Shared;

namespace FileLock.Service;

internal sealed partial class NativePathProtection : IDisposable
{
    internal const int AccessWindowSeconds = 15;
    internal const int MaximumJournalEntries = 10_000;
    private readonly Action _persist;
    private readonly Func<ItemState, string, bool>? _canRelocate;
    private AccessAuditListener? _audit;
    public string? UnavailableReason { get; private set; }
    public bool PermissionAvailable { get; private set; }
    public bool Available => PermissionAvailable && _audit?.Healthy == true && SecurityNative.FailureAuditingEnabled();
    public System.Collections.Concurrent.ConcurrentQueue<AccessAuditNotification> Notifications => _audit?.Notifications ?? _empty;
    private readonly System.Collections.Concurrent.ConcurrentQueue<AccessAuditNotification> _empty = new();

    internal NativePathProtection(Action persist, Func<ItemState, string, bool>? canRelocate = null)
    {
        _persist = persist;
        _canRelocate = canRelocate;
        try
        {
            SecurityNative.EnableRequiredPrivileges();
            PermissionAvailable = true;
            if (!SecurityNative.FailureAuditingEnabled()) throw new IOException("File System and Handle Manipulation failure auditing must both be enabled. Run the FileLock installer to enable passcode prompts.");
            _audit = new();
        }
        catch (Exception error) { UnavailableReason = error.Message; }
    }

    public void Prepare(ItemState item)
    {
        RequirePermissions();
        using var tree = OpenTree(item, capture: true, exclusiveFiles: true);
        foreach (var target in tree.Objects)
        {
            var descriptor = new RawSecurityDescriptor(Convert.FromBase64String(target.Entry.OriginalSecurityDescriptor), 0);
            if (descriptor.Owner?.Value != item.OwnerSid) throw new GateException("Protect only files and folders owned by your Windows account.", "NOT_OWNER");
        }
        item.PermissionJournal = tree.Objects.Select(target => target.Entry).ToList();
        item.NtPath = tree.Objects[0].NtPath;
        item.ProtectionPhase = "Staged";
        item.ActiveLeaseUntilUtc = null;
        item.ProtectionError = null;
    }

    // The original descriptors are durable before any security update. A failed
    // transaction retains the journal and can always be retried or removed.
    public void Upsert(ItemState item)
    {
        RequirePermissions();
        if (TryRecoverMovedLocation(item)) return;
        UpsertAtCurrentLocation(item);
    }

    private void UpsertAtCurrentLocation(ItemState item)
    {
        RequirePermissions();
        if (item.PermissionJournal.Count == 0) throw new IOException("This item has no recoverable permission journal.");
        using var tree = OpenTree(item, capture: true, exclusiveFiles: item.ProtectionPhase == "Staged");
        var savedRoot = item.PermissionJournal.SingleOrDefault(entry => entry.RelativePath == "") ?? throw new IOException("Missing root permission journal.");
        var replacementFile = !SecurityNative.IdentityMatches(savedRoot, tree.Objects[0].Entry);
        if (replacementFile)
        {
            // Editors commonly save by replacing a file at its original name.
            // Adopt only an own-account file on the same verified volume during
            // a PIN-approved use; directories and locked replacements still fail.
            var currentRoot = tree.Objects[0].Entry;
            var currentSecurity = new RawSecurityDescriptor(Convert.FromBase64String(currentRoot.OriginalSecurityDescriptor), 0);
            if (item.ProtectionPhase != "Open" || item.Kind == ProtectionKind.Folder || currentRoot.IsDirectory
                || !currentRoot.VolumeIdentity.Equals(savedRoot.VolumeIdentity, StringComparison.OrdinalIgnoreCase)
                || currentSecurity.Owner?.Value != item.OwnerSid)
                throw new IOException("The protected root now refers to a different file or volume. Permissions were left unchanged.");
        }
        // Device volume numbers can change after a reboot. Derive audit matching
        // from this identity-verified handle instead of the previously saved name.
        item.NtPath = tree.Objects[0].NtPath;
        var journals = item.PermissionJournal.ToDictionary(entry => entry.RelativePath, StringComparer.OrdinalIgnoreCase);
        var changed = false;
        foreach (var target in tree.Objects)
        {
            if (journals.TryGetValue(target.Entry.RelativePath, out var saved) && SecurityNative.IdentityMatches(saved, target.Entry))
            {
                if (item.ProtectionPhase == "Staged" && saved.OriginalSecurityDescriptor != target.Entry.OriginalSecurityDescriptor)
                    throw new IOException("Windows permissions changed during validation. Remove this staged item and add it again.");
                continue;
            }
            if (item.ProtectionPhase != "Open") throw new IOException("A protected file was replaced or an unjournaled file appeared. Recovery requires review of this location.");
            journals[target.Entry.RelativePath] = target.Entry;
            changed = true;
        }
        // Deleted descendants during an approved access window are dropped; no
        // descriptor is ever applied to a different file with a reused name.
        if (item.ProtectionPhase == "Open")
        {
            var current = tree.Objects.Select(target => target.Entry.RelativePath).ToHashSet(StringComparer.OrdinalIgnoreCase);
            changed |= journals.Keys.Any(path => !current.Contains(path));
            item.PermissionJournal = journals.Values.Where(entry => current.Contains(entry.RelativePath)).ToList();
        }
        if (changed) _persist();
        var applied = new List<SecurityNative.OpenObject>();
        try
        {
            // Lock the containing directory first, then its descendants. All
            // handles are opened and identities checked before this first write.
            foreach (var target in tree.Objects)
            {
                SecurityNative.Lock(target, journals[target.Entry.RelativePath], item.OwnerSid);
                applied.Add(target);
            }
            item.ActiveLeaseUntilUtc = null;
            item.ProtectionPhase = "Locked";
            item.ProtectionError = null;
            _persist();
        }
        catch (Exception error)
        {
            // A new Add can be rolled back completely. Expiry/relock failures
            // remain denied wherever lock permissions have already been applied.
            if (item.ProtectionPhase == "Staged")
            {
                foreach (var target in applied) try { SecurityNative.Restore(target, journals[target.Entry.RelativePath]); } catch { }
            }
            item.ProtectionError = error.Message;
            try { _persist(); } catch { }
            throw;
        }
    }

    public void Grant(ItemState item, uint sessionId, int seconds = AccessWindowSeconds)
    {
        RequireAvailable();
        TryRecoverMovedLocation(item);
        using var tree = OpenTree(item, capture: false);
        ValidateAll(item, tree);
        // Commit the deadline before restoration. A service restart always
        // locks Open items, including a crash during this restoration.
        item.ActiveLeaseUntilUtc = DateTimeOffset.UtcNow.AddSeconds(seconds);
        item.ProtectionPhase = "Open";
        item.ProtectionError = null;
        _persist();
        var journal = item.PermissionJournal.ToDictionary(entry => entry.RelativePath, StringComparer.OrdinalIgnoreCase);
        try
        {
            foreach (var target in tree.Objects) SecurityNative.Restore(target, journal[target.Entry.RelativePath]);
            item.ProtectionError = null;
        }
        catch (Exception error)
        {
            foreach (var target in tree.Objects) try { SecurityNative.Lock(target, journal[target.Entry.RelativePath], item.OwnerSid); } catch { }
            item.ActiveLeaseUntilUtc = null;
            item.ProtectionPhase = "Locked";
            item.ProtectionError = "Unlock was rolled back: " + error.Message;
            _persist();
            throw;
        }
    }

    public void Renew(ItemState item)
    {
        RequireAvailable();
        if (item.ProtectionPhase != "Open" || item.ProtectionError != null || item.ActiveLeaseUntilUtc is not { } until || until <= DateTimeOffset.UtcNow)
            throw new GateException("This access session has closed. Enter the location passcode again.", "ACCESS_SESSION_EXPIRED");
        var previous = item.ActiveLeaseUntilUtc;
        item.ActiveLeaseUntilUtc = DateTimeOffset.UtcNow.AddSeconds(AccessWindowSeconds);
        try { _persist(); }
        catch { item.ActiveLeaseUntilUtc = previous; throw; }
    }

    public void Revoke(ItemState item) => Upsert(item);

    public void Remove(ItemState item)
    {
        RequirePermissions();
        if (item.PermissionJournal.Count == 0) throw new IOException("Missing permission journal; this item cannot be removed safely.");
        try { TryRecoverMovedLocation(item); }
        catch (GateException error) when (error.Code is "LOCATION_NOT_FOUND" or "LOCATION_DELETED")
        {
            RemoveDeletedLocation(item);
            return;
        }
        // Capture files created during the approved window before restoring all
        // original descriptors. Revoke journals these files durably first.
        if (item.ProtectionPhase == "Open") Upsert(item);
        using var tree = OpenTree(item, capture: false);
        ValidateAll(item, tree);
        var journal = item.PermissionJournal.ToDictionary(entry => entry.RelativePath, StringComparer.OrdinalIgnoreCase);
        try
        {
            foreach (var target in tree.Objects) SecurityNative.Restore(target, journal[target.Entry.RelativePath]);
        }
        catch
        {
            foreach (var target in tree.Objects) try { SecurityNative.Lock(target, journal[target.Entry.RelativePath], item.OwnerSid); } catch { }
            throw;
        }
    }

    private static void ValidateRoot(ItemState item, OpenTreeResult tree)
    {
        var original = item.PermissionJournal.SingleOrDefault(entry => entry.RelativePath == "") ?? throw new IOException("Missing root permission journal.");
        if (!SecurityNative.IdentityMatches(original, tree.Objects[0].Entry)) throw new IOException("The protected root now refers to a different file or volume. Permissions were left unchanged.");
    }
    private static void ValidateAll(ItemState item, OpenTreeResult tree)
    {
        ValidateRoot(item, tree);
        var journal = item.PermissionJournal.ToDictionary(entry => entry.RelativePath, StringComparer.OrdinalIgnoreCase);
        foreach (var target in tree.Objects)
            if (!journal.TryGetValue(target.Entry.RelativePath, out var original) || !SecurityNative.IdentityMatches(original, target.Entry))
                throw new IOException("A protected descendant changed identity. Permissions were left unchanged.");
        if (journal.Count != tree.Objects.Count) throw new IOException("A protected descendant is missing. Permissions were left unchanged.");
    }

    private sealed class OpenTreeResult : IDisposable
    {
        internal List<SecurityNative.OpenObject> Objects { get; } = [];
        public void Dispose() { foreach (var target in Objects) target.Dispose(); }
    }
    private static OpenTreeResult OpenTree(ItemState item, bool capture, bool exclusiveFiles = false)
    {
        var result = new OpenTreeResult();
        try
        {
            var queue = new Queue<(string Path, string Relative)>(); queue.Enqueue((item.OriginalPath, ""));
            while (queue.Count > 0)
            {
                if (result.Objects.Count >= MaximumJournalEntries) throw new GateException("Select a folder containing fewer than 10,000 items.", "INVALID_PATH");
                var (path, relative) = queue.Dequeue();
                var attributes = File.GetAttributes(path);
                var target = SecurityNative.Open(path, relative, capture, exclusiveFiles && !attributes.HasFlag(FileAttributes.Directory));
                result.Objects.Add(target);
                if (attributes.HasFlag(FileAttributes.Directory) != target.Entry.IsDirectory) throw new IOException("A file changed type during validation.");
                if (!target.Entry.VolumeIdentity.Equals(item.VolumeIdentity, StringComparison.OrdinalIgnoreCase)) throw new IOException("A protected path changed volume.");
                if (target.Entry.IsDirectory)
                    foreach (var child in Directory.EnumerateFileSystemEntries(path)) queue.Enqueue((child, Path.GetRelativePath(item.OriginalPath, child)));
            }
            if ((item.Kind == ProtectionKind.Folder) != result.Objects[0].Entry.IsDirectory) throw new IOException("The protected item type changed.");
            return result;
        }
        catch { result.Dispose(); throw; }
    }
    private void RequirePermissions()
    {
        if (!PermissionAvailable) throw new GateException("Windows location permissions are unavailable. " + UnavailableReason, "PROTECTION_UNAVAILABLE");
    }
    private void RequireAvailable()
    {
        if (!Available) throw new GateException("Windows location protection is unavailable. " + UnavailableReason, "PROTECTION_UNAVAILABLE");
    }
    public void Dispose() { _audit?.Dispose(); PermissionAvailable = false; }
}

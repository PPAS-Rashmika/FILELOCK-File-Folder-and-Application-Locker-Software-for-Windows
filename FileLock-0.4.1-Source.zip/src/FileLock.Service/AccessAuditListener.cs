using System.Collections.Concurrent;
using System.Diagnostics.Eventing.Reader;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Xml;
using System.Xml.Linq;

namespace FileLock.Service;

internal sealed record AccessAuditNotification(string OwnerSid, string Path, uint ProcessId, uint SessionId);

// Security 4656 failure records come from the Windows object manager after the
// denied open. The desktop shows the passcode and reopens after approval.
internal sealed class AccessAuditListener : IDisposable
{
    private readonly EventLogWatcher _watcher;
    public ConcurrentQueue<AccessAuditNotification> Notifications { get; } = new();
    public bool Healthy { get; private set; } = true;

    internal AccessAuditListener()
    {
        var query = new EventLogQuery("Security", PathType.LogName,
            "*[System[(EventID=4656) and band(Keywords,4503599627370496)]]");
        _watcher = new EventLogWatcher(query);
        _watcher.EventRecordWritten += OnRecord;
        _watcher.Enabled = true;
    }
    private void OnRecord(object? sender, EventRecordWrittenEventArgs args)
    {
        if (args.EventException != null) { Healthy = false; return; }
        if (args.EventRecord == null) return;
        using var record = args.EventRecord;
        try
        {
            var notification = Parse(record.ToXml());
            if (notification != null && Notifications.Count < 1024) Notifications.Enqueue(notification);
        }
        catch (Exception error) when (error is XmlException or ArgumentException or InvalidOperationException) { }
    }
    internal static AccessAuditNotification? Parse(string xml)
    {
        if (xml.Length > 64 * 1024) return null;
        using var reader = XmlReader.Create(new StringReader(xml), new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 64 * 1024 });
        var document = XDocument.Load(reader);
        XNamespace ns = "http://schemas.microsoft.com/win/2004/08/events/event";
        var system = document.Root?.Element(ns + "System");
        if (system?.Element(ns + "EventID")?.Value != "4656" || !TryHex(system.Element(ns + "Keywords")?.Value, out var keywords)
            || (keywords & 0x0010000000000000UL) == 0) return null;
        var fields = document.Root?.Element(ns + "EventData")?.Elements(ns + "Data").ToDictionary(field => field.Attribute("Name")?.Value ?? "", field => field.Value, StringComparer.Ordinal);
        if (fields == null || !fields.TryGetValue("ObjectType", out var type) || type != "File"
            || !fields.TryGetValue("AccessMask", out var mask) || !TryHex(mask, out var access) || (access & SecurityNative.ContentAccessMask) == 0
            || !fields.TryGetValue("SubjectUserSid", out var sid) || !sid.StartsWith("S-1-", StringComparison.Ordinal)
            || !fields.TryGetValue("ObjectName", out var path) || string.IsNullOrWhiteSpace(path) || path.Length > 2048) return null;
        uint processId = 0;
        if (fields.TryGetValue("ProcessId", out var process) && TryHex(process, out var parsed) && parsed <= uint.MaxValue) processId = (uint)parsed;
        uint session = uint.MaxValue;
        if (processId != 0 && ProcessIdToSessionId(processId, out var found) && found != 0) session = found;
        return new(sid, path, processId, session);
    }
    private static bool TryHex(string? value, out ulong result) => ulong.TryParse(value?.StartsWith("0x", StringComparison.OrdinalIgnoreCase) == true ? value[2..] : value,
        NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out result);
    public void Dispose() { _watcher.Enabled = false; _watcher.EventRecordWritten -= OnRecord; _watcher.Dispose(); Healthy = false; }
    [DllImport("kernel32.dll", SetLastError = true)] private static extern bool ProcessIdToSessionId(uint process, out uint session);
}

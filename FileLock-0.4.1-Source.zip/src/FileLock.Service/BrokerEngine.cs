using System.Security.Cryptography;
using System.Security.Principal;
using FileLock.Shared;

namespace FileLock.Service;

internal sealed class BrokerEngine : IDisposable
{
    private readonly StateStore _store;
    private GateState _state;
    private readonly NativePathProtection _protection;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly Dictionary<string, LoginSession> _sessions = new(StringComparer.Ordinal);
    private readonly Dictionary<(string Id, uint Session), PendingChallenge> _pending = [];
    private readonly Dictionary<string, AccessSession> _accessSessions = new(StringComparer.Ordinal);
    private readonly Dictionary<string, DateTimeOffset> _relockRetries = new(StringComparer.Ordinal);
    private readonly CancellationTokenSource _stop = new();
    private readonly Task _expiryTask;
    private bool _uninstallPrepared;
    private sealed record LoginSession(string Sid, uint WindowsSession, DateTimeOffset ExpiresUtc);
    private sealed record AccessSession(string Token, string Sid, uint WindowsSession);

    public BrokerEngine(StateStore? store = null)
    {
        _store = store ?? new();
        _state = _store.Load();
        _protection = new(() => _store.Save(_state), (item, path) =>
            !_state.Users.SelectMany(owner => owner.Items).Any(other => other.Id != item.Id && PathPolicy.Overlaps(other.NtPath, path)));
        // Every previously granted window is closed before clients can connect.
        if (_protection.PermissionAvailable)
            foreach (var owner in _state.Users)
            foreach (var item in owner.Items)
            {
                try
                {
                    item.OwnerSid = owner.OwnerSid;
                    if (item.PermissionJournal.Count == 0) { _protection.Prepare(item); _store.Save(_state); }
                    _protection.Upsert(item);
                }
                catch (Exception error) { item.ProtectionError = error.Message; try { _store.Save(_state); } catch { } }
            }
        _expiryTask = Task.Run(ExpireWindowsAsync);
    }

    public async Task<BrokerResponse> ExecuteAsync(BrokerRequest request, CallerContext caller, CancellationToken cancellationToken)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            DrainNotifications();
            var user = _state.Users.SingleOrDefault(u => u.OwnerSid == caller.Sid);
            if (request.Operation == "Status")
            {
                var ready = _protection.Available;
                return new() { Ok = true, Status = new()
                {
                    Initialized = user != null, ProtectionAvailable = ready, SupportsAccessSessions = true, SupportsLocationRecovery = true, ServiceAvailable = true,
                    Backend = "Windows NTFS permissions", AccessWindowSeconds = NativePathProtection.AccessWindowSeconds,
                    TotalProtectedItems = _state.Users.Sum(owner => owner.Items.Count),
                    SessionAuthenticated = IsAuthenticated(request.SessionToken, caller),
                    Message = ready ? "Windows permissions protect original locations. Each FileLock open requires the location passcode; access relocks when its observed window closes."
                        : "Windows protection needs attention: " + (_protection.UnavailableReason ?? "File System or Handle Manipulation failure auditing, or its event listener, is unavailable. Existing locked permissions remain in place.")
                }};
            }
            if (request.Operation == "PrepareUninstall")
            {
                if (!new WindowsPrincipal(caller.Identity).IsInRole(WindowsBuiltInRole.Administrator))
                    throw new GateException("Uninstall preparation requires an elevated administrator.", "ADMIN_REQUIRED");
                if (_state.Users.Any(owner => owner.Items.Count != 0))
                    throw new GateException("Remove every protected item before uninstalling FileLock.", "PROTECTED_ITEMS_EXIST");
                _uninstallPrepared = true;
                return new() { Ok = true };
            }
            if (request.Operation == "Setup")
            {
                if (user != null) throw new GateException("FileLock is already configured for this Windows account.");
                PinRules.Ensure(request.Pin);
                if (_state.Users.Count >= 128) throw new GateException("This machine has reached the account limit.");
                var root = RandomNumberGenerator.GetBytes(32);
                try
                {
                    var pin = PasscodeStore.Create(request.Pin!, root);
                    var recovery = PasscodeStore.CreateRecovery(root);
                    user = new() { OwnerSid = caller.Sid, RootSecret = Convert.ToBase64String(root), MasterSalt = pin.Salt, MasterHash = pin.Hash, RecoveryEnvelope = recovery.Envelope };
                    _state.Users.Add(user);
                    _store.Save(_state);
                    return new() { Ok = true, Setup = new() { RecoveryKey = recovery.Key, SessionToken = IssueSession(caller) } };
                }
                finally { CryptographicOperations.ZeroMemory(root); }
            }
            if (request.Operation == "Resolve")
            {
                // Explorer supplies the original folder path. Only the current
                // user's own journal is consulted; no master login or list of
                // other users' protected locations is exposed by this lookup.
                var path = NormalizeRequestedPath(request.Path);
                var resolved = user?.Items.SingleOrDefault(item => MatchesOriginalPath(item, path));
                // A protected folder can be renamed through its parent while
                // locked. Reconnect only this caller's saved identities before
                // treating the new shell path as an unprotected location.
                if (resolved == null && user != null && _protection.PermissionAvailable)
                {
                    foreach (var item in user.Items)
                    {
                        try
                        {
                            if (_protection.RecoverMovedLocation(item)) ForgetItem(item.Id);
                        }
                        catch (Exception error)
                        {
                            if (item.ProtectionError == error.Message) continue;
                            item.ProtectionError = error.Message;
                            try { _store.Save(_state); } catch { }
                        }
                    }
                    resolved = user.Items.SingleOrDefault(item => MatchesOriginalPath(item, path));
                }
                return new() { Ok = true, Item = resolved == null ? null : ToItem(resolved, caller.SessionId) };
            }
            if (user == null) throw new GateException("Set up your six-digit master passcode first.", "NOT_INITIALIZED");
            switch (request.Operation)
            {
                case "SignOutSettings":
                    foreach (var token in _sessions.Where(pair => pair.Value.Sid == caller.Sid && pair.Value.WindowsSession == caller.SessionId).Select(pair => pair.Key).ToList()) _sessions.Remove(token);
                    return new() { Ok = true };
                case "Login":
                    VerifyPin(user, request.Pin, null);
                    return new() { Ok = true, SessionToken = IssueSession(caller) };
                case "Recover":
                    PinRules.Ensure(request.NewPin);
                    VerifyRecovery(user, request.RecoveryKey);
                    var secret = Convert.FromBase64String(user.RootSecret);
                    try
                    {
                        RequirePermissionsIfItems(user);
                        RevokeUser(user);
                        var newPin = PasscodeStore.Create(request.NewPin!, secret);
                        var recovery = PasscodeStore.CreateRecovery(secret);
                        user.MasterSalt = newPin.Salt; user.MasterHash = newPin.Hash;
                        user.RecoveryEnvelope = recovery.Envelope;
                        _store.Save(_state);
                        DropSessions(caller.Sid);
                        return new() { Ok = true, Setup = new() { RecoveryKey = recovery.Key, SessionToken = IssueSession(caller) } };
                    }
                    finally { CryptographicOperations.ZeroMemory(secret); }
                case "Poll":
                    DrainNotifications();
                    var delivered = _pending.Where(p => (p.Key.Session == caller.SessionId || p.Key.Session == uint.MaxValue) && user.Items.Any(i => i.Id == p.Key.Id)).Take(10).ToList();
                    foreach (var challenge in delivered) _pending.Remove(challenge.Key);
                    return new() { Ok = true, Challenges = delivered.Select(challenge => challenge.Value).ToList() };
                case "Unlock":
                    var unlock = FindItem(user, request.ItemId);
                    RequireProtection();
                    VerifyPin(user, request.Pin, unlock);
                    // A new PIN approval may follow edits made during the
                    // previous use. Capture created/replaced contents before
                    // granting a fresh session against the updated journal.
                    if (unlock.ProtectionPhase == "Open") RevokeItem(unlock);
                    _protection.Grant(unlock, caller.SessionId);
                    var accessToken = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
                    _accessSessions[unlock.Id] = new(accessToken, caller.Sid, caller.SessionId);
                    foreach (var key in _pending.Keys.Where(key => key.Id == unlock.Id).ToList()) _pending.Remove(key);
                    var approved = ToItem(unlock, caller.SessionId);
                    approved.AccessToken = accessToken;
                    return new() { Ok = true, Item = approved };
                case "RenewAccess":
                    var renewing = FindItem(user, request.ItemId);
                    RequireAccessSession(renewing, request.AccessToken, caller);
                    _protection.Renew(renewing);
                    return new() { Ok = true };
                case "CloseAccess":
                    var closing = FindItem(user, request.ItemId);
                    RequireAccessSession(closing, request.AccessToken, caller);
                    RevokeItem(closing);
                    return new() { Ok = true };
            }
            RequireSession(request.SessionToken, caller);
            switch (request.Operation)
            {
                case "List":
                    if (request.Offset < 0 || request.Offset > user.Items.Count) throw new GateException("Invalid item page.");
                    return new() { Ok = true, Items = user.Items.Skip(request.Offset).Take(10).Select(i => ToItem(i, caller.SessionId)).ToList(), HasMore = request.Offset + 10 < user.Items.Count };
                case "Add":
                    RequireProtection();
                    if (_uninstallPrepared) throw new GateException("FileLock is preparing to uninstall. Restart its service before adding items.", "UNINSTALL_PREPARED");
                    if (_state.Users.Sum(u => u.Items.Count) >= 128) throw new GateException("This prototype supports at most 128 protected paths.");
                    if (request.ItemPin != null) PinRules.Ensure(request.ItemPin);
                    var validated = WindowsIdentity.RunImpersonated(caller.Identity.AccessToken, () => PathPolicy.Validate(request.Path, request.Kind, caller.Sid));
                    if (_state.Users.SelectMany(u => u.Items).Any(i => PathPolicy.Overlaps(i.NtPath, validated.NtPath)))
                        throw new GateException("This location overlaps an existing protected file or folder.", "OVERLAPPING_PATH");
                    var added = new ItemState { Id = Guid.NewGuid().ToString("D"), Name = validated.Name, OriginalPath = validated.OriginalPath, NtPath = validated.NtPath, VolumeIdentity = validated.VolumeIdentity, OwnerSid = caller.Sid, Kind = request.Kind, AddedUtc = DateTimeOffset.UtcNow };
                    if (request.ItemPin != null) SetItemPin(user, added, request.ItemPin);
                    _protection.Prepare(added);
                    // Persist the complete descriptor journal before any ACL write.
                    user.Items.Add(added);
                    try { _store.Save(_state); }
                    catch { user.Items.Remove(added); throw; }
                    _protection.Upsert(added);
                    return new() { Ok = true, Item = ToItem(added, caller.SessionId) };
                case "Lock":
                    RequirePermissionsIfItems(user);
                    if (request.ItemId == null) RevokeUser(user);
                    else RevokeItem(FindItem(user, request.ItemId));
                    return new() { Ok = true };
                case "Logout":
                    RequirePermissionsIfItems(user);
                    RevokeUser(user);
                    DropSessions(caller.Sid);
                    return new() { Ok = true };
                case "Remove":
                    var remove = FindItem(user, request.ItemId);
                    _protection.Remove(remove);
                    user.Items.Remove(remove);
                    try { _store.Save(_state); }
                    catch
                    {
                        user.Items.Add(remove);
                        // Reapply protection when the object still exists. A
                        // deleted root can no longer be relocked; retain its
                        // journal and report the original persistence failure.
                        try { _protection.Upsert(remove); } catch { }
                        throw;
                    }
                    ForgetItem(remove.Id);
                    return new() { Ok = true };
                case "RepairLocation":
                    var repair = FindItem(user, request.ItemId);
                    _protection.RecoverLocation(repair, request.Path);
                    ForgetItem(repair.Id);
                    return new() { Ok = true, Item = ToItem(repair, caller.SessionId) };
                case "ChangePin":
                    PinRules.Ensure(request.NewPin);
                    VerifyPin(user, request.Pin, null);
                    RequirePermissionsIfItems(user);
                    RevokeUser(user);
                    var root = Convert.FromBase64String(user.RootSecret);
                    try
                    {
                        var changed = PasscodeStore.Create(request.NewPin!, root);
                        user.MasterSalt = changed.Salt; user.MasterHash = changed.Hash;
                        _store.Save(_state);
                    }
                    finally { CryptographicOperations.ZeroMemory(root); }
                    DropSessions(caller.Sid);
                    return new() { Ok = true, SessionToken = IssueSession(caller) };
                case "ChangeItemPin":
                    var change = FindItem(user, request.ItemId);
                    if (request.NewPin != null) PinRules.Ensure(request.NewPin);
                    VerifyPin(user, request.Pin, change);
                    RequireProtection();
                    RevokeItem(change);
                    SetItemPin(user, change, request.NewPin);
                    _store.Save(_state);
                    return new() { Ok = true };
                case "ResetItemPin":
                    var reset = FindItem(user, request.ItemId);
                    if (request.NewPin != null) PinRules.Ensure(request.NewPin);
                    VerifyPin(user, request.Pin, null);
                    RequireProtection();
                    RevokeItem(reset);
                    SetItemPin(user, reset, request.NewPin);
                    _store.Save(_state);
                    return new() { Ok = true };
                default:
                    throw new GateException("Unknown FileLock service operation.", "INVALID_REQUEST");
            }
        }
        catch (GateException error)
        {
            return new() { Ok = false, Error = error.Message, ErrorCode = error.Code };
        }
        catch (ArgumentException error)
        {
            // Invalid client input does not change committed policy or revoke
            // other users' active leases through an unnecessary global replay.
            return new() { Ok = false, Error = error.Message, ErrorCode = "INVALID_REQUEST" };
        }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException or System.ComponentModel.Win32Exception or CryptographicException or InvalidOperationException)
        {
            // Journals are saved before ACL writes. Reloading the last durable
            // snapshot reverses uncommitted PIN/metadata edits while retaining
            // every object whose permissions may already have changed.
            try { _state = _store.Load(); }
            catch { }
            return new() { Ok = false, Error = "This action could not be completed safely: " + error.Message, ErrorCode = "ACTION_FAILED" };
        }
        finally { _gate.Release(); }
    }

    private void RequireProtection()
    {
        if (!_protection.Available) throw new GateException("Enable Windows protection with administrator access before adding or unlocking a location. " + _protection.UnavailableReason, "PROTECTION_UNAVAILABLE");
    }
    private void RequirePermissionsIfItems(UserState user)
    {
        if (user.Items.Count != 0 && !_protection.PermissionAvailable)
            throw new GateException("Windows permission management is unavailable. " + _protection.UnavailableReason, "PROTECTION_UNAVAILABLE");
    }
    private void RevokeItem(ItemState item)
    {
        _protection.Revoke(item);
        _accessSessions.Remove(item.Id);
        _relockRetries.Remove(item.Id);
    }
    private void RevokeUser(UserState user) { foreach (var item in user.Items) RevokeItem(item); }
    private void ForgetItem(string id)
    {
        _accessSessions.Remove(id);
        _relockRetries.Remove(id);
        foreach (var key in _pending.Keys.Where(k => k.Id == id).ToList()) _pending.Remove(key);
    }
    private async Task ExpireWindowsAsync()
    {
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(1));
        try
        {
            while (await timer.WaitForNextTickAsync(_stop.Token))
            {
                await _gate.WaitAsync(_stop.Token);
                try
                {
                    foreach (var item in _state.Users.SelectMany(owner => owner.Items).Where(item => item.ActiveLeaseUntilUtc is { } until && until <= DateTimeOffset.UtcNow))
                    {
                        if (_relockRetries.TryGetValue(item.Id, out var retry) && retry > DateTimeOffset.UtcNow) continue;
                        try { RevokeItem(item); }
                        catch (Exception error)
                        {
                            _relockRetries[item.Id] = DateTimeOffset.UtcNow.AddSeconds(15);
                            var message = "Automatic relock needs attention: " + error.Message;
                            if (item.ProtectionError == message) continue;
                            item.ProtectionError = message;
                            try { _store.Save(_state); } catch { }
                        }
                    }
                    DrainNotifications();
                }
                finally { _gate.Release(); }
            }
        }
        catch (OperationCanceledException) when (_stop.IsCancellationRequested) { }
    }
    private static ItemState FindItem(UserState user, string? id) => user.Items.SingleOrDefault(i => i.Id == id) ?? throw new GateException("This protected item does not belong to your Windows account.", "ITEM_NOT_FOUND");

    private void RequireAccessSession(ItemState item, string? token, CallerContext caller)
    {
        if (item.ProtectionPhase != "Open" || item.ProtectionError != null || item.ActiveLeaseUntilUtc is not { } until || until <= DateTimeOffset.UtcNow
            || token is not { Length: 64 } || !_accessSessions.TryGetValue(item.Id, out var current)
            || current.Sid != caller.Sid || current.WindowsSession != caller.SessionId
            || !CryptographicOperations.FixedTimeEquals(System.Text.Encoding.ASCII.GetBytes(current.Token), System.Text.Encoding.ASCII.GetBytes(token)))
            throw new GateException("This access session has closed. Enter the location passcode again.", "ACCESS_SESSION_EXPIRED");
    }

    private ProtectedItem ToItem(ItemState item, uint session)
    {
        var isOpen = item.ProtectionPhase == "Open" && item.ProtectionError == null && item.ActiveLeaseUntilUtc is { } until && until > DateTimeOffset.UtcNow;
        return new() { Id = item.Id, Name = item.Name, OriginalPath = item.OriginalPath, Kind = item.Kind, UsesSharedPin = item.PinHash == null, AddedUtc = item.AddedUtc, IsOpen = isOpen, UnlockedUntilUtc = isOpen ? item.ActiveLeaseUntilUtc : null, ProtectionState = item.ProtectionPhase, ProtectionError = item.ProtectionError };
    }
    private string IssueSession(CallerContext caller)
    {
        foreach (var token in _sessions.Where(p => p.Value.ExpiresUtc <= DateTimeOffset.UtcNow).Select(p => p.Key).ToList()) _sessions.Remove(token);
        // One management token per account/session also bounds a malicious
        // authenticated local client's repeated-login memory consumption.
        foreach (var token in _sessions.Where(p => p.Value.Sid == caller.Sid && p.Value.WindowsSession == caller.SessionId).Select(p => p.Key).ToList()) _sessions.Remove(token);
        var tokenText = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
        _sessions[tokenText] = new(caller.Sid, caller.SessionId, DateTimeOffset.UtcNow.AddMinutes(10));
        return tokenText;
    }
    private bool IsAuthenticated(string? token, CallerContext caller) => token != null && _sessions.TryGetValue(token, out var session) && session.Sid == caller.Sid && session.WindowsSession == caller.SessionId && session.ExpiresUtc > DateTimeOffset.UtcNow;
    private void RequireSession(string? token, CallerContext caller)
    {
        if (!IsAuthenticated(token, caller)) throw new GateException("Enter your master passcode to manage protected items. Management sessions expire after 10 minutes.", "SESSION_EXPIRED");
    }
    private void DropSessions(string sid) { foreach (var token in _sessions.Where(s => s.Value.Sid == sid).Select(s => s.Key).ToList()) _sessions.Remove(token); }

    private void VerifyPin(UserState user, string? pin, ItemState? item)
    {
        CheckThrottle(user);
        var root = Convert.FromBase64String(user.RootSecret);
        bool valid;
        try { valid = pin != null && PasscodeStore.Verify(pin, item?.PinSalt ?? user.MasterSalt, item?.PinHash ?? user.MasterHash, root); }
        finally { CryptographicOperations.ZeroMemory(root); }
        RecordAttempt(user, valid);
        if (!valid) throw new GateException("Incorrect six-digit passcode.", "INVALID_PIN");
    }
    private void VerifyRecovery(UserState user, string? key)
    {
        CheckThrottle(user);
        var root = Convert.FromBase64String(user.RootSecret);
        bool valid;
        try { valid = PasscodeStore.VerifyRecovery(key, user.RecoveryEnvelope, root); }
        finally { CryptographicOperations.ZeroMemory(root); }
        RecordAttempt(user, valid);
        if (!valid) throw new GateException("The recovery key is incorrect.", "INVALID_RECOVERY");
    }
    private static void CheckThrottle(UserState user)
    {
        if (user.RetryAfterUtc is { } retry && retry > DateTimeOffset.UtcNow)
            throw new GateException($"Too many attempts. Try again in {Math.Max(1, (int)Math.Ceiling((retry - DateTimeOffset.UtcNow).TotalSeconds))} seconds.", "RATE_LIMITED");
    }
    private void RecordAttempt(UserState user, bool success)
    {
        if (success)
        {
            if (user.FailedAttempts == 0 && user.RetryAfterUtc == null) return;
            user.FailedAttempts = 0; user.RetryAfterUtc = null;
        }
        else
        {
            user.FailedAttempts = Math.Min(30, user.FailedAttempts + 1);
            if (user.FailedAttempts >= 5)
                user.RetryAfterUtc = DateTimeOffset.UtcNow.AddSeconds(Math.Min(3600, 30 * Math.Pow(2, user.FailedAttempts - 5)));
        }
        _store.Save(_state);
    }
    private static void SetItemPin(UserState user, ItemState item, string? pin)
    {
        if (pin == null) { item.PinHash = null; item.PinSalt = null; return; }
        var root = Convert.FromBase64String(user.RootSecret);
        try { var value = PasscodeStore.Create(pin, root); item.PinSalt = value.Salt; item.PinHash = value.Hash; }
        finally { CryptographicOperations.ZeroMemory(root); }
    }
    private void DrainNotifications()
    {
        while (_protection.Notifications.TryDequeue(out var notification))
        {
            var user = _state.Users.SingleOrDefault(owner => owner.OwnerSid == notification.OwnerSid);
            var item = user?.Items.SingleOrDefault(candidate => MatchesAuditPath(candidate, notification.Path));
            if (item == null || item.ProtectionPhase == "Open") continue;
            var id = item.Id;
            var key = (id, notification.SessionId);
            if (!_pending.ContainsKey(key) && _pending.Count < 1024)
                _pending[key] = new() { Id = Guid.NewGuid().ToString("D"), ItemId = item.Id, Name = item.Name, OriginalPath = item.OriginalPath, Kind = item.Kind, ProcessId = notification.ProcessId, RequestedUtc = DateTimeOffset.UtcNow };
        }
        foreach (var key in _pending.Where(p => p.Value.RequestedUtc < DateTimeOffset.UtcNow.AddMinutes(-2)).Select(p => p.Key).ToList()) _pending.Remove(key);
    }
    private static bool MatchesAuditPath(ItemState item, string path)
    {
        if (path.StartsWith(@"\\?\", StringComparison.Ordinal)) path = path[4..];
        foreach (var root in new[] { item.OriginalPath, item.NtPath })
            if (path.Equals(root, StringComparison.OrdinalIgnoreCase) || (item.Kind == ProtectionKind.Folder && path.StartsWith(root.TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase))) return true;
        return false;
    }
    internal static string NormalizeRequestedPath(string? path)
    {
        if (string.IsNullOrWhiteSpace(path) || path.Length > 2048 || !Path.IsPathFullyQualified(path)
            || path.Contains('"') || path.StartsWith(@"\\?\", StringComparison.Ordinal) || path.StartsWith(@"\\.\", StringComparison.Ordinal))
            throw new GateException("Choose an absolute Windows folder path.", "INVALID_PATH");
        var full = Path.GetFullPath(path);
        return Path.TrimEndingDirectorySeparator(full);
    }
    internal static bool MatchesOriginalPath(ItemState item, string path)
    {
        if (path.Equals(item.OriginalPath, StringComparison.OrdinalIgnoreCase)) return true;
        if (item.Kind != ProtectionKind.Folder || !path.StartsWith(item.OriginalPath.TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase)) return false;
        // A textual prefix alone must not resolve a sibling or an unjournaled
        // alias. Match a concrete descendant already verified by the service.
        var relative = Path.GetRelativePath(item.OriginalPath, path);
        return item.PermissionJournal.Any(entry => entry.RelativePath.Equals(relative, StringComparison.OrdinalIgnoreCase));
    }
    public void Dispose()
    {
        _stop.Cancel();
        try { _expiryTask.GetAwaiter().GetResult(); } catch (OperationCanceledException) { }
        _protection.Dispose(); _stop.Dispose(); _gate.Dispose();
    }
}

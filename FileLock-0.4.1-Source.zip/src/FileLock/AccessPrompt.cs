using System.Windows;
using System.IO;
using FileLock.Shared;

namespace FileLock;

internal static class AccessPrompt
{
    internal static bool Show(Window? owner, string name, Func<string, Task<ProtectedItem>> unlock, Action<ProtectedItem> open)
    {
        ProtectedItem? granted = null;
        var dialog = new PinDialog(owner, "Unlock this location",
            $"{name}\nEnter its 6-digit passcode. Access locks again when its window closes.",
            "Unlock & open", verify: async pin =>
            {
                var result = await unlock(pin);
                if (!result.IsOpen || result.UnlockedUntilUtc is not { } until || until <= DateTimeOffset.UtcNow)
                    throw new GateException("Windows could not unlock this location. Try again.");
                granted = result;
            });
        if (dialog.ShowDialog() != true || granted is null) return false;
        open(granted);
        return true;
    }

    internal static string ValidateRequestedPath(ProtectedItem granted, string requestedPath)
    {
        var requested = DesktopActivation.NormalizeOpenPath(requestedPath);
        var root = DesktopActivation.NormalizeOpenPath(granted.OriginalPath);
        if (!requested.Equals(root, StringComparison.OrdinalIgnoreCase)
            && !requested.StartsWith(root.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new IOException("The requested folder is outside the approved protected location.");
        return requested;
    }

    internal static string RebaseRequestedPath(ProtectedItem granted, string requestedPath, string previousRoot)
    {
        if (granted.Kind != ProtectionKind.Folder) throw new IOException("Only folder requests can be rebased.");
        // A rename can be discovered while the PIN dialog is open. Preserve a
        // requested descendant, but first prove it belonged to the cached root.
        var previous = new ProtectedItem { OriginalPath = previousRoot, Kind = ProtectionKind.Folder };
        var requested = ValidateRequestedPath(previous, requestedPath);
        var oldRoot = DesktopActivation.NormalizeOpenPath(previousRoot);
        var relative = Path.GetRelativePath(oldRoot, requested);
        if (Path.IsPathRooted(relative) || relative == ".." || relative.StartsWith(".." + Path.DirectorySeparatorChar, StringComparison.Ordinal))
            throw new IOException("The requested folder is outside the previous protected location.");
        var newRoot = DesktopActivation.NormalizeOpenPath(granted.OriginalPath);
        return ValidateRequestedPath(granted, Path.Combine(newRoot, relative));
    }
}

internal sealed class AccessChallengeQueue
{
    private readonly Queue<PendingChallenge> _pending = [];
    private readonly HashSet<string> _seen = [];

    internal void Add(IEnumerable<PendingChallenge> challenges)
    {
        foreach (var challenge in challenges)
        {
            if (!_seen.Add(challenge.Id)) continue;
            if (_seen.Count > 2000) { _seen.Clear(); _seen.Add(challenge.Id); }
            if (!_pending.Any(pending => pending.ItemId == challenge.ItemId)) _pending.Enqueue(challenge);
        }
    }

    internal PendingChallenge? TakeNext()
    {
        while (_pending.TryDequeue(out var next))
            if (next.RequestedUtc >= DateTimeOffset.UtcNow.AddMinutes(-2)) return next;
        return null;
    }

    internal void RemoveItem(string itemId)
    {
        var keep = _pending.Where(challenge => challenge.ItemId != itemId).ToArray();
        _pending.Clear();
        foreach (var challenge in keep) _pending.Enqueue(challenge);
    }
}

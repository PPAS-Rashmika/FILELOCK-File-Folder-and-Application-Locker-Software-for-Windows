using System.IO;
using System.Text.Json;
using FileLock.Shared;

namespace FileLock;

internal sealed class DesktopActivation
{
    internal const int MaximumMessageBytes = 8192;
    public string Operation { get; set; } = "show";
    public string? Path { get; set; }

    internal static string NormalizeOpenPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || path.Length > 2048 || !System.IO.Path.IsPathFullyQualified(path)
            || path.Any(character => character < 32 || character is '"' or '<' or '>' or '|')
            || path.StartsWith(@"\\?\", StringComparison.Ordinal) || path.StartsWith(@"\\.\", StringComparison.Ordinal))
            throw new ArgumentException("Choose an absolute Windows folder path.");
        return System.IO.Path.TrimEndingDirectorySeparator(System.IO.Path.GetFullPath(path));
    }

    internal static async Task WriteAsync(Stream stream, DesktopActivation message, CancellationToken token)
    {
        var data = JsonSerializer.SerializeToUtf8Bytes(message, BrokerProtocol.JsonOptions);
        if (data.Length >= MaximumMessageBytes) throw new IOException("The folder request is too long.");
        await stream.WriteAsync(data, token);
        await stream.WriteAsync(new byte[] { (byte)'\n' }, token);
        await stream.FlushAsync(token);
    }

    internal static async Task<DesktopActivation> ReadAsync(Stream stream, CancellationToken token)
    {
        using var message = new MemoryStream();
        var next = new byte[1];
        while (message.Length < MaximumMessageBytes)
        {
            if (await stream.ReadAsync(next, token) != 1) throw new IOException("The folder request is incomplete.");
            if (next[0] != '\n') { message.WriteByte(next[0]); continue; }
            var value = JsonSerializer.Deserialize<DesktopActivation>(message.ToArray(), BrokerProtocol.JsonOptions)
                ?? throw new IOException("The folder request is invalid.");
            if (value.Operation == "open" && value.Path is { } path) value.Path = NormalizeOpenPath(path);
            else if (value.Operation != "show" || value.Path is not null) throw new IOException("The folder request is invalid.");
            return value;
        }
        throw new IOException("The folder request is too long.");
    }
}

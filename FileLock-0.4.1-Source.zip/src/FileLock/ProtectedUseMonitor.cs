using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using FileLock.Shared;

namespace FileLock;

internal enum ProtectedUseStatus { Starting, InUse, Closed, Unobservable }
internal enum UseObservation { Present, Absent, ConfirmedClosed, Unavailable }

// Observation errors never count as evidence that access is still needed. The
// broker's short heartbeat deadline closes access if the desktop cannot observe it.
internal sealed class ProtectedUseLifetime
{
    internal static readonly TimeSpan LaunchGrace = TimeSpan.FromSeconds(10);
    internal static readonly TimeSpan CloseStabilization = TimeSpan.FromSeconds(2);
    private readonly DateTimeOffset _started;
    private bool _seen;
    private bool _closed;
    private DateTimeOffset? _absentSince;

    internal ProtectedUseLifetime(DateTimeOffset started) => _started = started;

    internal ProtectedUseStatus Evaluate(UseObservation observation, DateTimeOffset now)
    {
        if (_closed) return ProtectedUseStatus.Closed;
        if (observation == UseObservation.ConfirmedClosed)
        { _closed = true; return ProtectedUseStatus.Closed; }
        if (observation == UseObservation.Present)
        { _seen = true; _absentSince = null; return ProtectedUseStatus.InUse; }
        if (observation == UseObservation.Unavailable)
            return ProtectedUseStatus.Unobservable;
        if (!_seen)
        {
            if (now - _started < LaunchGrace) return ProtectedUseStatus.Starting;
            _closed = true; return ProtectedUseStatus.Closed;
        }
        _absentSince ??= now;
        if (now - _absentSince.Value < CloseStabilization) return ProtectedUseStatus.InUse;
        _closed = true; return ProtectedUseStatus.Closed;
    }
}

// This observes ordinary Explorer views and viewer/application windows; it is
// not a generic document-close API. Files shown without an identifiable title,
// or tabs not exposed by the viewer, get a bounded launch grace and then relock.
internal sealed class ProtectedUseMonitor : IDisposable
{
    private readonly ProtectionKind _kind;
    private readonly string _path;
    private readonly ProtectedUseLifetime _lifetime;
    private readonly Dictionary<nint, NativeWindow> _beforeLaunch;
    private Process? _process;
    private int? _processId;
    private DateTime? _processStartedUtc;
    private bool _disposed;

    internal ProtectedUseMonitor(ProtectionKind kind, string path)
    {
        _kind = kind;
        _path = DesktopActivation.NormalizeOpenPath(path);
        _lifetime = new(DateTimeOffset.UtcNow);
        _beforeLaunch = kind == ProtectionKind.File ? NativeWindow.Read().ToDictionary(w => w.Handle) : [];
    }

    internal void ObserveLaunch(Process? process)
    {
        _process?.Dispose(); _process = process;
        _processId = null; _processStartedUtc = null;
        if (process == null) return;
        try { _processId = process.Id; _processStartedUtc = process.StartTime.ToUniversalTime(); }
        catch (Exception error) when (error is InvalidOperationException or System.ComponentModel.Win32Exception)
        { }
    }

    internal ProtectedUseStatus Evaluate(DateTimeOffset now)
    {
        if (_disposed) return ProtectedUseStatus.Closed;
        UseObservation observation;
        try
        {
            observation = _kind switch
            {
                ProtectionKind.Folder => ObserveFolder(),
                ProtectionKind.Application => ObserveApplication(),
                _ => ObserveFile()
            };
        }
        catch (Exception error) when (error is COMException or InvalidComObjectException
            or InvalidOperationException or System.ComponentModel.Win32Exception
            or Microsoft.CSharp.RuntimeBinder.RuntimeBinderException or ArgumentException)
        { observation = UseObservation.Unavailable; }
        return _lifetime.Evaluate(observation, now);
    }

    private UseObservation ObserveApplication()
    {
        if (_process is null || _processId is null || _processStartedUtc is null)
            return UseObservation.Unavailable;
        if (!IsSameProcessRunning()) return UseObservation.ConfirmedClosed;
        return NativeWindow.Read().Any(window => window.ProcessId == _processId)
            ? UseObservation.Present : UseObservation.Absent;
    }

    private UseObservation ObserveFile()
    {
        // A shell document launch may return no process, or a short-lived launcher
        // that hands the document to an existing viewer. Match a viewer window
        // rather than keeping permissions open for that viewer's whole process.
        var sameProcess = _process != null && _processId != null && _processStartedUtc != null && IsSameProcessRunning();
        foreach (var window in NativeWindow.Read())
        {
            if (!TitleMatchesFile(window.Title, _path)) continue;
            if (sameProcess && window.ProcessId == _processId) return UseObservation.Present;
            // Ignore an unrelated pre-existing same-title window. A reused viewer
            // is accepted when its title changes to the requested document.
            if (!_beforeLaunch.TryGetValue(window.Handle, out var previous)
                || previous.ProcessId != window.ProcessId
                || !previous.Title.Equals(window.Title, StringComparison.Ordinal))
                return UseObservation.Present;
        }
        return UseObservation.Absent;
    }

    private bool IsSameProcessRunning()
    {
        return _process is { HasExited: false }
            && _process.Id == _processId
            && _process.StartTime.ToUniversalTime() == _processStartedUtc;
    }

    private UseObservation ObserveFolder()
    {
        if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA)
            return UseObservation.Unavailable;
        object? shell = null, windows = null;
        var incomplete = false;
        try
        {
            var type = Type.GetTypeFromProgID("Shell.Application");
            if (type == null) return UseObservation.Unavailable;
            shell = Activator.CreateInstance(type);
            if (shell == null) return UseObservation.Unavailable;
            windows = ((dynamic)shell).Windows();
            var count = (int)((dynamic)windows).Count;
            for (var index = 0; index < count; index++)
            {
                object? window = null, document = null, folder = null, self = null;
                try
                {
                    window = ((dynamic)windows).Item(index);
                    if (window == null) continue;
                    var executable = (string)((dynamic)window).FullName;
                    if (!Path.GetFileName(executable).Equals("explorer.exe", StringComparison.OrdinalIgnoreCase)) continue;
                    document = ((dynamic)window).Document;
                    folder = ((dynamic)document).Folder;
                    self = ((dynamic)folder).Self;
                    var viewedPath = (string)((dynamic)self).Path;
                    if (MatchesFolder(_path, viewedPath)) return UseObservation.Present;
                }
                catch (Exception error) when (error is COMException or InvalidComObjectException
                    or Microsoft.CSharp.RuntimeBinder.RuntimeBinderException)
                { incomplete = true; }
                finally { Release(self); Release(folder); Release(document); Release(window); }
            }
            return incomplete ? UseObservation.Unavailable : UseObservation.Absent;
        }
        finally { Release(windows); Release(shell); }
    }

    internal static bool MatchesFolder(string root, string viewedPath)
    {
        try
        {
            if (!Path.IsPathFullyQualified(viewedPath)) return false;
            root = Path.TrimEndingDirectorySeparator(Path.GetFullPath(root));
            viewedPath = Path.TrimEndingDirectorySeparator(Path.GetFullPath(viewedPath));
            return viewedPath.Equals(root, StringComparison.OrdinalIgnoreCase)
                || viewedPath.StartsWith(root.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar,
                    StringComparison.OrdinalIgnoreCase);
        }
        catch (Exception error) when (error is ArgumentException or NotSupportedException or PathTooLongException)
        { return false; }
    }

    internal static bool TitleMatchesFile(string title, string path)
    {
        var fileName = Path.GetFileName(path);
        if (ContainsName(title, fileName)) return true;
        var stem = Path.GetFileNameWithoutExtension(path);
        // One-letter/stub names would match many unrelated viewer captions.
        return stem.Length >= 4 && ContainsName(title, stem, stemOnly: true);
    }

    private static bool ContainsName(string title, string name, bool stemOnly = false)
    {
        if (string.IsNullOrWhiteSpace(name)) return false;
        var offset = 0;
        while (offset < title.Length)
        {
            var index = title.IndexOf(name, offset, StringComparison.OrdinalIgnoreCase);
            if (index < 0) return false;
            var end = index + name.Length;
            if ((index == 0 || !IsNameCharacter(title[index - 1]))
                && (end == title.Length || (!IsNameCharacter(title[end]) && (!stemOnly || title[end] != '.')))) return true;
            offset = end;
        }
        return false;
    }

    private static bool IsNameCharacter(char value) => char.IsLetterOrDigit(value) || value == '_';

    private static void Release(object? value)
    {
        if (value != null && Marshal.IsComObject(value)) Marshal.ReleaseComObject(value);
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true; _process?.Dispose(); _process = null;
    }

    private sealed record NativeWindow(nint Handle, int ProcessId, string Title)
    {
        internal static List<NativeWindow> Read()
        {
            var result = new List<NativeWindow>();
            if (!EnumWindows((handle, parameter) =>
            {
                if (!IsWindowVisible(handle)) return true;
                _ = GetWindowThreadProcessId(handle, out var pid);
                var text = new StringBuilder(1024);
                _ = GetWindowText(handle, text, text.Capacity);
                result.Add(new(handle, unchecked((int)pid), text.ToString()));
                return true;
            }, 0)) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            return result;
        }

        private delegate bool EnumWindowCallback(nint handle, nint parameter);
        [DllImport("user32.dll", SetLastError = true)] private static extern bool EnumWindows(EnumWindowCallback callback, nint parameter);
        [DllImport("user32.dll")] private static extern bool IsWindowVisible(nint handle);
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(nint handle, out uint processId);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetWindowText(nint handle, StringBuilder title, int maximum);
    }
}

using System.Diagnostics;
using System.Windows.Threading;
using FileLock.Shared;

namespace FileLock;

public partial class MainWindow
{
    private readonly DispatcherTimer _useTimer = new() { Interval = TimeSpan.FromSeconds(1) };
    private readonly Dictionary<string, WatchedAccess> _activeUses = new(StringComparer.Ordinal);
    private bool _watchingUses;
    private sealed class WatchedAccess(string token)
    {
        internal string Token = token;
        internal readonly List<ProtectedUseMonitor> Monitors = [];
        internal DateTimeOffset LastRenewed = DateTimeOffset.UtcNow;
    }

    private void StartAccessMonitoring()
    {
        _useTimer.Tick += async (_, _) => await MaintainAccessAsync();
        _useTimer.Start();
    }

    private void StartProtectedUse(ProtectedItem granted, string requestedPath)
    {
        if (_exiting) throw new InvalidOperationException("FileLock is exiting. Open it again before accessing this location.");
        if (granted.AccessToken is not { Length: 64 })
            throw new GateException("Install the matching FileLock service before opening this location.", "UPGRADE_REQUIRED");
        var path = granted.Kind == ProtectionKind.Folder ? AccessPrompt.ValidateRequestedPath(granted, requestedPath) : granted.OriginalPath;
        var monitor = new ProtectedUseMonitor(granted.Kind, granted.OriginalPath);
        try
        {
            var launched = granted.Kind == ProtectionKind.Folder ? OpenFolder(path)
                : Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            monitor.ObserveLaunch(launched);
            if (!_activeUses.TryGetValue(granted.Id, out var watched))
                _activeUses[granted.Id] = watched = new(granted.AccessToken);
            // A fresh PIN rotates the service token. Existing observed uses of
            // the same item remain relevant, but can never close a newer token.
            watched.Token = granted.AccessToken;
            watched.LastRenewed = DateTimeOffset.UtcNow;
            if (granted.Kind == ProtectionKind.Folder)
            {
                // One root observer covers every open Explorer view of this
                // folder, including an opening requested at a nested path.
                foreach (var previous in watched.Monitors) previous.Dispose();
                watched.Monitors.Clear();
            }
            watched.Monitors.Add(monitor);
        }
        catch { monitor.Dispose(); throw; }
    }

    private async Task MaintainAccessAsync()
    {
        // Independent of modal PIN dialogs: an already-open document must keep
        // its heartbeat while the user authenticates another location/manager.
        if (_watchingUses || _preview || _exiting) return;
        _watchingUses = true;
        try
        {
            foreach (var pair in _activeUses.ToArray())
            {
                var watched = pair.Value;
                var now = DateTimeOffset.UtcNow;
                var active = false;
                foreach (var monitor in watched.Monitors.ToArray())
                {
                    var state = monitor.Evaluate(now);
                    if (state == ProtectedUseStatus.Closed)
                    { watched.Monitors.Remove(monitor); monitor.Dispose(); }
                    else if (state is ProtectedUseStatus.Starting or ProtectedUseStatus.InUse) active = true;
                }
                if (watched.Monitors.Count == 0 || (!active && now - watched.LastRenewed >= TimeSpan.FromSeconds(15)))
                {
                    var token = watched.Token;
                    try { await _client.CloseAccessAsync(pair.Key, token); }
                    catch (GateException error) when (error.Code is "ACCESS_SESSION_EXPIRED" or "ITEM_NOT_FOUND" or "SERVICE_UNAVAILABLE") { }
                    if (watched.Token == token) RemoveWatchedAccess(pair.Key, watched);
                    if (IsVisible) await RefreshAsync();
                }
                else if (active && now - watched.LastRenewed >= TimeSpan.FromSeconds(3))
                {
                    var token = watched.Token;
                    try
                    {
                        await _client.RenewAccessAsync(pair.Key, token);
                        if (watched.Token == token)
                        {
                            watched.LastRenewed = DateTimeOffset.UtcNow;
                            var item = _items.SingleOrDefault(item => item.Id == pair.Key);
                            if (item != null) item.UnlockedUntilUtc = watched.LastRenewed.AddSeconds(15);
                        }
                    }
                    catch (GateException error) when (error.Code is "ACCESS_SESSION_EXPIRED" or "ITEM_NOT_FOUND")
                    { if (watched.Token == token) RemoveWatchedAccess(pair.Key, watched); }
                    catch (GateException) { /* No heartbeat evidence: the service closes its deadline. */ }
                }
            }
        }
        catch (Exception error) { SetStatus("Automatic locking needs attention: " + error.Message, warning: true); }
        finally { _watchingUses = false; }
    }

    private void RemoveWatchedAccess(string id, WatchedAccess expected)
    {
        if (!_activeUses.TryGetValue(id, out var current) || !ReferenceEquals(current, expected)) return;
        _activeUses.Remove(id);
        foreach (var monitor in current.Monitors) monitor.Dispose();
        current.Monitors.Clear();
    }

    private async Task EndAllAccessAsync()
    {
        foreach (var pair in _activeUses.ToArray())
        {
            try { await _client.CloseAccessAsync(pair.Key, pair.Value.Token); } catch { }
            RemoveWatchedAccess(pair.Key, pair.Value);
        }
    }
}

using FileLock;
using FileLock.Shared;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;

internal static class ProtectedUseTests
{
    internal static int Run()
    {
        var passed = 0;
        var now = DateTimeOffset.UtcNow;
        var launching = new ProtectedUseLifetime(now);
        Check(launching.Evaluate(UseObservation.Absent, now.AddSeconds(9)) == ProtectedUseStatus.Starting,
            "A slow launch gets a bounded observation grace");
        Check(launching.Evaluate(UseObservation.Absent, now.AddSeconds(10)) == ProtectedUseStatus.Closed,
            "An unidentifiable viewer cannot leave permissions open after launch grace");
        Check(launching.Evaluate(UseObservation.Present, now.AddSeconds(11)) == ProtectedUseStatus.Closed,
            "A closed access generation cannot restart from a late window");

        var active = new ProtectedUseLifetime(now);
        Check(active.Evaluate(UseObservation.Present, now) == ProtectedUseStatus.InUse,
            "An observed folder or viewer retains access while in use");
        Check(active.Evaluate(UseObservation.Absent, now.AddSeconds(1)) == ProtectedUseStatus.InUse
            && active.Evaluate(UseObservation.Present, now.AddSeconds(2)) == ProtectedUseStatus.InUse,
            "A momentary window transition does not prematurely close the item");
        Check(active.Evaluate(UseObservation.Absent, now.AddSeconds(3)) == ProtectedUseStatus.InUse
            && active.Evaluate(UseObservation.Absent, now.AddSeconds(5)) == ProtectedUseStatus.Closed,
            "Closing the final view requests relock after two seconds");

        var uncertain = new ProtectedUseLifetime(now);
        _ = uncertain.Evaluate(UseObservation.Present, now);
        Check(uncertain.Evaluate(UseObservation.Unavailable, now.AddSeconds(1)) == ProtectedUseStatus.Unobservable,
            "Observer failure supplies no heartbeat evidence");
        Check(new ProtectedUseLifetime(now).Evaluate(UseObservation.ConfirmedClosed, now) == ProtectedUseStatus.Closed,
            "Actual application exit closes access immediately during launch grace");

        Check(ProtectedUseMonitor.MatchesFolder(@"C:\private", @"c:\PRIVATE\nested")
            && ProtectedUseMonitor.MatchesFolder(@"C:\private\", @"C:\private"),
            "Folder views include the original root and its descendants");
        Check(!ProtectedUseMonitor.MatchesFolder(@"C:\private", @"C:\private-other")
            && !ProtectedUseMonitor.MatchesFolder(@"C:\private", @"C:\private\..\outside")
            && !ProtectedUseMonitor.MatchesFolder(@"C:\private", "shell:Home"),
            "Sibling, traversal and virtual views do not prolong folder access");
        Check(ProtectedUseMonitor.TitleMatchesFile("Report.pdf - Viewer", @"C:\private\Report.pdf")
            && ProtectedUseMonitor.TitleMatchesFile("Report - Viewer", @"C:\private\Report.pdf"),
            "Viewer captions can identify full document names or ordinary extensionless names");
        Check(!ProtectedUseMonitor.TitleMatchesFile("AnotherReport.pdf - Viewer", @"C:\private\Report.pdf")
            && !ProtectedUseMonitor.TitleMatchesFile("Other_Report.pdf - Viewer", @"C:\private\Report.pdf")
            && !ProtectedUseMonitor.TitleMatchesFile("Report.docx - Viewer", @"C:\private\Report.pdf")
            && !ProtectedUseMonitor.TitleMatchesFile("Viewer application", @"C:\private\a.txt"),
            "Unrelated and ambiguous short captions do not prolong file access");
        TestNativeApplication();
        TestNativeFileViewer();
        if (Environment.GetEnvironmentVariable("FILELOCK_TEST_EXPLORER") == "1") TestNativeFolderExplorer();
        return passed;

        void TestNativeApplication()
        {
            var fixture = new Window { Title = "FileLock disposable application observer", Width = 320, Height = 160 };
            using var monitor = new ProtectedUseMonitor(ProtectionKind.Application, Environment.ProcessPath!);
            var process = Process.GetCurrentProcess();
            monitor.ObserveLaunch(process);
            try
            {
                fixture.Show();
                var observed = DateTimeOffset.UtcNow;
                Check(monitor.Evaluate(observed) == ProtectedUseStatus.InUse,
                    "The native observer sees an actual application window");
                fixture.Hide();
                Check(!process.HasExited,
                    "Hiding the last application window leaves its resident process running");
                Check(monitor.Evaluate(observed.AddSeconds(1)) == ProtectedUseStatus.InUse
                    && monitor.Evaluate(observed.AddSeconds(3)) == ProtectedUseStatus.Closed,
                    "The native observer closes access after the last window disappears without requiring process exit");
            }
            finally { fixture.Close(); }
        }

        void TestNativeFileViewer()
        {
            var fileName = "FileLock-observer-" + Guid.NewGuid().ToString("N") + ".txt";
            var filePath = Path.Combine(Path.GetTempPath(), fileName);
            var fixture = new Window { Title = fileName + " - Disposable viewer", Width = 320, Height = 160 };
            try
            {
                using (var monitor = new ProtectedUseMonitor(ProtectionKind.File, filePath))
                {
                    // ShellExecute can reuse an existing viewer and return no
                    // Process. Its actual window remains observable in that case.
                    monitor.ObserveLaunch(null);
                    fixture.Show();
                    var observed = DateTimeOffset.UtcNow;
                    Check(monitor.Evaluate(observed) == ProtectedUseStatus.InUse,
                        "The native observer sees a real document caption when the shell supplies no process");
                    fixture.Title = "Different document - Disposable viewer";
                    Check(monitor.Evaluate(observed.AddSeconds(1)) == ProtectedUseStatus.InUse
                        && monitor.Evaluate(observed.AddSeconds(3)) == ProtectedUseStatus.Closed,
                        "Changing a reused viewer to another document closes the protected document's access");
                }
                using (var reused = new ProtectedUseMonitor(ProtectionKind.File, filePath))
                {
                    reused.ObserveLaunch(null);
                    fixture.Title = fileName + " - Disposable viewer";
                    var observed = DateTimeOffset.UtcNow;
                    Check(reused.Evaluate(observed) == ProtectedUseStatus.InUse,
                        "A pre-existing viewer whose caption changes to the requested document is observed");
                    fixture.Close();
                    Check(reused.Evaluate(observed.AddSeconds(1)) == ProtectedUseStatus.InUse
                        && reused.Evaluate(observed.AddSeconds(3)) == ProtectedUseStatus.Closed,
                        "Closing the native viewer window requests automatic relock");
                }
            }
            finally { if (fixture.IsVisible) fixture.Close(); }
        }

        void TestNativeFolderExplorer()
        {
            // Opt in on an interactive Windows desktop. Hosted CI runners may
            // have no Explorer shell, and must still run the pure/UI checks.
            var fixture = Path.Combine(AppContext.BaseDirectory, "use-folder-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(fixture);
            var before = ReadExplorerViews().Select(view => view.Handle).ToHashSet();
            nint ownedWindow = 0;
            try
            {
                using var monitor = new ProtectedUseMonitor(ProtectionKind.Folder, fixture);
                using var launched = Process.Start(new ProcessStartInfo(fixture) { UseShellExecute = true, Verb = "explore" });
                var deadline = DateTimeOffset.UtcNow.AddSeconds(15);
                while (DateTimeOffset.UtcNow < deadline)
                {
                    var own = ReadExplorerViews().FirstOrDefault(view => view.Path.Equals(fixture, StringComparison.OrdinalIgnoreCase)
                        && !before.Contains(view.Handle));
                    if (own.Handle != 0) { ownedWindow = own.Handle; break; }
                    Thread.Sleep(100);
                }
                Check(ownedWindow != 0,
                    "The interactive folder test owns a newly created Explorer window");
                var observed = DateTimeOffset.UtcNow;
                Check(monitor.Evaluate(observed) == ProtectedUseStatus.InUse,
                    "The native COM observer sees the real Explorer folder view");
                Check(CloseOwnedExplorer(ownedWindow, fixture, before),
                    "The folder test closes only its own new Explorer fixture window");
                deadline = DateTimeOffset.UtcNow.AddSeconds(5);
                while (DateTimeOffset.UtcNow < deadline && ReadExplorerViews().Any(view => view.Handle == ownedWindow))
                    Thread.Sleep(100);
                Check(!ReadExplorerViews().Any(view => view.Handle == ownedWindow),
                    "The fixture Explorer window actually disappears from the shell collection");
                observed = DateTimeOffset.UtcNow;
                Check(monitor.Evaluate(observed) == ProtectedUseStatus.InUse
                    && monitor.Evaluate(observed.AddSeconds(2)) == ProtectedUseStatus.Closed,
                    "Closing the actual Explorer view requests automatic folder relock");
            }
            finally
            {
                if (ownedWindow != 0) _ = CloseOwnedExplorer(ownedWindow, fixture, before);
                // The fixture is empty; never recursively remove a generated path.
                try { Directory.Delete(fixture); } catch (IOException) { }
            }
        }

        void Check(bool value, string message)
        {
            if (!value) throw new InvalidOperationException(message);
            passed++; Console.WriteLine("PASS " + message);
        }
    }

    private static List<(nint Handle, string Path)> ReadExplorerViews()
    {
        var result = new List<(nint, string)>();
        object? shell = null, windows = null;
        try
        {
            shell = Activator.CreateInstance(Type.GetTypeFromProgID("Shell.Application")
                ?? throw new InvalidOperationException("Explorer automation is unavailable."));
            windows = ((dynamic)shell!).Windows();
            var count = (int)((dynamic)windows).Count;
            for (var index = 0; index < count; index++)
            {
                object? window = null, document = null, folder = null, self = null;
                try
                {
                    window = ((dynamic)windows).Item(index);
                    if (window == null) continue;
                    var executable = (string)((dynamic)window).FullName;
                    if (!Path.GetFileName(executable).Equals("explorer.exe", StringComparison.OrdinalIgnoreCase)) continue;
                    document = ((dynamic)window).Document;
                    folder = ((dynamic)document).Folder;
                    self = ((dynamic)folder).Self;
                    result.Add(((nint)(long)((dynamic)window).HWND, (string)((dynamic)self).Path));
                }
                catch (Exception error) when (error is COMException or InvalidComObjectException
                    or Microsoft.CSharp.RuntimeBinder.RuntimeBinderException) { }
                finally { Release(self); Release(folder); Release(document); Release(window); }
            }
            return result;
        }
        finally { Release(windows); Release(shell); }
    }

    private static bool CloseOwnedExplorer(nint handle, string path, HashSet<nint> before)
    {
        if (before.Contains(handle)) throw new InvalidOperationException("Refusing to close a pre-existing Explorer window.");
        object? shell = null, windows = null;
        try
        {
            shell = Activator.CreateInstance(Type.GetTypeFromProgID("Shell.Application")!);
            windows = ((dynamic)shell!).Windows();
            var count = (int)((dynamic)windows).Count;
            for (var index = 0; index < count; index++)
            {
                object? window = null, document = null, folder = null, self = null;
                try
                {
                    window = ((dynamic)windows).Item(index);
                    if (window == null || (nint)(long)((dynamic)window).HWND != handle) continue;
                    document = ((dynamic)window).Document;
                    folder = ((dynamic)document).Folder;
                    self = ((dynamic)folder).Self;
                    if (!((string)((dynamic)self).Path).Equals(path, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidOperationException("The fixture window changed location; refusing to close it.");
                    ((dynamic)window).Quit();
                    return true;
                }
                finally { Release(self); Release(folder); Release(document); Release(window); }
            }
            return false;
        }
        finally { Release(windows); Release(shell); }
    }

    private static void Release(object? value)
    {
        if (value != null && Marshal.IsComObject(value)) Marshal.ReleaseComObject(value);
    }
}

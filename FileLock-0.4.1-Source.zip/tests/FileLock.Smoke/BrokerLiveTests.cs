using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text.Json;
using System.Text.RegularExpressions;
using FileLock.Service;
using FileLock.Shared;
using Microsoft.Win32.SafeHandles;

// Runs only inside the temporary native-test SYSTEM service. The state store
// and all protected paths stay inside that service's fresh disposable fixture.
internal static class BrokerLiveTests
{
    internal static async Task RunAsync(string suppliedRoot, string ownerSid, uint processId, List<string> checks)
    {
        var root = Path.GetFullPath(suppliedRoot).TrimEnd(Path.DirectorySeparatorChar);
        var fixture = new DirectoryInfo(root);
        if (!Regex.IsMatch(fixture.Name, "^native-[a-f0-9]{32}$") || fixture.Parent?.Name != ".work" || fixture.Parent.Parent?.Name != "tests")
            throw new InvalidOperationException("Broker integration tests require a fresh tests/.work/native-<guid> fixture.");
        for (var parent = fixture; parent != null; parent = parent.Parent)
            if (parent.Attributes.HasFlag(FileAttributes.ReparsePoint)) throw new IOException("The broker fixture contains a reparse point.");
        using var system = WindowsIdentity.GetCurrent();
        if (!system.IsSystem) throw new UnauthorizedAccessException("The broker integration harness must run in its temporary SYSTEM service.");
        using var caller = NormalCaller(processId, ownerSid);
        const string masterPin = "184063";
        const string individualPin = "709251";
        const string wrongPin = "999997";
        var sharedPath = Path.Combine(root, "broker-shared-folder");
        var individualPath = Path.Combine(root, "broker-individual-folder");
        WindowsIdentity.RunImpersonated(caller.Identity.AccessToken, () =>
        {
            foreach (var path in new[] { sharedPath, individualPath })
            {
                Directory.CreateDirectory(Path.Combine(path, "nested"));
                File.WriteAllText(Path.Combine(path, "nested", "child.txt"), "Disposable broker PIN verification fixture.");
            }
        });
        var store = new StateStore(Path.Combine(root, "broker-system-state"));
        using var engine = new BrokerEngine(store);
        string? managementToken = null;
        var originals = new Dictionary<string, List<PermissionJournalEntry>>(StringComparer.Ordinal);
        Exception? failure = null;
        async Task<BrokerResponse> Send(BrokerRequest request) => await engine.ExecuteAsync(request, caller, CancellationToken.None);
        try
        {
            var beforeSetup = Require(await Send(new() { Operation = "Resolve", Path = sharedPath }));
            var initial = Require(await Send(new() { Operation = "Status" }));
            NativeAclTests.Check(beforeSetup.Item == null && initial.Status?.Initialized == false && !File.Exists(Path.Combine(root, "broker-system-state", "state.dpapi")),
                "Resolving a path before setup initialized or modified the isolated broker state.");
            checks.Add("Resolving an unconfigured folder does not initialize the broker or grant access");

            var setup = Require(await Send(new() { Operation = "Setup", Pin = masterPin }));
            managementToken = setup.Setup?.SessionToken ?? throw new InvalidOperationException("The isolated setup returned no management token.");
            var shared = Require(await Send(new() { Operation = "Add", SessionToken = managementToken, Path = sharedPath, Kind = ProtectionKind.Folder })).Item
                ?? throw new InvalidOperationException("The broker did not return the shared folder.");
            var individual = Require(await Send(new() { Operation = "Add", SessionToken = managementToken, Path = individualPath, Kind = ProtectionKind.Folder, ItemPin = individualPin })).Item
                ?? throw new InvalidOperationException("The broker did not return the individual-PIN folder.");
            foreach (var item in store.Load().Users.Single().Items) originals[item.Id] = item.PermissionJournal;
            Require(await Send(new() { Operation = "Logout", SessionToken = managementToken }));
            managementToken = null;

            foreach (var item in new[] { shared, individual })
            {
                await AssertDeniedAsync(root, item.OriginalPath, processId);
                await ContinueBypassTests.AssertDeniedAsync(root, item.OriginalPath, ownerSid, checks);
                await AssertDeniedAsync(root, item.OriginalPath, processId);
                checks.Add("Normal original folder listings and descendant reads remain denied after elevated Continue attempt for " + Path.GetFileName(item.OriginalPath));
                var snapshot = File.ReadAllBytes(Path.Combine(root, "broker-system-state", "state.dpapi"));
                var resolved = Require(await Send(new() { Operation = "Resolve", Path = item.OriginalPath })).Item;
                var nested = Require(await Send(new() { Operation = "Resolve", Path = Path.Combine(item.OriginalPath, "nested") })).Item;
                var noLogin = Require(await Send(new() { Operation = "Status" }));
                NativeAclTests.Check(resolved?.Id == item.Id && nested?.Id == item.Id && resolved.IsOpen == false && nested.IsOpen == false
                    && noLogin.Status?.SessionAuthenticated == false && snapshot.SequenceEqual(File.ReadAllBytes(Path.Combine(root, "broker-system-state", "state.dpapi"))),
                    "Unauthenticated folder resolution changed permissions, authenticated management, or modified saved state.");
                await AssertDeniedAsync(root, item.OriginalPath, processId);
            }
            checks.Add("Broker-added folders deny actual normal-process listing and descendant reads");
            checks.Add("Resolving original and nested folders before login leaves both locked and saved state unchanged");
            var unauthorizedList = await Send(new() { Operation = "List" });
            NativeAclTests.Check(!unauthorizedList.Ok && unauthorizedList.ErrorCode == "SESSION_EXPIRED", "A Resolve request authenticated protected-item management.");
            checks.Add("Folder resolution does not authorize protected-item management");

            var rejectedShared = await Send(new() { Operation = "Unlock", ItemId = shared.Id, Pin = wrongPin });
            NativeAclTests.Check(!rejectedShared.Ok && rejectedShared.ErrorCode == "INVALID_PIN", "The broker accepted an incorrect shared PIN.");
            AssertSavedLocked(store, shared.Id);
            await AssertDeniedAsync(root, sharedPath, processId);
            checks.Add("Incorrect shared folder PIN keeps original listing and descendant contents denied");

            var rejectedMaster = await Send(new() { Operation = "Unlock", ItemId = individual.Id, Pin = masterPin });
            NativeAclTests.Check(!rejectedMaster.Ok && rejectedMaster.ErrorCode == "INVALID_PIN", "The shared master PIN bypassed a folder's individual PIN.");
            AssertSavedLocked(store, individual.Id);
            await AssertDeniedAsync(root, individualPath, processId);
            checks.Add("Shared master PIN cannot unlock a folder protected by its individual PIN");

            var rejectedIndividual = await Send(new() { Operation = "Unlock", ItemId = individual.Id, Pin = wrongPin });
            NativeAclTests.Check(!rejectedIndividual.Ok && rejectedIndividual.ErrorCode == "INVALID_PIN", "The broker accepted an incorrect individual PIN.");
            AssertSavedLocked(store, individual.Id);
            await AssertDeniedAsync(root, individualPath, processId);
            checks.Add("Incorrect individual folder PIN keeps original listing and descendant contents denied");

            var approvedShared = Require(await Send(new() { Operation = "Unlock", ItemId = shared.Id, Pin = masterPin }));
            NativeAclTests.Check(approvedShared.Item?.IsOpen == true, "The correct shared PIN did not grant the original folder.");
            await AssertOpenAsync(root, sharedPath, processId);
            var afterApproval = Require(await Send(new() { Operation = "Status" }));
            NativeAclTests.Check(afterApproval.Status?.SessionAuthenticated == false, "Folder PIN approval created an unrelated management login.");
            checks.Add("Correct shared PIN opens the original folder and descendant contents without management login");
            managementToken = Require(await Send(new() { Operation = "Login", Pin = masterPin })).SessionToken
                ?? throw new InvalidOperationException("The isolated management login returned no session.");
            Require(await Send(new() { Operation = "Lock", SessionToken = managementToken, ItemId = shared.Id }));
            await AssertDeniedAsync(root, sharedPath, processId);

            var approvedIndividual = Require(await Send(new() { Operation = "Unlock", ItemId = individual.Id, Pin = individualPin }));
            NativeAclTests.Check(approvedIndividual.Item?.IsOpen == true && approvedIndividual.Item.AccessToken is { Length: 64 }
                && !approvedIndividual.Item.UsesSharedPin, "The correct individual PIN did not grant an individual access session.");
            var accessToken = approvedIndividual.Item!.AccessToken!;
            await AssertOpenAsync(root, individualPath, processId);
            checks.Add("Correct individual PIN opens the original folder and descendant contents");

            var resolvedOpen = Require(await Send(new() { Operation = "Resolve", Path = individualPath })).Item;
            var listedOpen = Require(await Send(new() { Operation = "List", SessionToken = managementToken })).Items?.Single(item => item.Id == individual.Id);
            NativeAclTests.Check(resolvedOpen?.IsOpen == true && resolvedOpen.AccessToken == null && listedOpen?.AccessToken == null,
                "Read-only item lookup exposed an access-session secret.");
            checks.Add("Only fresh PIN approval returns the access-session token; lookup and item lists do not expose it");

            var originalDeadline = OpenDeadline(store, individual.Id);
            foreach (var operation in new[] { "RenewAccess", "CloseAccess" })
            foreach (var token in new string?[] { null, new string('0', 64) })
            {
                AssertAccessRejected(await Send(new() { Operation = operation, ItemId = individual.Id, AccessToken = token }));
                AssertOpenDeadline(store, individual.Id, originalDeadline);
            }
            AssertOriginalPermissions(individualPath, originals[individual.Id]);
            await AssertOpenAsync(root, individualPath, processId);
            checks.Add("Missing and incorrect access tokens cannot renew or close an open location or change its permissions");

            await Task.Delay(150);
            Require(await Send(new() { Operation = "RenewAccess", ItemId = individual.Id, AccessToken = accessToken }));
            var renewedDeadline = OpenDeadline(store, individual.Id);
            NativeAclTests.Check(renewedDeadline > originalDeadline && renewedDeadline > DateTimeOffset.UtcNow
                && renewedDeadline <= DateTimeOffset.UtcNow.AddSeconds(NativePathProtection.AccessWindowSeconds),
                "The current access heartbeat did not extend its bounded deadline.");
            checks.Add("A valid heartbeat renews the current location's short access deadline");

            var wrongReopen = await Send(new() { Operation = "Unlock", ItemId = individual.Id, Pin = wrongPin });
            NativeAclTests.Check(!wrongReopen.Ok && wrongReopen.ErrorCode == "INVALID_PIN", "An open individual location accepted an incorrect PIN on reopening.");
            AssertOpenDeadline(store, individual.Id, renewedDeadline);
            AssertOriginalPermissions(individualPath, originals[individual.Id]);
            Require(await Send(new() { Operation = "RenewAccess", ItemId = individual.Id, AccessToken = accessToken }));
            checks.Add("Reopening an already-open individual location still verifies its PIN and an incorrect PIN cannot replace its access session");

            WindowsIdentity.RunImpersonated(caller.Identity.AccessToken, () =>
                File.WriteAllText(Path.Combine(individualPath, "created-during-use.txt"), "Saved during an approved folder use."));
            var reopened = Require(await Send(new() { Operation = "Unlock", ItemId = individual.Id, Pin = individualPin })).Item!;
            NativeAclTests.Check(store.Load().Users.Single().Items.Single(item => item.Id == individual.Id).PermissionJournal
                .Any(entry => entry.RelativePath == "created-during-use.txt"), "Fresh PIN approval did not journal a file created during the previous folder use.");
            checks.Add("Reopening an edited folder with a fresh PIN journals newly created contents before starting its new access session");
            NativeAclTests.Check(reopened.IsOpen && reopened.AccessToken is { Length: 64 } && reopened.AccessToken != accessToken,
                "A fresh PIN approval reused the previous access-session token.");
            var freshToken = reopened.AccessToken!;
            var freshDeadline = OpenDeadline(store, individual.Id);
            foreach (var operation in new[] { "RenewAccess", "CloseAccess" })
            {
                AssertAccessRejected(await Send(new() { Operation = operation, ItemId = individual.Id, AccessToken = accessToken }));
                AssertOpenDeadline(store, individual.Id, freshDeadline);
            }
            AssertOriginalPermissions(individualPath, originals[individual.Id]);
            checks.Add("Fresh PIN approval rotates the access token and stale renew or close requests cannot affect the new session");

            using (var otherSession = new CallerContext(caller.Sid, caller.SessionId + 1,
                new WindowsIdentity(caller.Identity.AccessToken.DangerousGetHandle())))
            {
                foreach (var operation in new[] { "RenewAccess", "CloseAccess" })
                {
                    AssertAccessRejected(await engine.ExecuteAsync(new() { Operation = operation, ItemId = individual.Id, AccessToken = freshToken }, otherSession, CancellationToken.None));
                    AssertOpenDeadline(store, individual.Id, freshDeadline);
                }
            }
            await AssertOpenAsync(root, individualPath, processId);
            checks.Add("A different Windows session cannot use another session's access token to renew or close the location");

            Require(await Send(new() { Operation = "SignOutSettings" }));
            var signedOutList = await Send(new() { Operation = "List", SessionToken = managementToken });
            NativeAclTests.Check(!signedOutList.Ok && signedOutList.ErrorCode == "SESSION_EXPIRED"
                && Require(await Send(new() { Operation = "Status", SessionToken = managementToken })).Status?.SessionAuthenticated == false,
                "Signing out of settings left its previous management token authenticated.");
            managementToken = null;
            AssertOpenDeadline(store, individual.Id, freshDeadline);
            Require(await Send(new() { Operation = "RenewAccess", ItemId = individual.Id, AccessToken = freshToken }));
            await AssertOpenAsync(root, individualPath, processId);
            checks.Add("Signing out of settings invalidates its old management token while the active item access heartbeat remains valid");

            Require(await Send(new() { Operation = "CloseAccess", ItemId = individual.Id, AccessToken = freshToken }));
            AssertSavedLocked(store, individual.Id);
            await AssertDeniedAsync(root, individualPath, processId);
            AssertAccessRejected(await Send(new() { Operation = "RenewAccess", ItemId = individual.Id, AccessToken = freshToken }));
            checks.Add("Closing the current access session relocks actual folder listing and descendant reads without a management login");

            var masterReopen = await Send(new() { Operation = "Unlock", ItemId = individual.Id, Pin = masterPin });
            NativeAclTests.Check(!masterReopen.Ok && masterReopen.ErrorCode == "INVALID_PIN", "Closing an individual location reset it to the shared master PIN.");
            AssertSavedLocked(store, individual.Id);
            await AssertDeniedAsync(root, individualPath, processId);
            checks.Add("Reopening a closed individual location requires its individual PIN and rejects the master PIN");

            var unattended = Require(await Send(new() { Operation = "Unlock", ItemId = individual.Id, Pin = individualPin })).Item!;
            NativeAclTests.Check(unattended.IsOpen && unattended.AccessToken is { Length: 64 }, "The correct PIN did not reopen a closed location.");
            await AssertOpenAsync(root, individualPath, processId);
            var heartbeatDeadline = OpenDeadline(store, individual.Id);
            var expiryLimit = heartbeatDeadline.AddSeconds(5);
            while (DateTimeOffset.UtcNow < expiryLimit && store.Load().Users.Single().Items.Single(item => item.Id == individual.Id).ProtectionPhase == "Open")
                await Task.Delay(200);
            AssertSavedLocked(store, individual.Id);
            await AssertDeniedAsync(root, individualPath, processId);
            checks.Add("Losing access heartbeats automatically relocks actual original folder and descendant reads after the short deadline");
            foreach (var operation in new[] { "RenewAccess", "CloseAccess" })
                AssertAccessRejected(await Send(new() { Operation = operation, ItemId = individual.Id, AccessToken = unattended.AccessToken }));
            AssertSavedLocked(store, individual.Id);
            checks.Add("An expired access token cannot reopen or extend the automatically relocked location");

            managementToken = Require(await Send(new() { Operation = "Login", Pin = masterPin })).SessionToken
                ?? throw new InvalidOperationException("The deleted-item test received no management session.");
            var deletedPath = Path.Combine(root, "broker-deleted-empty-folder");
            WindowsIdentity.RunImpersonated(caller.Identity.AccessToken, () => Directory.CreateDirectory(deletedPath));
            var deletedItem = Require(await Send(new() { Operation = "Add", SessionToken = managementToken,
                Path = deletedPath, Kind = ProtectionKind.Folder })).Item
                ?? throw new InvalidOperationException("The broker did not protect the disposable deleted-item fixture.");
            var deletedJournal = JsonSerializer.Serialize(store.Load().Users.Single().Items.Single(item => item.Id == deletedItem.Id).PermissionJournal);
            Directory.Delete(deletedPath); // SYSTEM deletes only this empty fixture.
            var unauthorizedRemoval = await Send(new() { Operation = "Remove", ItemId = deletedItem.Id });
            NativeAclTests.Check(!unauthorizedRemoval.Ok && unauthorizedRemoval.ErrorCode == "SESSION_EXPIRED"
                && deletedJournal == JsonSerializer.Serialize(store.Load().Users.Single().Items.Single(item => item.Id == deletedItem.Id).PermissionJournal),
                "Unauthenticated removal discarded a deleted location's saved recovery record.");
            Require(await Send(new() { Operation = "Remove", SessionToken = managementToken, ItemId = deletedItem.Id }));
            NativeAclTests.Check(store.Load().Users.Single().Items.All(item => item.Id != deletedItem.Id) && !Directory.Exists(deletedPath),
                "Authenticated deleted-location removal did not durably remove its record, or recreated the deleted root.");
            checks.Add("Removing a permanently deleted broker item requires management authentication, then durably removes its saved record without recreating the root");

            Require(await Send(new() { Operation = "SignOutSettings" }));
            managementToken = null;
            var beforeMove = store.Load().Users.Single().Items.Single(item => item.Id == individual.Id);
            var movedIndividualPath = individualPath + "-renamed";
            Directory.Move(individualPath, movedIndividualPath);
            var movedResolved = Require(await Send(new() { Operation = "Resolve", Path = movedIndividualPath })).Item;
            var afterMove = store.Load().Users.Single().Items.Single(item => item.Id == individual.Id);
            NativeAclTests.Check(movedResolved?.Id == individual.Id && movedResolved.OriginalPath == movedIndividualPath
                && !movedResolved.IsOpen && !movedResolved.UsesSharedPin
                && afterMove.OriginalPath == movedIndividualPath && afterMove.PinSalt == beforeMove.PinSalt && afterMove.PinHash == beforeMove.PinHash
                && JsonSerializer.Serialize(afterMove.PermissionJournal) == JsonSerializer.Serialize(beforeMove.PermissionJournal)
                && Require(await Send(new() { Operation = "Status" })).Status?.SessionAuthenticated == false,
                "Resolving a renamed original folder lost its individual PIN, saved journal, locked state, or authenticated management without a login.");
            await AssertDeniedAsync(root, movedIndividualPath, processId);
            checks.Add("Unauthenticated resolution repairs a renamed locked folder by identity while preserving its individual PIN and denied normal-process access");
        }
        catch (Exception error) { failure = error; }
        finally
        {
            var cleanupErrors = new List<Exception>();
            try
            {
                var remaining = store.Load().Users.SingleOrDefault()?.Items.ToList() ?? [];
                if (remaining.Count > 0)
                {
                    managementToken = Require(await Send(new() { Operation = "Login", Pin = masterPin })).SessionToken;
                    foreach (var item in remaining)
                    {
                        try
                        {
                            Require(await Send(new() { Operation = "Remove", SessionToken = managementToken, ItemId = item.Id }));
                            if (originals.TryGetValue(item.Id, out var journal))
                                foreach (var original in journal)
                                {
                                    var path = original.RelativePath.Length == 0 ? item.OriginalPath : Path.Combine(item.OriginalPath, original.RelativePath);
                                    using var restored = SecurityNative.Open(path, original.RelativePath, captureSecurity: true);
                                    NativeAclTests.Check(SecurityNative.IdentityMatches(original, restored.Entry), "Broker removal restored permissions to a different object.");
                                    SamePermissions(original.OriginalSecurityDescriptor, restored.Entry.OriginalSecurityDescriptor);
                                }
                        }
                        catch (Exception error) { cleanupErrors.Add(new IOException("Disposable broker fixture restoration needs its retained journal: " + item.OriginalPath, error)); }
                    }
                }
            }
            catch (Exception error) { cleanupErrors.Add(error); }
            if (cleanupErrors.Count > 0) failure = new AggregateException(new[] { failure }.Where(error => error != null).Cast<Exception>().Concat(cleanupErrors));
        }
        if (failure != null) throw failure;
        checks.Add("Broker removal restores the exact original folder and descendant permission journal");
    }

    private static BrokerResponse Require(BrokerResponse response)
    {
        if (!response.Ok) throw new InvalidOperationException("The isolated broker request failed: " + response.ErrorCode + " " + response.Error);
        return response;
    }

    private static void AssertSavedLocked(StateStore store, string id)
    {
        var saved = store.Load().Users.Single().Items.Single(item => item.Id == id);
        NativeAclTests.Check(saved.ProtectionPhase == "Locked" && saved.ActiveLeaseUntilUtc == null, "An incorrect PIN created a saved access window.");
    }

    private static DateTimeOffset OpenDeadline(StateStore store, string id)
    {
        var saved = store.Load().Users.Single().Items.Single(item => item.Id == id);
        NativeAclTests.Check(saved.ProtectionPhase == "Open" && saved.ProtectionError == null && saved.ActiveLeaseUntilUtc is { } until && until > DateTimeOffset.UtcNow,
            "The expected current access session is not open.");
        return saved.ActiveLeaseUntilUtc!.Value;
    }

    private static void AssertOpenDeadline(StateStore store, string id, DateTimeOffset expected)
    {
        NativeAclTests.Check(OpenDeadline(store, id) == expected, "A rejected request changed the active access deadline.");
    }

    private static void AssertAccessRejected(BrokerResponse response)
    {
        NativeAclTests.Check(!response.Ok && response.ErrorCode == "ACCESS_SESSION_EXPIRED",
            "An invalid access token or Windows session was accepted.");
    }

    private static void AssertOriginalPermissions(string root, List<PermissionJournalEntry> journal)
    {
        foreach (var original in journal)
        {
            var path = original.RelativePath.Length == 0 ? root : Path.Combine(root, original.RelativePath);
            using var current = SecurityNative.Open(path, original.RelativePath, captureSecurity: true);
            NativeAclTests.Check(SecurityNative.IdentityMatches(original, current.Entry), "The open access fixture changed identity.");
            SamePermissions(original.OriginalSecurityDescriptor, current.Entry.OriginalSecurityDescriptor);
        }
    }

    private static async Task AssertDeniedAsync(string root, string path, uint processId)
    {
        var listing = await ProbeAsync(root, path, "Enumerate");
        var read = await ProbeAsync(root, Path.Combine(path, "nested", "child.txt"), "Read");
        NativeAclTests.Check(listing.ProcessId == processId && read.ProcessId == processId && !listing.Succeeded && !read.Succeeded
            && listing.ErrorType == typeof(UnauthorizedAccessException).FullName && read.ErrorType == typeof(UnauthorizedAccessException).FullName,
            "A normal Windows process accessed a broker-locked original folder: " + listing.ErrorMessage + " " + read.ErrorMessage);
    }

    private static async Task AssertOpenAsync(string root, string path, uint processId)
    {
        var listing = await ProbeAsync(root, path, "Enumerate");
        var read = await ProbeAsync(root, Path.Combine(path, "nested", "child.txt"), "Read");
        NativeAclTests.Check(listing.ProcessId == processId && read.ProcessId == processId && listing.Succeeded && listing.EntryCount > 0 && read.Succeeded,
            "PIN approval did not open the original folder and descendant contents: " + listing.ErrorMessage + " " + read.ErrorMessage);
    }

    private sealed class ProbeResponse
    {
        public string Id { get; set; } = "";
        public bool Succeeded { get; set; }
        public int? EntryCount { get; set; }
        public string? ErrorType { get; set; }
        public string? ErrorMessage { get; set; }
        public uint ProcessId { get; set; }
    }

    private static async Task<ProbeResponse> ProbeAsync(string root, string path, string operation)
    {
        var id = Guid.NewGuid().ToString("N");
        var request = Path.Combine(root, "probe-request.json");
        var temporary = request + ".next";
        File.WriteAllText(temporary, JsonSerializer.Serialize(new { Id = id, Path = path, Operation = operation }));
        File.Move(temporary, request, overwrite: true);
        var responsePath = Path.Combine(root, "probe-response.json");
        var deadline = DateTimeOffset.UtcNow.AddSeconds(15);
        while (DateTimeOffset.UtcNow < deadline)
        {
            try
            {
                if (File.Exists(responsePath) && new FileInfo(responsePath).Length < 16 * 1024)
                {
                    var response = JsonSerializer.Deserialize<ProbeResponse>(File.ReadAllText(responsePath));
                    if (response?.Id == id) return response;
                }
            }
            catch (IOException) { }
            catch (JsonException) { }
            await Task.Delay(50);
        }
        throw new TimeoutException("The normal parent process did not answer the isolated broker folder probe.");
    }

    private static CallerContext NormalCaller(uint processId, string sid)
    {
        using var process = OpenProcess(0x1000, false, processId);
        if (process.IsInvalid || !OpenProcessToken(process, 0x000E, out var source)) throw new Win32Exception();
        using (source)
        {
            if (!DuplicateTokenEx(source, 0x02000000, IntPtr.Zero, 2, 2, out var token)) throw new Win32Exception();
            using (token)
            {
                var identity = new WindowsIdentity(token.DangerousGetHandle());
                try
                {
                    if (identity.User?.Value != sid || identity.IsSystem || new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator))
                        throw new UnauthorizedAccessException("Broker tests require the actual normal Windows parent token.");
                    if (!GetTokenInformation(identity.AccessToken, 12, out uint session, sizeof(uint), out _) || session == 0) throw new Win32Exception();
                    return new(sid, session, identity);
                }
                catch { identity.Dispose(); throw; }
            }
        }
    }

    private static void SamePermissions(string originalBase64, string restoredBase64)
    {
        var original = new RawSecurityDescriptor(Convert.FromBase64String(originalBase64), 0);
        var restored = new RawSecurityDescriptor(Convert.FromBase64String(restoredBase64), 0);
        NativeAclTests.Check(original.Owner?.Value == restored.Owner?.Value && original.Group?.Value == restored.Group?.Value, "Broker removal changed the original owner/group.");
        foreach (var (left, right) in new[] { (original.DiscretionaryAcl, restored.DiscretionaryAcl), (original.SystemAcl, restored.SystemAcl) })
        {
            NativeAclTests.Check((left == null) == (right == null), "Broker removal changed an absent original ACL.");
            if (left == null) continue;
            var leftBytes = new byte[left.BinaryLength]; var rightBytes = new byte[right!.BinaryLength];
            left.GetBinaryForm(leftBytes, 0); right.GetBinaryForm(rightBytes, 0);
            NativeAclTests.Check(leftBytes.SequenceEqual(rightBytes), "Broker removal changed the original permission/audit ACL.");
        }
        const ControlFlags protection = ControlFlags.DiscretionaryAclProtected | ControlFlags.SystemAclProtected;
        NativeAclTests.Check((original.ControlFlags & protection) == (restored.ControlFlags & protection), "Broker removal changed original inheritance protection.");
    }

    [DllImport("kernel32.dll", SetLastError = true)] private static extern SafeProcessHandle OpenProcess(uint access, bool inherit, uint processId);
    [DllImport("advapi32.dll", SetLastError = true)] private static extern bool OpenProcessToken(SafeProcessHandle process, uint access, out SafeAccessTokenHandle token);
    [DllImport("advapi32.dll", SetLastError = true)] private static extern bool DuplicateTokenEx(SafeAccessTokenHandle source, uint access, IntPtr attributes, int level, int type, out SafeAccessTokenHandle token);
    [DllImport("advapi32.dll", SetLastError = true)] private static extern bool GetTokenInformation(SafeAccessTokenHandle token, int information, out uint sessionId, uint length, out uint returned);
}
